# Diners Club Privilege Credit  Card

Global Belonging, Ready For You.

For the global citizens who cherish the unexplored, savor the exotic. Elevate your joy with the HDFC Bank Diners Club Privilege Credit Card.

[**Click here**](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\Know-more-Privilege-Portfolio-Communication.pdf) **if card open date is before 15** **th** **June 23**

Diners Club Privilege Credit  Card

## All You Need To Know

- [Features](\personal\pay\cards\credit-cards\diners-privilege)
- [Eligibility](\personal\pay\cards\credit-cards\diners-privilege\eligibility)
- [Fees &amp; Charges](\personal\pay\cards\credit-cards\diners-privilege\fees-and-charges)

### [Features](\personal\pay\cards\credit-cards\diners-privilege)

## 

#### Key Features

Key Features

- 'Buy 1 Get 1 Free' on movie/non-movie weekend tickets via BookMyShow
- 5X Reward Points on Swiggy and Zomato
- Complimentary Annual Memberships of Swiggy One and Times Prime as Welcome Benefit
- ₹ 1,500 worth Marriott, Decathlon &amp; more vouchers on quarterly spends of Rs. 1.5 lakh
- 2 Complimentary Airport lounge access every calendar quarter worldwide
- 4 Reward Points for every ₹ 150 spent

## 

#### Additional Features

Additional Features

- Redeem reward points for higher value on the Exclusive Privilege Dining Catalogue. [Click here](https://offers.reward360.in/diners/rewards?cat=exclusive-diners-privilege) to redeem (or) follow these steps: Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7Cec97ed89b9114e80077908db79473696%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638237118988693881%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=jfbpScSLxeTFeKwgrFEWiEi9W4rup2%2BZzovTa6JlowA%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Exclusive Dining Catalogue'
- Travel benefits: Upto 10X Rewards on Booking flight tickets / stays across 150+ hotels (Domestic &amp; International) at https://offers.smartbuy.hdfcbank.com/diners
- Interest Free Credit Period: Up to 50 days of interest free credit period on your HDFC Bank Diners Club Privilege Credit Card from the date of purchase. (subject to the submission of the charge by the Merchant)
- Credit Liability Cover: Rs. 9 lakh
- Foreign Currency Markup: Nominal 3.5% on all your foreign currency spends. (These charges are billed on your subsequent statement within 60 days from date of visit. Currency conversion rate is applicable as on the date of settlement)
- Revolving Credit: Available at a nominal interest rate on your HDFC Bank Diners Club Privilege Credit Card. Please refer to Fees and Charges section to know more. [Click here](\personal\pay\cards\credit-cards\diners-privilege\fees-and-charges) to visit.

## 

#### Customer Care

Customer Care

HDFC Phone Banking: For any queries, call us on 1800 1600 / 1800 2600  (from 8 a.m. to 8p.m.) Customers travelling overseas can reach us at 022-  61606160

Smartbuy Concierge: Simply call on 1860 425 1188

## 

#### Lounge Access

Lounge Access

- 2 Complimentary Airport lounge access every calendar quarter worldwide
- Please [click here](https://lms.hoi.in/lounge-list/hdfc-diners-privilege) to view Domestic Lounges
- Please [click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\International-Lounge-List.pdf) to view International Lounges

## 

#### Welcome Benefits

Welcome Benefits

- Avail Complimentary Annual memberships of Swiggy One and Times Prime on spending Rs 75,000 within the first 90 days of card issuance.
- Easily track your milestone spends and redeem benefits by following these steps. Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7C72f5c55e0a9841315af408db970b83ec%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638269847931494165%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=BVQnjkRlw40x6zS8y3imSok0hY0IfFaahJpfh6TbQl4%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Diners Club Privilege Milestones' &gt;&gt; Check Welcome Benefits.
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\DNP-ProductFeature-TnC.pdf) for T &amp; C

## 

#### Dining &amp; Entertainment Benefits

Dining &amp; Entertainment Benefits

- 'Buy 1 Get 1 Free' on movie/non-movie weekend tickets via BookMyShow. Offer is applicable for shows on Friday, Saturday and Sunday (irrespective of booking day). Maximum discount is Rs. 250/ticket, upto 2 free tickets every calendar month
- 5X Reward Points on Swiggy and Zomato. Additional 4X RP is capped at 2500 reward points every calendar month
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\DNP-ProductFeature-TnC.pdf) for T &amp; C

## 

#### Milestone Benefit

Milestone Benefit

- Avail ₹ 1,500 worth vouchers of Marriott Experience or Decathlon or Barbeque Nation or O2 Spa or Lakme Salon on spends of Rs. 1.5 lakhs in a calendar quarter.
- Easily track your milestone spends and redeem benefits by following these steps. Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7C72f5c55e0a9841315af408db970b83ec%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638269847931494165%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=BVQnjkRlw40x6zS8y3imSok0hY0IfFaahJpfh6TbQl4%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Diners Club Privilege Milestones' &gt;&gt; Check Quarterly Benefits.
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\DNP-ProductFeature-TnC.pdf) for T &amp; C

## 

#### Renewal Offer

Renewal Offer

Renewal Fee waiver for next year on spends of Rs. 3 Lakhs in card anniversary year.

## 

#### Smart EMI (With logo)

Smart EMI (With logo)

HDFC Bank Diners Club Privilege Credit Card comes with an option to convert your big spends into EMI after purchase. To know more [click here](\personal\borrow\loan-against-assets\smartemi)

## 

#### Contactless Payment

Contactless Payment

The HDFC Bank Diners Club Privilege Credit Card is enabled for contactless payments on HDFC Bank POS machines, facilitating fast, convenient and secure payments at retail outlets.

*To see if your Card is contactless, look for contactless network symbol on your Card.

(Please note that in India, payment through contactless mode is allowed for a maximum of ₹5000 for a single transaction without the need to input your Credit Card PIN. However, if the amount is higher than or equal to ₹5000, the Card holder has to enter the Credit Card PIN for security reasons)

## 

#### Insurance/Comprehensive protection &amp; Nominee details for Insurance

Insurance/Comprehensive protection &amp; Nominee details for Insurance

- Air accident insurance cover worth ₹1crore($125,000)
- Emergency overseas hospitalization: up to ₹25 Lacs ($31,250)
- Travel Insurance Cover of up to ₹ 50,000 (up to $625) on baggage delay (Capped to 10$ per hour restricted to 8 hours)
- Credit Liability Cover of up to ₹ 9 Lakh
- [Click here](https://leads.hdfcbank.com/applications/webforms/apply/HDFC_NomineeDetails/Nominee.aspx) to update Nominee Details.
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\PDFs\Covers_Dinersaug.pdf) for Policy Details

## 

#### Reward Point/CashBack Redemption &amp; Validity

Reward Point/CashBack Redemption &amp; Validity

**Reward Points Accrual:**

- Earn 4 Reward Points on every Rs.150 retail* spends
- Earn 20 Reward Points on every Rs 150 spends on Swiggy and Zomato
- Earn upto 10X Reward Points on Spends Via Smartbuy

**Reward Point Redemption:**

You can redeem your Reward Points on Smartbuy or NetBanking.

Reward Points can be redeemed for:

- Flights and hotel bookings via Smartbuy at a value of 1 RP = Rs 0.5
- Exclusive Privilege Dining Catalogue on select Restaurants via Smartbuy at a value of 1 RP = Rs 0.50. [Click here](https://offers.reward360.in/diners/rewards?cat=exclusive-diners-privilege) to redeem (or) follow these steps: Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7Cec97ed89b9114e80077908db79473696%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638237118988693881%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=jfbpScSLxeTFeKwgrFEWiEi9W4rup2%2BZzovTa6JlowA%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Exclusive Dining Catalogue'
- Redeem Rewards Points on exclusive reward redemption catalogue for HDFC Bank Diners Club Privilege Credit Card 1 RP upto Rs 0.35
- Cashback at a value of 1 RP = Rs 0.20.
- Please [Click Here](\personal\pay\cards\credit-cards\personal-mitc) to know more

## 

#### Good food trail program

Good food trail program

- Good food Trail Program - HDFC Bank x Swiggy Dineout

Indulge in mouth-watering discounts! Pay with your HDFC Bank Credit Card and enjoy FLAT 10% EXTRA OFF* on dining bills at 35K+ restaurants! * - T&amp;C Apply. Please Click Here(embed &lt;https://tnc.dineout.co.in/hdfc\_tnc.html&gt;) to know more.

## 

#### Diners Exclusive Offers

Diners Exclusive Offers

- **Fast Track Airport Experience:** Skip the line for check-in and receive baggage assistance.
- **Dining Delight:** exclusive dining offers, from gourmet cuisine to local delicacies.
- **Luxury Spas:** access to some of the finest spas within India at special rates.
- **Small Medium Enterprise (SME):** tailor-made offers such as workspaces, business insurance and wellness discounts to meet business needs. To Know more [click here](https://dinersclub-offerplatform.com/)

### [Eligibility](\personal\pay\cards\credit-cards\diners-privilege\eligibility)

### [Fees &amp; Charges](\personal\pay\cards\credit-cards\diners-privilege\fees-and-charges)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Related Searches   | Related Searches                   | Related Searches   | Related Searches             |
|--------------------|------------------------------------|--------------------|------------------------------|
|                    | how to get a credit card           |                    | cibil score for credit card  |
|                    | how to choose the best credit card |                    | credit card offers           |
|                    | instant credit card                |                    | apply for credit card online |

## People Also Looked At

### Regalia Gold Credit Card

Regalia Gold Credit Card

Experience the Golden Side Of Life

### Millennia Credit Card

Millennia Credit Card

Best CashBack Credit Card

### Tata Neu Infinity HDFC Bank Credit Card

Tata Neu Infinity HDFC Bank Credit Card

Extraordinary Rewards. Ready for You.

### Related Videos

- [Know about Diners Club International](#)
Image Hyperlink.

<!-- image -->

[View More](#)

[View Less](#)

## 

Login

Know More

### Services for existing Credit Card Customers

- [Credit Card Referral Program](#)
Image Hyperlink.

<!-- image -->
- [Credit Card Services](#)
Image Hyperlink.

<!-- image -->
- [Limit Enhancement](#)
Image Hyperlink.

<!-- image -->
- [Upgrade Credit Card](#)
Image Hyperlink.

<!-- image -->
- [Active Channel Partners](#)
Image Hyperlink.

<!-- image -->
- [HDFC Bank MyCards](#)
Image Hyperlink.

<!-- image -->
- [Loan on Credit Card](#)
Image Hyperlink.

<!-- image -->
- [Credit Card NetBanking](#)
Image Hyperlink.

<!-- image -->
- [Credit Card EMI Calculator](#)
Image Hyperlink.

<!-- image -->
- [Balance Transfer Calculator](#)
Image Hyperlink.

<!-- image -->
- [Credit Card Bill Payment](#)
Image Hyperlink.

<!-- image -->

[View More](#)

[View Less](#)

## 

Login

Know More

### Useful Credit Card Links

- [Active Channel Partners](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\List-of-Active-Digital-Channel-Partners.pdf)
Image Hyperlink.

<!-- image -->
- [Personal MITC](https://www.hdfcbank.com/personal/pay/cards/credit-cards/personal-mitc)
Image Hyperlink.

<!-- image -->
- [Purchase MITC](https://www.hdfcbank.com/personal/pay/cards/credit-cards/purchase-mitc)
Image Hyperlink.

<!-- image -->
- [Corporate MITC](https://www.hdfcbank.com/personal/pay/cards/credit-cards/corporate-mitc)
Image Hyperlink.

<!-- image -->
- [Credit Cards Policy](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\HDFC-Bank-Credit-Cards-Policy -Conditions-Ver-1-1st-July22.pdf)
Image Hyperlink.

<!-- image -->
- [DSA code of conduct](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\dsa_cc.pdf)
Image Hyperlink.

<!-- image -->
- [Fair practices code](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\fair_practice.pdf)
Image Hyperlink.

<!-- image -->
- [Transaction alerts](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\TransactionAlerts.pdf)
Image Hyperlink.

<!-- image -->
- [Statement Payment Related Info](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\statement_related_payment_info.pdf)
Image Hyperlink.

<!-- image -->
- [Retail Card Member Agreement](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\card-member-agreement-29-10-2019.pdf)
Image Hyperlink.

<!-- image -->
- [Priority Pass](https://www.prioritypass.com/)
Image Hyperlink.

<!-- image -->
- [Corporate Card Member Agreement](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Personal/Pay/Cards/Credit%20Card/Credit%20Card%20Landing%20Page/Credit%20Cards/Commercial/Cardmember-Agreement-Corp-Cards.pdf)
Image Hyperlink.

<!-- image -->
- [Contactless Cards](https://v.hdfcbank.com/htdocs/common/cardless-cash/index.html)
Image Hyperlink.

<!-- image -->
- [Chip+PIN Credit Card](https://www.hdfcbank.com/personal/pay/cards/credit-cards/chip-pin-credit-card)
Image Hyperlink.

<!-- image -->
- [Co-Brand Credit Card Revenue Sharing Disclosure](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Co-Brand-Credit-Card-Revenue-Sharing-disclosure.pdf)
Image Hyperlink.

<!-- image -->
- [Key Fact Statement- Purchase Card](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Commercial\KEY-FACT-STATEMENT%28Commercial-Cards%29.pdf)
Image Hyperlink.

<!-- image -->
- [Key Fact Statement- Corporate Card](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Commercial\KEY-FACT-STATEMENT-Corp-Card.pdf)
Image Hyperlink.

<!-- image -->
- [Commercial Card-Membership Kit](\personal\pay\cards\commercial-credit-cards\membership-kit)
Image Hyperlink.

<!-- image -->
- [MyRewards Program Terms &amp; Conditions](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\my-rewards-oct-17.pdf)
Image Hyperlink.

<!-- image -->

[View All](#)

## 

Login

Know More

### Tools &amp; Calculators

- [Credit Card EMI Calculator](\personal\pay\cards\credit-cards\credit-card-emi-calculator)
Image Hyperlink.

<!-- image -->
- [Credit Card Loan EMI Calculator](https://v.hdfcbank.com/htdocs/common/loancalculator/credit-card-emi-calculator.html)
Image Hyperlink.

<!-- image -->
- [Balance Transfer Calculator](\personal\tools-and-calculators\balance-transfer-calculator)
Image Hyperlink.

<!-- image -->
- [Active List of Digital Channel Partner - Credit Cards](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\List-of-Active-Digital-Channel-Partners.pdf)
Image Hyperlink.

<!-- image -->

[View All](\personal\tools-and-calculators)

## 

Login

Know More

### Stay Secure

#### [NetSafe](\personal\pay\stay-secure\netsafe)

[Protect real card information](\personal\pay\stay-secure\netsafe)

Image Hyperlink.

<!-- image -->

Nurturing your online business

## [in the current economy](\personal\resources\learning-centre\borrow\how-to-nurture-online-business-in-current-economy)

Learning Center Article Icon

<!-- image -->

[Apply Now](https://applyonline.hdfcbank.com/cards/credit-cards.html?utm_content=MKTG&mc_id=website_organic_dc&icid=website_organic_dc#nbb)

false

[Apply Now](https://applyonline.hdfcbank.com/cards/credit-cards.html?utm_content=MKTG&mc_id=website_organic_dc&icid=website_organic_dc#nbb)

false

false

false