# Source: https://www.hdfcbank.com/personal/pay/cards/credit-cards/diners-privilege

# Diners Club Privilege Credit  Card

Global Belonging, Ready For You.

For the global citizens who cherish the unexplored, savor the exotic. Elevate your joy with the HDFC Bank Diners Club Privilege Credit Card.

[**Click here**](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\Know-more-Privilege-Portfolio-Communication.pdf) **if card open date is before 15** **th** **June 23**

Diners Club Privilege Credit  Card

## All You Need To Know

- [Features](\personal\pay\cards\credit-cards\diners-privilege)
- [Eligibility](\personal\pay\cards\credit-cards\diners-privilege\eligibility)
- [Fees &amp; Charges](\personal\pay\cards\credit-cards\diners-privilege\fees-and-charges)

### [Features](\personal\pay\cards\credit-cards\diners-privilege)

## 

#### Key Features

Key Features

- 'Buy 1 Get 1 Free' on movie/non-movie weekend tickets via BookMyShow
- 5X Reward Points on Swiggy and Zomato
- Complimentary Annual Memberships of Swiggy One and Times Prime as Welcome Benefit
- ₹ 1,500 worth Marriott, Decathlon &amp; more vouchers on quarterly spends of Rs. 1.5 lakh
- 2 Complimentary Airport lounge access every calendar quarter worldwide
- 4 Reward Points for every ₹ 150 spent

## 

#### Additional Features

Additional Features

- Redeem reward points for higher value on the Exclusive Privilege Dining Catalogue. [Click here](https://offers.reward360.in/diners/rewards?cat=exclusive-diners-privilege) to redeem (or) follow these steps: Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7Cec97ed89b9114e80077908db79473696%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638237118988693881%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=jfbpScSLxeTFeKwgrFEWiEi9W4rup2%2BZzovTa6JlowA%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Exclusive Dining Catalogue'
- Travel benefits: Upto 10X Rewards on Booking flight tickets / stays across 150+ hotels (Domestic &amp; International) at https://offers.smartbuy.hdfcbank.com/diners
- Interest Free Credit Period: Up to 50 days of interest free credit period on your HDFC Bank Diners Club Privilege Credit Card from the date of purchase. (subject to the submission of the charge by the Merchant)
- Credit Liability Cover: Rs. 9 lakh
- Foreign Currency Markup: Nominal 3.5% on all your foreign currency spends. (These charges are billed on your subsequent statement within 60 days from date of visit. Currency conversion rate is applicable as on the date of settlement)
- Revolving Credit: Available at a nominal interest rate on your HDFC Bank Diners Club Privilege Credit Card. Please refer to Fees and Charges section to know more. [Click here](\personal\pay\cards\credit-cards\diners-privilege\fees-and-charges) to visit.

## 

#### Customer Care

Customer Care

HDFC Phone Banking: For any queries, call us on 1800 1600 / 1800 2600  (from 8 a.m. to 8p.m.) Customers travelling overseas can reach us at 022-  61606160

Smartbuy Concierge: Simply call on 1860 425 1188

## 

#### Lounge Access

Lounge Access

- 2 Complimentary Airport lounge access every calendar quarter worldwide
- Please [click here](https://lms.hoi.in/lounge-list/hdfc-diners-privilege) to view Domestic Lounges
- Please [click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\International-Lounge-List.pdf) to view International Lounges

## 

#### Welcome Benefits

Welcome Benefits

- Avail Complimentary Annual memberships of Swiggy One and Times Prime on spending Rs 75,000 within the first 90 days of card issuance.
- Easily track your milestone spends and redeem benefits by following these steps. Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7C72f5c55e0a9841315af408db970b83ec%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638269847931494165%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=BVQnjkRlw40x6zS8y3imSok0hY0IfFaahJpfh6TbQl4%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Diners Club Privilege Milestones' &gt;&gt; Check Welcome Benefits.
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\DNP-ProductFeature-TnC.pdf) for T &amp; C

## 

#### Dining &amp; Entertainment Benefits

Dining &amp; Entertainment Benefits

- 'Buy 1 Get 1 Free' on movie/non-movie weekend tickets via BookMyShow. Offer is applicable for shows on Friday, Saturday and Sunday (irrespective of booking day). Maximum discount is Rs. 250/ticket, upto 2 free tickets every calendar month
- 5X Reward Points on Swiggy and Zomato. Additional 4X RP is capped at 2500 reward points every calendar month
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\DNP-ProductFeature-TnC.pdf) for T &amp; C

## 

#### Milestone Benefit

Milestone Benefit

- Avail ₹ 1,500 worth vouchers of Marriott Experience or Decathlon or Barbeque Nation or O2 Spa or Lakme Salon on spends of Rs. 1.5 lakhs in a calendar quarter.
- Easily track your milestone spends and redeem benefits by following these steps. Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7C72f5c55e0a9841315af408db970b83ec%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638269847931494165%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=BVQnjkRlw40x6zS8y3imSok0hY0IfFaahJpfh6TbQl4%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Diners Club Privilege Milestones' &gt;&gt; Check Quarterly Benefits.
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Super Premium\Diners Club Privilege New\DNP-ProductFeature-TnC.pdf) for T &amp; C

## 

#### Renewal Offer

Renewal Offer

Renewal Fee waiver for next year on spends of Rs. 3 Lakhs in card anniversary year.

## 

#### Smart EMI (With logo)

Smart EMI (With logo)

HDFC Bank Diners Club Privilege Credit Card comes with an option to convert your big spends into EMI after purchase. To know more [click here](\personal\borrow\loan-against-assets\smartemi)

## 

#### Contactless Payment

Contactless Payment

The HDFC Bank Diners Club Privilege Credit Card is enabled for contactless payments on HDFC Bank POS machines, facilitating fast, convenient and secure payments at retail outlets.

*To see if your Card is contactless, look for contactless network symbol on your Card.

(Please note that in India, payment through contactless mode is allowed for a maximum of ₹5000 for a single transaction without the need to input your Credit Card PIN. However, if the amount is higher than or equal to ₹5000, the Card holder has to enter the Credit Card PIN for security reasons)

## 

#### Insurance/Comprehensive protection &amp; Nominee details for Insurance

Insurance/Comprehensive protection &amp; Nominee details for Insurance

- Air accident insurance cover worth ₹1crore($125,000)
- Emergency overseas hospitalization: up to ₹25 Lacs ($31,250)
- Travel Insurance Cover of up to ₹ 50,000 (up to $625) on baggage delay (Capped to 10$ per hour restricted to 8 hours)
- Credit Liability Cover of up to ₹ 9 Lakh
- [Click here](https://leads.hdfcbank.com/applications/webforms/apply/HDFC_NomineeDetails/Nominee.aspx) to update Nominee Details.
- [Click here](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\PDFs\Covers_Dinersaug.pdf) for Policy Details

## 

#### Reward Point/CashBack Redemption &amp; Validity

Reward Point/CashBack Redemption &amp; Validity

**Reward Points Accrual:**

- Earn 4 Reward Points on every Rs.150 retail* spends
- Earn 20 Reward Points on every Rs 150 spends on Swiggy and Zomato
- Earn upto 10X Reward Points on Spends Via Smartbuy

**Reward Point Redemption:**

You can redeem your Reward Points on Smartbuy or NetBanking.

Reward Points can be redeemed for:

- Flights and hotel bookings via Smartbuy at a value of 1 RP = Rs 0.5
- Exclusive Privilege Dining Catalogue on select Restaurants via Smartbuy at a value of 1 RP = Rs 0.50. [Click here](https://offers.reward360.in/diners/rewards?cat=exclusive-diners-privilege) to redeem (or) follow these steps: Visit [offers.smartbuy.hdfcbank.com/diners](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Foffers.smartbuy.hdfcbank.com%2Fdiners&data=05%7C01%7CEuroMoney%40hdfcbank.com%7Cec97ed89b9114e80077908db79473696%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C638237118988693881%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=jfbpScSLxeTFeKwgrFEWiEi9W4rup2%2BZzovTa6JlowA%3D&reserved=0) &gt;&gt; Click on 'Diners Club Benefits' tab &gt;&gt; Select 'Exclusive Dining Catalogue'
- Redeem Rewards Points on exclusive reward redemption catalogue for HDFC Bank Diners Club Privilege Credit Card 1 RP upto Rs 0.35
- Cashback at a value of 1 RP = Rs 0.20.
- Please [Click Here](\personal\pay\cards\credit-cards\personal-mitc) to know more

## 

#### Good food trail program

Good food trail program

- Good food Trail Program - HDFC Bank x Swiggy Dineout

Indulge in mouth-watering discounts! Pay with your HDFC Bank Credit Card and enjoy FLAT 10% EXTRA OFF* on dining bills at 35K+ restaurants! * - T&amp;C Apply. Please Click Here(embed &lt;https://tnc.dineout.co.in/hdfc\_tnc.html&gt;) to know more.

## 

#### Diners Exclusive Offers

Diners Exclusive Offers

- **Fast Track Airport Experience:** Skip the line for check-in and receive baggage assistance.
- **Dining Delight:** exclusive dining offers, from gourmet cuisine to local delicacies.
- **Luxury Spas:** access to some of the finest spas within India at special rates.
- **Small Medium Enterprise (SME):** tailor-made offers such as workspaces, business insurance and wellness discounts to meet business needs. To Know more [click here](https://dinersclub-offerplatform.com/)

### [Eligibility](\personal\pay\cards\credit-cards\diners-privilege\eligibility)

### [Fees &amp; Charges](\personal\pay\cards\credit-cards\diners-privilege\fees-and-charges)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Related Searches   | Related Searches                   | Related Searches   | Related Searches             |
|--------------------|------------------------------------|--------------------|------------------------------|
|                    | how to get a credit card           |                    | cibil score for credit card  |
|                    | how to choose the best credit card |                    | credit card offers           |
|                    | instant credit card                |                    | apply for credit card online |

## People Also Looked At

### Regalia Gold Credit Card

Regalia Gold Credit Card

Experience the Golden Side Of Life

### Millennia Credit Card

Millennia Credit Card

Best CashBack Credit Card

### Tata Neu Infinity HDFC Bank Credit Card

Tata Neu Infinity HDFC Bank Credit Card

Extraordinary Rewards. Ready for You.

### Related Videos

- [Know about Diners Club International](#)
Image Hyperlink.

<!-- image -->

[View More](#)

[View Less](#)

## 

Login

Know More

### Services for existing Credit Card Customers

- [Credit Card Referral Program](#)
Image Hyperlink.

<!-- image -->
- [Credit Card Services](#)
Image Hyperlink.

<!-- image -->
- [Limit Enhancement](#)
Image Hyperlink.

<!-- image -->
- [Upgrade Credit Card](#)
Image Hyperlink.

<!-- image -->
- [Active Channel Partners](#)
Image Hyperlink.

<!-- image -->
- [HDFC Bank MyCards](#)
Image Hyperlink.

<!-- image -->
- [Loan on Credit Card](#)
Image Hyperlink.

<!-- image -->
- [Credit Card NetBanking](#)
Image Hyperlink.

<!-- image -->
- [Credit Card EMI Calculator](#)
Image Hyperlink.

<!-- image -->
- [Balance Transfer Calculator](#)
Image Hyperlink.

<!-- image -->
- [Credit Card Bill Payment](#)
Image Hyperlink.

<!-- image -->

[View More](#)

[View Less](#)

## 

Login

Know More

### Useful Credit Card Links

- [Active Channel Partners](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\List-of-Active-Digital-Channel-Partners.pdf)
Image Hyperlink.

<!-- image -->
- [Personal MITC](https://www.hdfcbank.com/personal/pay/cards/credit-cards/personal-mitc)
Image Hyperlink.

<!-- image -->
- [Purchase MITC](https://www.hdfcbank.com/personal/pay/cards/credit-cards/purchase-mitc)
Image Hyperlink.

<!-- image -->
- [Corporate MITC](https://www.hdfcbank.com/personal/pay/cards/credit-cards/corporate-mitc)
Image Hyperlink.

<!-- image -->
- [Credit Cards Policy](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\HDFC-Bank-Credit-Cards-Policy -Conditions-Ver-1-1st-July22.pdf)
Image Hyperlink.

<!-- image -->
- [DSA code of conduct](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\dsa_cc.pdf)
Image Hyperlink.

<!-- image -->
- [Fair practices code](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\fair_practice.pdf)
Image Hyperlink.

<!-- image -->
- [Transaction alerts](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\TransactionAlerts.pdf)
Image Hyperlink.

<!-- image -->
- [Statement Payment Related Info](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\statement_related_payment_info.pdf)
Image Hyperlink.

<!-- image -->
- [Retail Card Member Agreement](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\card-member-agreement-29-10-2019.pdf)
Image Hyperlink.

<!-- image -->
- [Priority Pass](https://www.prioritypass.com/)
Image Hyperlink.

<!-- image -->
- [Corporate Card Member Agreement](https://www.hdfcbank.com/content/bbp/repositories/723fb80a-2dde-42a3-9793-7ae1be57c87f/?path=/Personal/Pay/Cards/Credit%20Card/Credit%20Card%20Landing%20Page/Credit%20Cards/Commercial/Cardmember-Agreement-Corp-Cards.pdf)
Image Hyperlink.

<!-- image -->
- [Contactless Cards](https://v.hdfcbank.com/htdocs/common/cardless-cash/index.html)
Image Hyperlink.

<!-- image -->
- [Chip+PIN Credit Card](https://www.hdfcbank.com/personal/pay/cards/credit-cards/chip-pin-credit-card)
Image Hyperlink.

<!-- image -->
- [Co-Brand Credit Card Revenue Sharing Disclosure](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Co-Brand-Credit-Card-Revenue-Sharing-disclosure.pdf)
Image Hyperlink.

<!-- image -->
- [Key Fact Statement- Purchase Card](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Commercial\KEY-FACT-STATEMENT%28Commercial-Cards%29.pdf)
Image Hyperlink.

<!-- image -->
- [Key Fact Statement- Corporate Card](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\Credit Cards\Commercial\KEY-FACT-STATEMENT-Corp-Card.pdf)
Image Hyperlink.

<!-- image -->
- [Commercial Card-Membership Kit](\personal\pay\cards\commercial-credit-cards\membership-kit)
Image Hyperlink.

<!-- image -->
- [MyRewards Program Terms &amp; Conditions](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\my-rewards-oct-17.pdf)
Image Hyperlink.

<!-- image -->

[View All](#)

## 

Login

Know More

### Tools &amp; Calculators

- [Credit Card EMI Calculator](\personal\pay\cards\credit-cards\credit-card-emi-calculator)
Image Hyperlink.

<!-- image -->
- [Credit Card Loan EMI Calculator](https://v.hdfcbank.com/htdocs/common/loancalculator/credit-card-emi-calculator.html)
Image Hyperlink.

<!-- image -->
- [Balance Transfer Calculator](\personal\tools-and-calculators\balance-transfer-calculator)
Image Hyperlink.

<!-- image -->
- [Active List of Digital Channel Partner - Credit Cards](\Personal\Pay\Cards\Credit Card\Credit Card Landing Page\List-of-Active-Digital-Channel-Partners.pdf)
Image Hyperlink.

<!-- image -->

[View All](\personal\tools-and-calculators)

## 

Login

Know More

### Stay Secure

#### [NetSafe](\personal\pay\stay-secure\netsafe)

[Protect real card information](\personal\pay\stay-secure\netsafe)

Image Hyperlink.

<!-- image -->

Nurturing your online business

## [in the current economy](\personal\resources\learning-centre\borrow\how-to-nurture-online-business-in-current-economy)

Learning Center Article Icon

<!-- image -->

[Apply Now](https://applyonline.hdfcbank.com/cards/credit-cards.html?utm_content=MKTG&mc_id=website_organic_dc&icid=website_organic_dc#nbb)

false

[Apply Now](https://applyonline.hdfcbank.com/cards/credit-cards.html?utm_content=MKTG&mc_id=website_organic_dc&icid=website_organic_dc#nbb)

false

false

false

---

# Source: C:\Users\Abhishek244642\Documents\Creditllm\HDFC\DinersClubPrivilegeCreditCard\diners_t&c.pdf

## HDFC Bank Diners Club Privilege Credit Card Terms and Conditions

## Section A: Product Features

Offer is applicable for shows on Friday, Saturday and Sunday. Maximum discount is Rs.

1. Entertainment Benefits: 'Buy One Get Free' on BookMyShow 250/ticket, upto 2 free tickets every calendar month

## How to avail?

- On 'www.bookmyshow.com'/BookMyShow App, upon reaching the payment page, click on 'Unlock offers or Apply Promocodes' → Click on 'Offer Code Credit/ Debit/ Netbanking' → Select 'HDFC Bank Diners Club Privilege Credit Card' → Enter the card number to validate → After this stage the website/app will recognize the eligible card, reduce the bill amount → You may then proceed to make the payment on HDFC Bank Diners Club Privilege Credit Card
- No coupon code is required
- In case the discount is applied but the transaction doesn't go through for some reason, wait for 20 minutes before trying to avail the discount again

## Terms and Conditions:

- Offer is applicable for bookings via BookMyShow website and mobile app
- Offer is valid on purchase of minimum 2 tickets
- Maximum discount which can be availed is Rs. 250 per ticket and up to 2 free tickets per calendar month
- Offer is valid for shows on Friday/Saturday/Sunday (irrespective of booking day)
- Offer is valid on Movies, Events, Concerts, Plays, Sports &amp; Activities, Excluding BMS Stream &amp; F&amp;B
- Offer is not applicable on purchase of Gift Cards.
- Offer discount is applicable on ticket cost only and customers availing the offer will have to pay internet handling fee and/or any other charges as levied on each ticket.
- Offer is valid only for users coming directly to the BookMyShow website and mobile app not via individual cinema sites
- Offer cannot be combined with any other offer/winpin/discount on BookMyShow
- Tickets once bought online, shall be considered sold and cannot be cancelled, refunded or exchanged.
- Transactions with offer discount applied are not eligible for cancellation or refund.
- Once the booking is committed, the confirmation mail/SMS received from BookMyShow needs to be exchanged with the ticket available at the theatre
- Cardholders shall not be entitled to compensation / benefits in any form whatsoever in lieu of the offer being availed

HDFC Bank/Credit Cards/Diners Club Privilege/Features-TnC/ 06-23

- BookMyShow &amp; HDFC BANK LIMITED reserves the right to disqualify any cardholder/s from the benefits of the program. If case of any fraudulent activity, prosecution will be carried according to the purpose of availing the benefits under the program
- BookMyShow &amp; HDFC BANK LIMITED reserves the right to modify/change all or any of the terms applicable to the program without assigning any reasons or without any prior intimation.
- BookMyShow &amp; HDFC BANK LIMITED  also reserves the right to discontinue the program without assigning any reasons or without any prior intimation whatsoever
- Individual cinema rules are applicable
- In addition to the above, this offer on the website is also subject to BookMyShow's general Terms of Use. Kindly refer to BookMyShow's Terms &amp; Conditions on the homepage.
- In case of any disputes, BookMyShow's decision will be final

## 2. 5X Rewards on Swiggy and Zomato:

- Earn 5X Reward Points i.e. 20 reward points for every Rs. 150 spent on Swiggy, Zomato
- 16 reward points (4X) for every Rs. 150 spend on Swiggy &amp; Zomato is capped at 2500 reward points  per calendar month across both merchants combined. 4 reward points for every 150 spend  on Swiggy, Zomato will continue as is without any capping
- Minimum transaction value to be eligible for reward points is Rs. 150
- Only transactions settled from the merchant will be eligible for Reward Points accrual
- Transactions settled/posted during a calendar month will be considered for calculating accelerated reward points accrual in that month, maximum accelerated reward point accrual can be 2500 per calendar month
- For spends made under the 5X rewards eligible transactions, the incremental reward points (i.e. 4X points) shall be credited to the customer's card account in the 1st week of the subsequent calendar month.
- Transactions qualify to earn 5X rewards under this feature is based on: Merchant description: Swiggy/ Zomato (AND) MCC: 5411/ 5499/ 5811/ 5812/ 5814 (or)
- Terminal / merchant IDs (TIDs &amp; MIDs) shared by the respective merchant partners
- If the transaction does not meet the stated condition, it will not qualify for the benefit
- Reversal transactions, if any, shall be considered for the calculation of net spends and monthly cap in the calendar month in which reversal transaction is posted. Therefore, the accelerated reward points deducted on the reversal transaction could be different from the reward points earned for the original purchase transaction.
- The offer cannot be clubbed with any other promotions currently applicable
- To be eligible for the offer, payment has to be done directly using HDFC Bank Diners Privilege Credit Card. Any wallet payments will not be eligible even if wallet is refilled using HDFC Bank Diners Privilege Credit Card.

3. Welcome Benefits: Complimentary Annual Memberships of Swiggy One &amp; Times Prime on achieving net retail spends of Rs 75,000 within 90 days of card issuance

## How to track/avail ?

- Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club Privilege Milestones
- In Welcome Benefits section, choose the membership to download
- Click on ' Generate Voucher code '
- Voucher code/ Gift card details will be sent to your registered Email ID also

## Terms and Conditions

- Welcome Benefit Period is defined as 90 days from card issuance or last upgrade/downgrade date. For ex: if your card issuance/upgrade/downgrade date is 01st January, Welcome Benefit Period will be 1st Jan to 31st March and so on
- Both memberships will be unlocked on achievement of benefits criteria
- Benefits will be unlocked within 48 hours on achievement of benefits criteria
- Once the benefit is unlocked, cardholder can download the memberships within 90 days from the end of the Welcome Benefit Period (As quoted in the example: 31st March + 90 days i.e. 28 June)
- The benefits will be communicated to your HDFC bank registered Email ID within 24-48 hours of download of voucher
- Membership validity will be mentioned in the communication received on email
- Membership validity cannot be extended post expiry. For detailed brand specific T&amp;C, refer section B
- Memberships redemption need to be done at respective website/portal depending on the brand/ Merchant.
- Memberships can be resent to registered email ID through 'Manage Order' section in Smartbuy (https://offers.smartbuy.hdfcbank.com/diners). The resent voucher will have the same validity as the original communication.
- Cardholder can view their downloaded benefits under 'Track Benefits' section in Smartbuy
- In case of any cancellation, refund or reversal of transaction. The spend aggregation &amp; transaction count for the Welcome benefits will also be reversed / adjusted.
- Transactions are tracked as per the posted/settled date from third party/merchant to the bank and the posting/settlement date will be considered as contribution to the spend accrual
4. Quarterly Milestone: Choose any one Rs. 1500 voucher from Marriott, Decathlon, Barbeque Nation, O2 Spa or Lakme Salon upon net spends of Rs. 1,50,000 or more in a calendar quarter

## How to track/avail ?

- Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits →
- Diners Club Privilege Milestones
- In Quarterly Benefits section, choose the brand voucher to download

- Click on ' Generate Voucher code '
- Voucher code/ Gift card details will be sent to your registered Email ID also

## Terms and Conditions

- Calendar quarter is defined as Jan -Mar; Apr -Jun; Jul -Sep; Oct -Dec.
- Benefits will be unlocked within 48 hours on achievement of quarterly spends milestone.
- Once the benefit is unlocked, cardholder can download the voucher / benefits within 90 days from the end of that qualifying quarter.
- Example:  Cardholder qualifies for Jan-Mar quarterly milestone on Feb 1st, then the benefit module will be unlocked and available for download from Feb 3rd till 30 Jun'22 (90 days from 31st March)
- Select any one brand voucher. Only a single voucher of the selected brand with value Rs. 1500 will be shared
- The benefits will be communicated on your HDFC bank registered Email ID within 24 hours of download of voucher.
- Voucher validity will be mentioned in the communication, post which the benefits expire. Voucher validity cannot be extended post expiry. For detailed brand specific T&amp;C, refer section B
- Voucher redemption need to be done at store / online depending on the brand of choice of the cardholder
- Vouchers can b e resent to registered email ID through 'Manage Order' section in Unified Smartbuy Portal
- Cardholder can view their downloaded benefits under 'Track Benefits' section in Unified Smartbuy Portal
- In case of any cancellation, refund or reversal of transaction. The spends aggregation for the milestone benefits will also be reversed / adjusted.
- Transactions are tracked as per the posted/settled date from third party/merchant to the bank and the posting/settlement date will be considered as contribution to the spend accrual for any quarter.

## Section B: Brand/ Merchant T &amp; C

## Times Prime Now Membership

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher.

Voucher Value:

Annual membership

## How to Avail?

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club
- Privilege Milestones
- -In Welcome Benefits section, Choose Times Prime  as brand to download
- -Generate Voucher code
- -Voucher code/ Gift card details will be sent to your registered Email ID also

## How can customers activate their membership?

- -Download the app from playstore/app store
- -Enter the voucher/ e-code while signing up
- -Your membership is activated
- -Now activate the offers and enjoy your membership

## How to activate the offers?

- -Login to your account on the app.
- -Click on the preferred brand benefit, explore and activate the offer as per steps.
- -Enjoy the benefit on partner app.

## Terms and Conditions

- -The membership starts from the day the consumer activates to his/her Times Prime membership.
- -The voucher / e-code is applicable once per user.
- -For existing Times Prime members, a new membership will be added to his/her account
- -and will begin after their current membership expires.
- -In case of any issues related to the redemption of the e-code, please contact: support@timesprime.com
- -Times Prime reserves the right to terminate, modify, extend the timelines and features, at any time at its absolute discretion.
- -The offers/memberships must be unlocked within the Times Prime Membership period.
- -All Times Prime terms and conditions (as mentioned in the T&amp;Cs on https://www.timesprime.com/terms-and-conditions) are applicable to the membership availed under this offer

## Swiggy One Membership

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher

Voucher Value:

Annual membership

## How to Avail ?

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club Privilege Milestones
- -In Welcome Benefits section, Choose Swiggy One as brand to download
- -Generate Voucher code
- -Voucher code/ Gift card details will be sent to your registered Email ID also.

## How can customers activate their membership?

- -Download the app 'Swiggy' from playstore/app store
- -Click on "One Membership" icon on the Swiggy app
- -Enter coupon code and click "Apply"
- -User will get a confirmation pop up on the screen once the coupon is applied successfully\
- -Click on "Buy Swiggy One"

## Terms and Conditions:

- Swiggy One membership can be used only on 2 devices at a time.
- The flat Rs 150 off through the use of code "ONE150" on Dineout is applicable on a minimum order value of Rs 1500.
- The free delivery is applicable on all food delivery restaurants within 10kms from the user's location except for Dominos. The extra 30% member only discount is applicable on select food delivery restaurants.

## Marriott Experience Voucher

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher.

Voucher Value:

Rs 1,500 only

How to Avail ?

## For New User

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club Privilege Milestones
- -In Quarterly Benefits section, Choose Marriott Experience Voucher as brand to download
- -Click on the 'Generate Voucher' button.
- -Cardholder will receive the Voucher code on bank registered Email id.
- -Download the Club Marriott South Asia App from the App Store or Play Store. Enter the Voucher Code while signing up on the App.
- -On successful sign up, Cardholder will receive welcome Email and SMS.

- -On the App home screen, tap on the 'Your Experience Certificates' tab. Or, the Cardholder may tap on 'Membership' tab in the navigation and on the next screens taps on 'Experience Certificates' tab.
- -The Cardholder will see certificates with face value of INR 1500
- -Cardholder taps on the certificate and 2 options are displayed i.e., Redeem or Gift.

## Redemption of Marriott Experience Certificates:

- -Cardholder taps on 'Redeem'
- -Selects the Outlet
- -Agrees to the T&amp;Cs
- -Taps on 'Proceed to Redeem'
- -Taps on 'Got It' on the pop up displayed
- -Enters the OTP and taps on 'Confirm'
- -The Marriott Experience Certificate will thus be redeemed

## Gifting of Marriott Experience Certificates

- -User taps on 'Gift' and then taps on 'Proceed to Gift'.
- -Enters the Giftee's First Name, Last Name, Email and Mobile number.
- -Adds a message or a video with the gift.
- -Goes through OTP authentication and confirms.
- -The Marriott Experience Certificate will thus be gifted

## For Existing Club Marriott South Asia App User

- -Cardholder opens the Club Marriott South Asia App.
- -Taps on the 'Membership' tab in the navigation.
- -Enters the Voucher Code in the tab named 'Enter Code to Receive Benefit'.
- -Post successful Voucher Code validation, Marriott Experience Certificates can be viewed in the tab name d 'Experience Certificates' on the same membership page.
- -The Cardholder will see certificates with face value of INR 1500
- -Cardholder taps on the certificate and 2 CTAs are displayed i.e., Redeem or Gift.
- -Redemption of Marriott Experience Certificates
- -Cardh older taps on 'Redeem'.
- -Selects the Outlet.
- -Agrees to the T&amp;Cs.
- -Taps on Proceed to Redeem.
- -Taps on 'Got It' on the pop up displayed.
- -Enters the OTP and taps on 'Confirm'.
- -The Marriott Experience Certificate will thus be redeemed

## Terms and Conditions

- -The Marriott Hotels Gift Card is issued by Pine Labs Private Limited ('Pine Labs') under the Brand Name of Qwikcilver.
- -This Gift Card may be applied to eligible purchases at participating Marriott hotels in India. For a list of participating hotels please refer: https://www.qwikcilver.com/terms-andconditions/marriott-hotels

HDFC Bank/Credit Cards/Diners Club Privilege/Features-TnC/ 06-23

- -Gift Card cannot be used outside of India.
- -The experience voucher can be redeemed at participating Club Marriott hotels through the Club Marriott South Asia App and are applicable for use on regular rates of dining, stay and spa (and not on discounted rates)
- -Eligible purchases do not include advanced purchases, deposits, friends and family rates, payments for meetings, catering or group functions, negotiated rates (including volume, group, contracted, or other rates that have been previously negotiated and agreed in writing whether paid on a group or individual basis), and goods/services purchased through or provided by third parties, such as online or off-line travel agents. All other purchases made at participating Marriott hotels in India are eligible. Use of this Gift Card constitutes acceptance of terms. Certain purchases (e.g., hotel stays) may have a minimum age requirement. Subject to these terms, the Gift Card can be redeemed at hotel-operated restaurants, spa, salon or other services provided directly by participating hotel.
- -Each Gift Card shall be single use and only one transaction can be performed on Gift Card. Partial redemption of a Gift Card shall not be possible.
- -The Gift Card balance is only valid for as mentioned in the Email received on redeeming the voucher. Gift Card may not be reloaded.
- -If the purchase value exceeds the value of the Gift Card, the differential value should be paid by the customer who redeems the Gift Card.
- -Valid Gift Card in its original form (email) has to be presented at the time of availment. Gift Card is issued in Indian Rupees.
- -No fees or charges apply to Gift Cards.
- -This Gift Card cannot be transferred for balance value or redeemed for cash.
- -No replacement / compensation is permissible/ payable for lost /stolen or damaged Gift Card.
- -Gift Card and these terms are governed by the laws of India. Any dispute relating to the Gift Card shall be subject to the exclusive jurisdiction of courts at Bangalore. Marriott and related marks are trademarks of Marriott International Corporation or its affiliates.
- -Marriott reserves the right to institute additional security and verification procedures at the time of card redemption for fraud prevention. Marriott and/or Pine Labs reserve the entitlement to amend these terms and conditions from time to time.
- -For complete Terms and Conditions, please visit [https://www.qwikcilver.com/terms-andconditions/marriott-hotels] and for Check Balance Enquiries the consumers are invited to refer to [ https://www.woohoo.in/balenq]. Gift Cards issued by Pine Labs Private Limited. All rights reserved.
- -Please refer the Customer Grievance policy for dispute resolution, unauthorized transactions and liability related aspects at [ https://www.qwikcilver.com/grievance-policy/].
- -There will be no revalidation/ extension of the expired gift card.

## Decathlon Voucher

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher.

Voucher Value:

Rs 1,500 only

## How to Avail?

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club Privilege Milestones
- -In ' Quarterly Benefit ' section, Choose Decathlon Voucher as brand to download
- -Click on the 'Generate Voucher' button.
- -Cardholder will receive the Voucher code on bank registered Email id.

## For Retail Outlet (Offline):

- -Proceed to the Billing Counter at the decathlon Store and show the number of the Gift Card to avail the payment option.
- -If cart value is higher than gift card value, balance amount to be paid via HDFC Bank Diners Club Privilege Credit Card

## For Website (Online):

- -Log into to decathalon.in and add the products that you need
- -Proceed to Paymen t screen and choose the option ' Have a Gift Card'
- -Enter the Gift Card no and the Pin code specific to the particular card
- -If cart value is higher than gift card value, balance amount to be paid via HDFC Bank Diners Club Privilege Credit Card

## Terms and Conditions

- -Voucher can be redeemed at Decathlon Retail Outlets and website
- -This Gift voucher shall have a validity period as mentioned in the Email received on download of voucher
- -Voucher/ Gift card can be used for multiple transactions.
- -If the Invoice value is above voucher value, then the balance amount can be paid through debit/credit card/net banking.
- -Shipping charges will be applied as per the standard charges or promotions on the website at the time of redemption
- -Voucher/ Gift Card is non refundable or cannot be exchanged for cash

## Barbeque Nation Voucher

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher.

Voucher Value:

Rs 1,500 only

## How to Avail ?

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Privilege Milestones
- Diners Club
- -In 'Quarterly Benefit' section, Choose Barbecue Nation Voucher as brand to download
- -Click on the 'Generate Voucher' button.
- -Cardholder will receive the Voucher code on bank registered Email id.
- -Visit the nearest Barbeque Nation outlet.
- -Inform the cashier about the Gift Card before ordering food.
- -Show the Gift Card details to the cashier at the time of billing &amp; pay any balance amount by card

## Terms and Conditions

- -This Voucher has been powered by Pinelabs on behalf of Barbeque Nation
- -The guest should present the voucher to the restaurant concierge, at the time of entry, for a seamless experience
- -This voucher does not imply confirmation of booking. Prior booking through Barbeque Nation App/Web is required for a hassle free experience
- -The voucher is applicable for Dine-in only
- -The voucher shall have a validity period as mentioned in the Email received on download of voucher
- -The guest is advised to retain the voucher details safely and share the Voucher code responsibly. The bearer of the voucher shall be considered as the owner of the voucher
- -The Voucher is valid for one-time redemption only. Any voucher which is found redeemed will not be accepted
- -Voucher is non-refundable.
- -If the bill exceeds the voucher value, additional amount needs to be paid by the guest
- -Guest will not be entitled for any cashback/refund in case the bill value is less than the voucher value
- -Voucher is valid in all PAN India restaurants. For the list of restaurants please visit www.barbequenation.com/restaurants
- -Voucher will not be valid on 26th January'23, 15th August'23, 20th to 24th October'23, 25th December'23, 31st December'23 and 1st January'24
- -Maximum 5 vouchers applicable in single bill
- -Barbeque Nation Management reserves the right to identify the authenticity of the voucher in case of any dispute.
- -The restaurant reserves Right to Admission
- -Government Taxes and Services Charge as applicable
- -In case restaurant is non-operational due to government restrictions, political unrest, structural safety precautions etc. the guest is requested to make alternate bookings.
- -For any issues, please contact https://www.barbequenation.com/contact-us

## Lakme Salon Voucher

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher.

Voucher Value:

Rs 1,500 only

## How to Avail ?

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club Privilege Milestones
- -In 'Quarterly Benefit' section, Choose Lakme Salon Voucher as brand to download
- -Click on the 'Generate Voucher' button.
- -Cardholder will receive the Voucher code on bank registered Email id.
- -Visit the nearest Lakme Salon outlet.
- -Inform the cashier about the Gift Card before availing the service.
- -Show the Gift Card details to the cashier at the time of billing &amp; pay any balance amount by card

## Terms and Conditions

- -Lakme Salon Voucher /E-Gift Card is issued by Lakme Lever Pvt. Ltd (LLPL).
- -This Voucher /E- Gift Card can be redeemed only once and should be redeemed in full.
- -This Voucher /E-Gift Card is valid and can be redeemed against services as well as products at all salons of Lakme Salon Network.
- -The Voucher /E-Gift Card holder/(s) under no circumstances, will be paid cash or cheque in exchange for whole or part of the e-gfit card.
- -If the purchase amount is more than your Gift card value, you may compliment that purchase in any form of payment accepted by Lakme Salon outlets.
- -This gift card will not be accepted or redeemed after the expiry date.
- -LLPL and Ltd does not take any responsibility of and will not be liable for any replacement or compensation in case of any mishandling of this E-Gift Card.
- -Only valid Voucher /E-Gift Cards at the sole discretion of LLPL shall be accepted for redemption.
- -LLPL reserves the right to amend the Terms and Conditions at its own discretion without prior Notice. Any dispute shall the be referred to LLPL and the decision of LLPL will be final. Subject to the foregoing, these terms and conditions shall be subject to the jurisdiction of courts at Mumbai.
- -To locate your nearest Lakme Salon, log on to http://www.lakmeindia.com

## O2 Spa Voucher

Voucher Validity:

Will be mentioned in the Email received on downloading the Voucher.

Voucher Value:

Rs 1,500 only

## How to Avail ?

- -Visit Diners Club Privilege Smartbuy Milestone Page: https://offers.smartbuy.hdfcbank.com/diners → Diners Club Benefits → Diners Club Privilege Milestones
- -In 'Quarterly Benefit' section, Choose O2 Spa Voucher as brand to download

HDFC Bank/Credit Cards/Diners Club Privilege/Features-TnC/ 06-23

- -Click on the 'Generate Voucher' button.
- -Cardholder will receive the Voucher code on bank registered Email id.
- -Customer calls the call centre to fix an appointment, customer care: 9247020202
- -Selects outlet to avail service and informs the executive about making payment using gift card
- -Executive checks with the outlet on acceptance of gift card and confirms booking
- -Customer visits the outlets and selects offered service / product
- -Store executive prepares the final invoice and informs payable amount to the customer, customer intends to make payment using gift card
- -The store manager opens the web based single page redemption link
- -Enters gift card credentials and other required fields
- -Post validation, system confirms available value in the card and gets the card redeemed
- -Customer needs to pay by other mode if the invoice value exceeds redemption amount

## Terms and Conditions

- -The gift card is not a legal tender or replacement of credit / debit card
- -This card cannot be exchanged for cash or cheque
- -Every card has a validity period, please check the same before using at O2spa outlets.
- -Gift Card Validity is as mentioned in the Email received on download of voucher
- -The holder of this card is deemed to be the beneficiary
- -This Gift Card is valid across O2Spa, please check the outlet list: https://www.odespa.com/
- -Maximum of five gift cards can be redeemed against single invoice
- -No replacement or compensation is permissible for lost or mutilated or defaced Gift Card
- -Any dispute should be referred to O2SPA SALON PVT LTD head office and the decision of the company shall be final
- -Subject to the foregoing, these terms and conditions shall be subject to the jurisdiction of courts at Secunderabad / Hyderabad, India
- -Not applicable on return/refund /cancelled orders (if applicable)
- -Any redemption issues related queries customer needs to get in touch with O2Spa Salon customer care on 9247020202

## Section C: Generic Terms and Conditions

- Transactions are tracked as per the posted/settled date from third party/merchant to the bank and the posting/settlement date will be considered as contribution to the spend accrual for any month.
- Reward Points shall not be eligible for the following spends on the card,
- o Fuel Spends
- o Cash Advances
- o Payment of Outstanding Balances
- o Payment of card fees and other charges
- o Smart EMI / Dial an EMI transaction
- HDFC Bank Cardholders are not bound in any way to participate in this offer. Any participation is voluntary, and the offer is being made purely on a 'best effort' basis.
- All offers are non-cashable, not extendable, and non-negotiable
- All Offers shall be subject to all applicable laws, rules and regulations which are in existence, and which may be promulgated anytime by any statutory authority
- HDFC Bank is not making these offers and neither warrant nor guarantees the delivery, quality, merchantability or suitability of products/services availed of by the HDFC Bank Credit Card members under this offer and the member shall be solely responsible for all effects and consequences therefrom
- Any disputes as regards delivery, quality, warranty, merchantability or suitability of products/services availed of under this offer must be strictly addressed by the HDFC Bank Credit Card members in writing to Merchant/ Brand directly and HDFC Bank will not entertain any communication in this regard
- HDFC Bank shall not be liable for any loss or damage whatsoever or for any personal injury that may be suffered, by a HDFC Bank Credit Card member, directly or indirectly, by use or non-use of products/services availed of under this offer
- HDFC Bank reserves the right, at any time, without prior notice and without assigning any reason whatsoever, to add/alter/modify/change or vary all of these terms and conditions or to replace, wholly or in part, this offer by another offer, whether similar to this offer or not, or to extend or withdraw it altogether
- Above offers is by way of a special offer for select HDFC Bank Credit Card members only and nothing contained herein shall prejudice or affect the terms and conditions of the card member agreement. The terms of the above offers shall be in addition to and not in derogation of the terms contained in the Card Members Agreement.
- All disputes pertaining to Credit Cards, if any, arising out of or in connection with or as a result of above offers or otherwise relating hereto shall be subject to the exclusive jurisdiction of the competent courts / tribunals in Chennai only, irrespective of whether courts / tribunals in other areas have concurrent or similar jurisdiction.
- HDFC Bank reserves the right to debit reward points from customer's card account at any time in case of cancelations/ reversal of transaction for which reward points were credited earlier. In case sufficient reward points are not available, corresponding Rupee value will be charged to the card and will be payable by customer as per the credit card agreement

---
