from docling.document_converter import DocumentConverter
import os
import re
import json
import requests




def clean_docling_doc(result):
    """
    Cleans the Docling document:
      - Removes headers/footers
      - Sorts elements by page and vertical position
      - Returns Markdown
    """
    doc_dict = result.document.export_to_dict()

    # Step 1: Remove footer/header
    filtered_elements = [
        block for block in doc_dict.get("elements", [])
        if block.get("category") not in ("footer", "header")
    ]

    # Step 2: Sort blocks by page + vertical position
    sorted_elements = sorted(
        filtered_elements,
        key=lambda b: (b.get("page", 0), b.get("bbox", [0, 0, 0, 0])[1])
    )

    doc_dict["elements"] = sorted_elements

    # Step 3: Overwrite internal dict and re-export
    result.document._doc_dict = doc_dict  # ⚠ private attr
    return result.document.export_to_markdown()


def safe_filename(url_or_path: str) -> str:
    """
    Create a safe filename based on PDF filename or webpage URL.
    """
    base = os.path.basename(url_or_path)
    if base.lower().endswith(".pdf"):
        name = os.path.splitext(base)[0]
    else:
        # For web pages: use domain + path (sanitized)
        name = re.sub(r"[^a-zA-Z0-9_-]", "_", url_or_path)
    return name[:80]  # truncate if too long


def process_sources(sources, output_dir="outputs", combined_file="combined.md"):
    """
    Process multiple sources (PDFs or web URLs) using Docling.
    Generates individual Markdown files + one combined file.
    """
    os.makedirs(output_dir, exist_ok=True)
    converter = DocumentConverter()
    combined_markdown_parts = []

    for source in sources:
        try:
            print(f"📄 Processing: {source}")
            result = converter.convert(source)
            markdown_text = clean_docling_doc(result)

            fname = safe_filename(source) + "2.md"
            fpath = os.path.join(output_dir, fname)

            with open(fpath, "w", encoding="utf-8") as f:
                f.write(markdown_text)

            print(f"✅ Saved {fpath}")

            combined_markdown_parts.append(f"# Source: {source}\n\n{markdown_text}\n\n---\n")

        except Exception as e:
            print(f"❌ Error processing {source}: {e}")

    # Save combined markdown
    combined_path = os.path.join(output_dir, combined_file)
    with open(combined_path, "w", encoding="utf-8") as f:
        f.write("\n".join(combined_markdown_parts))

    print(f"📚 Combined Markdown saved as {combined_path}")


if __name__ == "__main__":
    sources = [
        "https://www.sbicard.com/en/personal/credit-cards/rewards/cashback-sbi-card.page",
        "https://www.sbicard.com/en/faq/cashback-sbi-card-faq.page",
        "https://www.sbicard.com/sbi-card-en/assets/docs/pdf/personal/credit-cards/lifestyle/sbi-signature-contactless-card/Signature%20Contactless%20FAQ.pdf",
        "https://www.sbicard.com/en/most-important-terms-and-conditions.page",  # webpages
        r"C:\Users\Abhishek244642\Documents\Creditllm\SBI\SBI CASHBACK CREDITCARD\cashback-card-brochure.pdf",
        r"C:\Users\Abhishek244642\Documents\Creditllm\SBI\SBI CASHBACK CREDITCARD\cashback-tnc-booklet.pdf"
]       
    process_sources(sources)
