## Contactless Credit Card FAQs

## 1. What is a Contactless Credit Card?

Contactless Credit Card powered by VISA payWave/RuPay Contactless is a fast and convenient way to pay for every day purchases. It is a secure, contactless chip technology designed to help you spend less time at the cash register and give you the freedom to do the things that matter most to you.

## 2. How does the Contactless Credit Card work?

Step 1: Look for the VISA payWave/RuPay Contactless mark and contactless logo at the point of sale. Step 2: The cashier enters your purchase amount into the terminal. This amount will be displayed on the contactless reader.

Step 3: Hold your card over the reader or at the POS at close range (less than 4 cm from where the contactless logo appears).

Step 4: Four green indicator lights or a beep sound will also be displayed on the screen indicating the transaction is complete. No PIN is required.

indicate that the transaction is complete. A message will Please note that payment through contactless mode is allowed for a maximum of ` 5,000 for a single transaction.

<!-- image -->

## 3. What are the benefits?

Contactless payment functionality powered by VISA payWave/RuPay Contactless is specially designed for you for speed, convenience and security. There's no dipping, swiping, entering PIN or fumbling for cash. You're ready to go in just a few seconds. Ideal for places like fast-food joints, petrol stations, movie theatres etc. During a contactless transaction the card never leaves your hand. This greatly reduces the risk of card loss and fraud through counterfeit/skimming. unique code for every VISA payWave/RuPay Contactless

A VISA payWave/RuPay Contactless card has its own, unique, built-in, secret key, which is used to generate a transaction, thus making it more secure. You don't need to look for cash/coins for small ticket everyday purchases. It is also easier to keep track of these expenses.

## 4. Is there a limit for a contactless transaction amount? Can I set my own Limit?

Payment through the contactless mode is allowed for a

<!-- image -->

maximum of ` 5,000 for a single transaction. For a contactless transaction PIN is not required. This limit is common for all customers and setting up of individual limits is not possible. Any transaction amount more than ` 5,000 has to be carried out through a contact transaction (Dip or Swipe) and entering the PIN. You can also choose to do a contact transaction (Dip or Swipe) with PIN for transactions amount below ` 5,000.

5. Where can I use my Contactless Credit Card? You can look for the Universal Contactless symbol at the POS machine at merchant outlets. Also please visit www.sbicard.com for details of  merchants enabled for VISA payWave/RuPay Contactless payment acceptance.
6. Can I use my Contactless Credit Card at other merchants (not enabled for contactless payment acceptance) as well? Yes, for the merchants not enabled for contactless payment acceptance, you can use this card for a normal dip or swipe transaction.
7. Could I be debited twice if I have more than one contactless card? No, contactless readers communicate with one card at a time. If the shop's reader finds more than one contactless card in your wallet or purse, you will be asked to select one card to pay.
8. Could I unknowingly have made a purchase if I walk past the reader? No, your card has to be waved within 4cm of the card reader for more than half a second and the retailer must enter the amount for you to approve. Terminals can only process one payment transaction at a time, therefore reducing transaction errors.
9. Is there any difference in the process for ATM and Internet transactions for this contactless Credit Card? There is no difference in transaction process for ATM or any Card not Present Transactions including Internet transactions. For ATM transactions you need to enter the PIN and for Internet transaction you need to enter your 3D secure PIN or OTP.
10. What happens if my contactless card is stolen - can it be misused?

Immediately report the loss of your Credit Card to SBI Card to prevent any misuse. Please call our helpline or visit SBI Card App / Website to block your credit card. Safeguards are in place to mitigate misuse of lost or stolen card by fraudster. The limit for Contactless Card transaction  without entering the PIN is ` 5,000, above which the transaction needs PIN for authorization. Please note that your maximum liability on any given date will be limited to available credit limit on your card.

<!-- image -->