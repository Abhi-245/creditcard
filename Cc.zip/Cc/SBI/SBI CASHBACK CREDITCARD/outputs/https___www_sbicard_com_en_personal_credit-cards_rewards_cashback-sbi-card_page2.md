# CASHBACK SBI Card

## Privileges on CASHBACK SBI Card

Know what you would be entitled to with this card

Card Cashback

<!-- image -->

### Card Cashback

- 5% Cashback on online* spends without any merchant restriction
- 1% Cashback on offline* spends

[Learn more](#)

[Back](#)

### Card Cashback

- *Cashback not applicable on Merchant EMI &amp; Flexipay EMI transactions and on following categories: Utility, Insurance, Fuel, Rent, Wallet, School &amp; Educational Services, Jewelry, Railways etc.. For complete list of exclusions, refer [www.sbicard.com/CashbackCardTnC](http://www.sbicard.com/CashbackCardTnC)

Hassle free

<!-- image -->

### Hassle free

- Card Cashback will be auto-credited to your SBI Card account within two working days of your next statement generation. For details, please see Cardholders T&amp;C

Spend Based Reversal

<!-- image -->

### Spend Based Reversal

- Reversal of Renewal Fee on annual spends of Rs.2 Lakh

Fuel Surcharge Waiver

<!-- image -->

### Fuel Surcharge Waiver

- 1% Fuel Surcharge Waiver across all petrol pumps in India*

[Learn more](#)

[Back](#)

### Fuel Surcharge Waiver

- * applicable on transactions of Rs. 500 - Rs. 3,000, exclusive of GST and other charges. Get maximum surcharge waiver of Rs. 100 per statement cycle per credit card account

    - Joining Fee (one-time): *Rs.* 999 + Taxes
    - Renewal Fee (Per Annum): *Rs.* 999 from second year onwards. Renewal Fee reversed if annual spends for last year &gt;= Rs. 2,00,000.

## Know your CASHBACK SBI Card

Your CASHBACK SBI Card now comes with  a host of features

- [Features](#)
- [Fees and Charges](#)

- Terms and Conditions
        - For detailed Terms and Conditions and Usage Directions, [click here](\sbi-card-en\assets\docs\pdf\cashback-tnc-booklet.pdf)
        - [Click here](\sbi-card-en\assets\docs\pdf\cashback-card-brochure.pdf) for CASHBACK SBI Card brochure

- Card Cashback
        - 5% Cashback on online* spends without any merchant restriction
        - 1% Cashback on offline* spends
        - *Cashback not applicable on Merchant EMI &amp; Flexipay EMI transactions and on following categories: Utility, Insurance, Fuel, Rent, Wallet, School &amp; Educational Services, Jewelry, Railways etc.. For complete list of exclusions, refer [www.sbicard.com/CashbackCardTnC](http://www.sbicard.com/CashbackCardTnC)
        - Click [**here**](\en\faq\cashback-sbi-card-faq.page) to know more details about Card Cashback

- Hassle free
        - Card Cashback will be auto-credited to your SBI Card account within two days of your next statement generation. For details, please see Cardholders T&amp;C

- Spend Based Reversal
        - Reversal of Renewal Fee on annual spends of Rs.2 Lakhs

- Fuel Surcharge Waiver
        - 1% Fuel Surcharge Waiver across all petrol pumps in India*

- Contactless Advantage
        - Daily purchases now made easy with CASHBACK SBI Card. Simply tap your card at a secure reader to transact
        - Fast &amp; convenient: No need to hand over your card or look for cash / coins for everyday small ticket purchases
        - Security: The card never leaves your hand during a Contactless transaction, significantly reducing the risk of card loss and fraud due to skimming (counterfeit). Even if the card is tapped multiple times at the reader, the unique security key feature of VISA PayWave will ensure that only one transaction goes through, thus making it more secure
        - Please [click here](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/personal/credit-cards/lifestyle/sbi-signature-contactless-card/Signature%20Contactless%20FAQ.pdf) to download the FAQ's
        - Please [click](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/personal/cards/list-of-stores.pdf) [**here**](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/personal/cards/list-of-stores.pdf) to download the list of Merchants enabled for transactions.

- Worldwide Acceptance
        - You can use your CASHBACK SBI Card in over 24 million outlets across the globe, including 3,25,000 outlets in India
        - Use your card to make payments at any outlet that accepts VISA

- Add-on Cards
        - With CASHBACK SBI Card, you can empower your family with [add-on cards](https://www.sbicard.com/en/personal/benefits/add-on-card.page) for your parents, spouse, children or siblings above the age of 18

- Cash on the Go
        - Withdraw cash from over 1 million VISA across the globe

- Utility Bill Payment Facility
        - Pay your electricity, telephone, mobile and other utility bills using the Easy Bill Pay facility on your CASHBACK SBI Card
        - [Click here](https://www.sbicard.com/en/personal/benefits.page#area5) to know more

- Balance Transfer on EMI
        - Save money while paying your credit card dues.
        - Transfer the outstanding balance of other banks' credit cards to your CASHBACK SBI Card, and avail a lower rate of interest and pay back in EMIs
        - Log on to [sbicard.com](https://www.sbicard.com/) with your user ID and password to take benefit of this service
        - [Click here](https://www.sbicard.com/en/personal/benefits/lower-interest-option/balance-transfer-on-emi.page) to know more about Balance Transfer on EMI

- Fees
        - Joining Fee (one time): Rs. 999
        - Renewal Fee (per annum): Rs. 999 from second year onwards. Renewal Fee reversed if annual spends for last year &gt;= Rs. 2,00,000.
        - Add-on Fee (per annum): NIL

- Fees and Charges
        - For information regarding fees and other applicable charges, please refer to the [Most Important Terms &amp; Conditions](\en\most-important-terms-and-conditions.page)

- Order of payment settlement
        - [Order Of Payment Settlement](\en\order-of-payment-settlement.page)

- Things to know
        - Submit account payee cheques following CTS 2010 standards for timely processing of your cheque payment
        - All taxes would be charged as applicable on all the above Fees, Interest &amp; Charges
        - Your continued use of the card will be deemed acceptance of these amendments.

## Allow us to help you

Contact Us

<!-- image -->

### Contact Us

SBI Cards and Payment Services Limited Unit 401 &amp; 402, 04th Floor, Aggarwal Millennium Tower, E-1,2,3 Netaji Subhash Place, Wazirpur , New Delhi 110034 CIN: L65999DL1998PLC093849

[Learn More](https://www.sbicard.com/en/contact-us/personal.page)

Image Hyperlink.

<!-- image -->

### [Contact Us](https://www.sbicard.com/en/contact-us/personal.page)

ATM/Drop box Locator

<!-- image -->

### ATM/Drop box Locator

Locate a Drop box, ATM or Pay Cash outlet nearest to you.

[Learn More](https://www.sbicard.com/en/personal/pay.page)

Image Hyperlink.

<!-- image -->

### [ATM/Drop box Locator](https://www.sbicard.com/en/personal/pay.page)

Track Application

<!-- image -->

### Track Application

Have applied for an SBI Card? Track your application status here.

[Learn More](https://www.sbicard.com/en/eapply.page#track-retrieve-form)

Image Hyperlink.

<!-- image -->

### [Track Application](https://www.sbicard.com/en/eapply.page#track-retrieve-form)

Simply SMS

<!-- image -->

### Simply SMS

Get instant information. Send an SMS to 5676791 from your registered mobile number.

[Learn More](https://www.sbicard.com/en/personal/benefits/easy-access-channels/simply-sms.page)

Image Hyperlink.

<!-- image -->

### [Simply SMS](https://www.sbicard.com/en/personal/benefits/easy-access-channels/simply-sms.page)

Download Mobile App

- Mobile Icon
SBI Credit Card App

<!-- image -->
- [Apple's App Store](https://itunes.apple.com/in/app/sbi-card/id694549848?mt=8)
- [Google's Play Store](https://play.google.com/store/apps/details?id=com.ge.capital.konysbiapp&hl=en)
- [Window's Store](#)

abb ccd dc dc dfv

- © 2025
- [Do Not Disturb](https://www.sbicard.com/en/do-not-disturb.page)
- [Most Important Terms &amp; Conditions](https://www.sbicard.com/en/most-important-terms-and-conditions.page)
- [Offer Terms &amp; Conditions](https://www.sbicard.com/en/offer-terms-conditions.page)
- [Security](https://www.sbicard.com/en/security.page)
- [Forms Central](https://www.sbicard.com/en/forms-central.page)
- [Sitemap](https://www.sbicard.com/en/sitemap.page)
- [Disclaimer](https://www.sbicard.com/en/disclaimer.page)
- [Fair Practice Code](https://www.sbicard.com/en/fair-practice-code.page)
- [Credit Bureau FAQs](https://www.sbicard.com/en/credit-bureau-faqs.page)
- [Privacy Policy/Notice](https://www.sbicard.com/en/privacy-policy.page)
- [PoSH Policy](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/posh-policy.pdf)
- [Order of Payment Settlement](https://www.sbicard.com/en/order-of-payment-settlement.page)
- [Cardholder Agreement](https://www.sbicard.com/en/cardholder-agreement.page)
- [Usage Agreement](https://www.sbicard.com/sbi-card-en/assets/docs/html/personal/usage-agreement/src/index.html)
- [Customer Grievance Redressal Policy](https://www.sbicard.com/en/grievance-redressal-policy.page)
- [Customer Notices](https://www.sbicard.com/en/customer-notices.page)
- [Tokenisation](https://www.sbicard.com/en/tokenisation.page)
- [Procurement News](https://www.sbicard.com/en/request-for-proposal.page)
- [ODR Portal Link &amp; Circular for Shareholders](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/who-we-are/notices/ODR-Portal-Link-Circular-for-Shareholders.pdf)
- [Policy for the issuance and conduct of credit cards](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/who-we-are/notices/policy-for-the-issuance-and-conduct-of-credit-cards-2023.pdf)

- **"SBI Cards and Payment Services Limited" was formerly known as "SBI Cards and Payment Services Private Limited"** Site best viewed in browsers I.E 11+, Mozilla 3.5+, Chrome 3.0+, Safari 5.0+ on all desktops, laptops, and Android &amp; iOS mobile/tablet devices

[x](#close)

You are being re-directed to a third party site. Please acknowledge the disclaimer before proceeding further.

You are about to access a site, the accuracy or completeness of the materials or the reliability of any advice, opinion, statement or other information displayed or distributed through it, is not warranted by SBICPSL and shall be solely be construed to be set forth by the third party.

You will access this site solely for the payment of your bills and you acknowledge that any reliance on any opinion, advice, statement, memorandum, or information available on the site shall be at your sole risk and consequences.

SBICPSL and its affiliates, subsidiaries, employees, officers, directors and agents, expressly disclaim any liability for any deficiency in the services of the service provider whose site you are about to access. Neither SBICPSL nor any of its affiliates nor their directors, officers and employees will be liable to or have any responsibility of any kind for any loss that you incur in the event of any deficiency in the services of the service provider, failure or disruption of the site of the service provider, or resulting from the act or omission of any other party involved in making this site or the data contained therein available to you, or from any other cause relating to your access to, inability to access, or use of the site or these materials in accordance thereto SBICSPL and all its related parties described hereinabove stand indemnified from all proceedings or matters arising thereto.

[OK Cancel](#)