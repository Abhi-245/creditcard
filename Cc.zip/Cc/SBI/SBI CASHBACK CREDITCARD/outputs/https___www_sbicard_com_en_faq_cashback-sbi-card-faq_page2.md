# CASHBACK SBI Card

- © 2025
- [Do Not Disturb](https://www.sbicard.com/en/do-not-disturb.page)
- [Most Important Terms &amp; Conditions](https://www.sbicard.com/en/most-important-terms-and-conditions.page)
- [Offer Terms &amp; Conditions](https://www.sbicard.com/en/offer-terms-conditions.page)
- [Security](https://www.sbicard.com/en/security.page)
- [Forms Central](https://www.sbicard.com/en/forms-central.page)
- [Sitemap](https://www.sbicard.com/en/sitemap.page)
- [Disclaimer](https://www.sbicard.com/en/disclaimer.page)
- [Fair Practice Code](https://www.sbicard.com/en/fair-practice-code.page)
- [Credit Bureau FAQs](https://www.sbicard.com/en/credit-bureau-faqs.page)
- [Privacy Policy/Notice](https://www.sbicard.com/en/privacy-policy.page)
- [PoSH Policy](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/posh-policy.pdf)
- [Order of Payment Settlement](https://www.sbicard.com/en/order-of-payment-settlement.page)
- [Cardholder Agreement](https://www.sbicard.com/en/cardholder-agreement.page)
- [Usage Agreement](https://www.sbicard.com/sbi-card-en/assets/docs/html/personal/usage-agreement/src/index.html)
- [Customer Grievance Redressal Policy](https://www.sbicard.com/en/grievance-redressal-policy.page)
- [Customer Notices](https://www.sbicard.com/en/customer-notices.page)
- [Tokenisation](https://www.sbicard.com/en/tokenisation.page)
- [Procurement News](https://www.sbicard.com/en/request-for-proposal.page)
- [ODR Portal Link &amp; Circular for Shareholders](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/who-we-are/notices/ODR-Portal-Link-Circular-for-Shareholders.pdf)
- [Policy for the issuance and conduct of credit cards](https://www.sbicard.com/sbi-card-en/assets/docs/pdf/who-we-are/notices/policy-for-the-issuance-and-conduct-of-credit-cards-2023.pdf)

- **"SBI Cards and Payment Services Limited" was formerly known as "SBI Cards and Payment Services Private Limited"** Site best viewed in browsers I.E 11+, Mozilla 3.5+, Chrome 3.0+, Safari 5.0+ on all desktops, laptops, and Android &amp; iOS mobile/tablet devices

[x](#close)

You are being re-directed to a third party site. Please acknowledge the disclaimer before proceeding further.

You are about to access a site, the accuracy or completeness of the materials or the reliability of any advice, opinion, statement or other information displayed or distributed through it, is not warranted by SBICPSL and shall be solely be construed to be set forth by the third party.

You will access this site solely for the payment of your bills and you acknowledge that any reliance on any opinion, advice, statement, memorandum, or information available on the site shall be at your sole risk and consequences.

SBICPSL and its affiliates, subsidiaries, employees, officers, directors and agents, expressly disclaim any liability for any deficiency in the services of the service provider whose site you are about to access. Neither SBICPSL nor any of its affiliates nor their directors, officers and employees will be liable to or have any responsibility of any kind for any loss that you incur in the event of any deficiency in the services of the service provider, failure or disruption of the site of the service provider, or resulting from the act or omission of any other party involved in making this site or the data contained therein available to you, or from any other cause relating to your access to, inability to access, or use of the site or these materials in accordance thereto SBICSPL and all its related parties described hereinabove stand indemnified from all proceedings or matters arising thereto.

[OK Cancel](#)