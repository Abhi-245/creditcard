<!-- image -->

er oerore on your purcnases.

- nd offline spends
- ) your SBI Card account within ment generation date
- ry month^

<!-- image -->

57

cashback

## Big cash right back at you!

- Avail 5% Cashback* on online spends
- No merchant restriction

'Cashback not applicable on Merchant EMI &amp; Flexipay EMI transactions and on following categories: Utility; Insurance; Fuel, Rent, Wallet; School &amp; Educational Services, Jewelry; Railways etc.. For complete list of exclusions, refer www.sbicard com/CashbackCardTnC

## Jo without 1 gift.

- n offline spends

c. For complete list of exclusions; refer www.sbicard com/CashbackCardTnC

## d comeback.

2 of ?999+Taxes waived off on reaching annual spends

## ts more -

17 WAIver

CASH

Icard

1 is enabled with the latest gy that helps you make faster and ts\_

- K SBI Card on a contactless POS machine for
- es
- ever leaves your hand

<!-- image -->

## onnected; ver you go.

- related to SBI Card account

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->