"""
recursivecrawl.py
-----------------
Hybrid crawler:
 - Crawl main webpage using Crawl4AI.
 - Extract all links from target DOM sections.
 - Print links found.
 - Scrape those links using requests + BeautifulSoup (with retry).
 - Handle PDFs with PyPDF2.
 - Save everything into individual files + combined file.
"""

import asyncio
import os
import re
import time
import requests
import io
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from crawl4ai import (
    AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode
)
from PyPDF2 import PdfReader


# -------------------------------
# Helpers
# -------------------------------

def fetch_with_retries(url, retries=3, timeout=15):
    """Fetch a webpage (or detect PDF) with retry logic. Always returns (kind, data)."""
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(
                url,
                timeout=timeout,
                headers={"User-Agent": "Edg/139.0.0.0"},
                allow_redirects=True,
            )

            content_type = resp.headers.get("Content-Type", "").lower()

            # PDF detection
            if resp.url.lower().endswith(".pdf") or "application/pdf" in content_type:
                return ("pdf", resp.content)

            if resp.status_code == 200:
                return ("html", resp.text)

            print(f"[WARN] {url} returned {resp.status_code} (attempt {attempt})")

        except Exception as e:
            print(f"[ERROR] Fetch failed for {url} (attempt {attempt}): {e}")

        time.sleep(2 * attempt)  # backoff

    return (None, None)


def extract_pdf_bytes(pdf_bytes):
    """Extract text from raw PDF bytes using PyPDF2."""
    try:
        file_like = io.BytesIO(pdf_bytes)
        reader = PdfReader(file_like)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception as e:
        print(f"[ERROR] PDF extraction failed: {e}")
        return ""


def safe_filename_from_url(url: str, suffix: str = "", folder: str = "") -> str:
    safe = re.sub(r"[^\w\-_.]", "_", url)
    if suffix:
        safe = f"{safe}_{suffix}"
    if folder:
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, f"{safe}.txt")
    return f"{safe}.txt"


def filter_valid_links(links):
    """Keep only absolute http/https links and deduplicate."""
    cleaned = []
    for l in links:
        if not l.startswith("http"):
            continue
        l = l.replace("http://", "https://")
        cleaned.append(l)
    return list(sorted(set(cleaned)))


# -------------------------------
# Main crawling function
# -------------------------------

async def crawl_main_and_scrape_links(start_url):
    browser_config = BrowserConfig(headless=True, verbose=False)
    run_config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS, stream=False)

    async with AsyncWebCrawler(config=browser_config) as crawler:
        print("\n=== Crawling Main Page ===")
        result = await crawler.arun(start_url, config=run_config)

        if not result.success:
            print(f"[ERROR] Failed to crawl main page: {result.error_message}")
            return

        html_source = result.html or ""
        links_set = set()
        section_texts = []

        # Extract sections and links with BeautifulSoup
        soup = BeautifulSoup(html_source, "html.parser")
        nodes = []
        nodes.extend(soup.select("body > div:nth-of-type(1) > section:nth-of-type(4)"))
        nodes.extend(soup.select("body > div:nth-of-type(1) > section:nth-of-type(5)"))
        nodes.extend(soup.select("body > div:nth-of-type(1) > section:nth-of-type(6) > div > section"))

        if not nodes:
            nodes = soup.find_all("div", class_="content") or [soup]

        for node in nodes:
            text = node.get_text(separator="\n", strip=True)
            if text:
                section_texts.append(text)
            for a in node.find_all("a", href=True):
                href = a.get("href").strip()
                if href and not href.startswith("#") and not href.lower().startswith("javascript:"):
                    links_set.add(urljoin(result.url, href))

        # Save main page content
        combined_texts = []
        combined_text = "\n\n".join(section_texts).strip()
        combined_texts.append(f"==== Main Page: {result.url} ====\n{combined_text}\n")

        txt_filename = safe_filename_from_url(result.url, suffix="sections")
        with open(txt_filename, "w", encoding="utf-8") as f:
            f.write("URL: " + result.url + "\n\nLinks:\n")
            f.write("\n".join(sorted(links_set)) if links_set else "(none)")
            f.write("\n\n--- Extracted Section Text ---\n\n")
            f.write(combined_text or "(no content extracted)\n")
        print(f"Saved main page -> {txt_filename}")

        # Filter links
        valid_links = filter_valid_links(links_set)
        print(f"\n=== Links Found ({len(valid_links)}) ===")
        for l in valid_links:
            print("  ", l)

        # Scrape each link
# Scrape each link
    for link in valid_links:
        print(f"\n[Scraping] {link}")
        kind, data = fetch_with_retries(link)

        if not kind:
            print(f"[FAILED] Could not scrape {link}")
            continue

        if kind == "pdf":
            print(f"[PDF] Extracting text from {link}")
            text2 = extract_pdf_bytes(data)
        else:
            soup2 = BeautifulSoup(data, "html.parser")
            text2 = soup2.get_text(separator="\n", strip=True)

        # Save individual link file
        safe_url = safe_filename_from_url(link, folder="linkbylinkscrap")
        with open(safe_url, "w", encoding="utf-8") as f:
            f.write("URL: " + link + "\n\n")
            f.write(text2 or "(no text extracted)")

        # ✅ Append extracted *text* (not raw bytes) to combined
        combined_texts.append(f"==== Linked Page: {link} ====\n{text2 or '(no text extracted)'}\n")
        print(f"Saved linked page -> {safe_url}")

        with open("combinedscrapping.txt", "w", encoding="utf-8") as f:
            f.write("\n\n".join(combined_texts))
        print("\nSaved combined output to combinedscrapping.txt")

# -------------------------------
# Run
# -------------------------------

if __name__ == "__main__":
    asyncio.run(crawl_main_and_scrape_links(
        "https://www.sbicard.com/en/personal/credit-cards/rewards/cashback-sbi-card.page"
    ))
