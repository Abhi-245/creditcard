## IMPORTANT TERMS AND CONDITIONS

## HSBC Platinum Credit Card and HSBC Live+ Credit Card

To get the complete version, please visit www.hsbc.co.in

## 1.  FEES AND CHARGES

## a.  Joining fees

-  Joining fee for Platinum Primary Cardholder is NIL..
-  Joining fee for Live+ Primary Cardholder is ` 999
-  Joining fee for add-on cardholder(s) is NIL

## b.  Annual membership fees

Annual membership fees are applicable on the primary credit card. These fees may vary depending on the offer under which the HSBC Credit Card has been availed of by the cardholder.

These fees, including fees for any add-on cardholder(s), as applicable, are charged to the cardholder's credit card account on issuance/renewal and the same would be reflected in the monthly credit card statement of the month in which it is charged.

No refund of fees will be available if the credit card is terminated. Current charges are mentioned in the tariff sheet given below.

## c.  Cash advance fees

The cardholder has access to cash, round the clock, at HSBC/Visa ATMs in India and overseas.

A transaction fee of 2.5% of the transaction amount (subject to a minimum of INR 500) would be levied on all such transactions at the time of posting of the cash advance and would be billed to the Cardholder in the next monthly statement. HSBC shall provide a prior notice of one month in case of any changes to the transaction fee. Cash advance transactions are also subject to a finance charge at the prevailing rate calculated on daily outstanding balances from the date of withdrawal. The finance charge will be debited to the credit card account on the last day of the billing cycle.

## d.   Service charges levied for certain transactions

-   Fees and charges, as may be applicable from time to time, are payable by the cardholders for specific services provided to the cardholder or for defaults committed by the cardholder with reference to his/her card account.
-   Tariff structure is subject to change from time to time at the sole discretion of HSBC. Such changes will be made with prospective effect giving notice of at least 30 days.
-    Please be advised that applicable Indirect Taxes including GST would be recovered on all our fees and charges and any other amount liable to tax under prevailing Indirect Tax.

HSBC Maharashtra GST No. - 27AAACT2786P3ZL.

Address: 52/60, Mahatma Gandhi Road, Fort, Mumbai - 400 001. HSN (Harmonised System Nomenclature) Code: 997113 - Credit Card Services

-    I/We hereby declare that though our aggregate turnover in any preceding financial year from 2017-18 onwards is more than the aggregate turnover notified under sub-rule (4) of rule 48, we are not required to prepare an invoice in terms of the provisions of the said sub-rule.
- Late payment charge will be applicable if minimum payment due is not paid within 3 days of the payment due date.
-   Overlimit charges is applicable in the event of total outstandings exceeding the credit limit assigned.

<!-- image -->

| Tariff Sheet                                                                                                                                                                                                                              | Platinum Card                                                                                                                                                                                                                                                                                                                                                                                                                                                    | Cashback/Live+ Card                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Joining Fee                                                                                                                                                                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Primary Card                                                                                                                                                                                                                              | NIL                                                                                                                                                                                                                                                                                                                                                                                                                                                              | ` 999                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| Add-on card                                                                                                                                                                                                                               | NIL                                                                                                                                                                                                                                                                                                                                                                                                                                                              | NIL                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Annual Fee                                                                                                                                                                                                                                | NIL                                                                                                                                                                                                                                                                                                                                                                                                                                                              | ` 999 (Waived off only if the minimum spends on the primary card is more than ` 200,000 in the AY for which the annual fee is charged)                                                                                                                                                                                                                                                                                                                           |
| Free Credit Period Please note that the free credit period is not valid if any balance of the previous months' bills is outstanding                                                                                                       | Cardholders can get up to 48 days free credit without any finance charge levied to the credit card account. This is applicable provided the credit card outstanding, as shown on monthly credit card statement, is settled fully by the payment due date. However, the free credit period will not be applicable for cash advance transactions. Please note that the free credit period is not valid if any balance of the previous month's bill is outstanding. | Cardholders can get up to 45 days free credit without any finance charge levied to the credit card account. This is applicable provided the credit card outstanding, as shown on monthly credit card statement, is settled fully by the payment due date. However, the free credit period will not be applicable for cash advance transactions. Please note that the free credit period is not valid if any balance of the previous month's bill is outstanding. |
| Finance Charges #                                                                                                                                                                                                                         |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Finance Charges on extended credit and cash advances *These charges are also applicable on transactions in categories such as money transfer (wire transfer), foreign currency purchase, money orders, traveler cheques, debt repayments, | 3.75% per month (45% per annum) computed from the date of transaction                                                                                                                                                                                                                                                                                                                                                                                            | 3.75% per month (45% per annum) computed from the date of transaction                                                                                                                                                                                                                                                                                                                                                                                            |

| MPD                                                                                                    | Higher of ` 100 OR Sum of: 1. 100% of all Interest, Fees and Taxes billed in the current statement 2. 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any) 3. Higher of (Past due*; Over limit amount if any) 4. 1% of the billed statement balance (excluding any EMI balance, fees, interest, and taxes billed) *Past due refers to unpaid Minimum Payment Due from the previous cycle   | Higher of ` 100 OR Sum of: 1. 100% of all Interest, Fees and Taxes billed in the current statement 2. 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any) 3. Higher of (Past due*; Over limit amount if any) 4. 1% of the billed statement balance (excluding any EMI balance, fees, interest, and taxes billed) *Past due refers to unpaid Minimum Payment Due from the previous cycle   |
|--------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Charge in case of bounced cheque, dishonored SI, or unsuccessful payment through NACH                  | ` 500                                                                                                                                                                                                                                                                                                                                                                                                                           | ` 500                                                                                                                                                                                                                                                                                                                                                                                                                           |
| Late payment fee (Charged if minimum amount due does not reach HSBC within 3 days of payment due date) | 100% of the Minimum Payment Due (MPD) - Subject to a minimum of ` 250 and a maximum of ` 1,200 per month                                                                                                                                                                                                                                                                                                                        | 100% of the Minimum Payment Due (MPD) - Subject to a minimum of ` 250 and a maximum of ` 1,200 per month                                                                                                                                                                                                                                                                                                                        |
| Charges towards Foreign Currency Transactions                                                          | 3.5% foreign currency transactions                                                                                                                                                                                                                                                                                                                                                                                              | 3.5% foreign currency transactions                                                                                                                                                                                                                                                                                                                                                                                              |
| Cash Payment Charge                                                                                    | ` 100 (at HSBC Branches and Drop boxes)                                                                                                                                                                                                                                                                                                                                                                                         | ` 100 (at HSBC Branches and Drop boxes)                                                                                                                                                                                                                                                                                                                                                                                         |
| Charges Towards Rental and related payments                                                            | 1% processing fee plus the applicable taxes                                                                                                                                                                                                                                                                                                                                                                                     | 1% processing fee plus the applicable taxes                                                                                                                                                                                                                                                                                                                                                                                     |
| Cash advance limit (against card account)                                                              | As communicated in your credit monthly card statement                                                                                                                                                                                                                                                                                                                                                                           | As communicated in your credit monthly card statement                                                                                                                                                                                                                                                                                                                                                                           |
| Transaction fee for cash advances against your credit card account at branches and ATMs                | 2.5% of transaction amount (subject to a minimum amount of ` 500)                                                                                                                                                                                                                                                                                                                                                               | 2.5% of transaction amount (subject to a minimum amount of ` 500)                                                                                                                                                                                                                                                                                                                                                               |
| Transaction fee for cash withdrawal against your bank account at ATMs                                  | ` 100 at ATMs overseas                                                                                                                                                                                                                                                                                                                                                                                                          | ` 100 at ATMs overseas                                                                                                                                                                                                                                                                                                                                                                                                          |
| Transaction fee for cash withdrawal against your bank account at non-HSBC ATMs in India                | NIL                                                                                                                                                                                                                                                                                                                                                                                                                             | NIL                                                                                                                                                                                                                                                                                                                                                                                                                             |

| Overlimit fee            | 2.5% of the overlimit amount or ` 500 (whichever is higher) + applicable GST                                      | 2.5% of the overlimit amount or ` 500 (whichever is higher) + applicable GST                                      |
|--------------------------|-------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Balance transfer charges | • Rate of interest: 10.99% p.a. to 15.99% p.a. across tenors • Processing fee: 1.5% subject to a minimum of ` 200 | • Rate of interest: 10.99% p.a. to 15.99% p.a. across tenors • Processing fee: 1.5% subject to a minimum of ` 200 |

NOTE: All fees will be charged along with applicable taxes.

# Finance charges per month at the prevailing rate will also apply.

**Annual fee will be waived off only if the minimum spends on the primary card is more than /.notdef200,000 in the FY for which the annual fee is charged.

If a 100% interest refund EMI plan is communicated by the merchant, the interest component pertaining to the EMI will be charged by HSBC as applicable. However, the interest will be refunded as an upfront discount/cashback by the merchant to the card/wallet as communicated at the time of the purchase. Applicable taxes on interest charged by HSBC will be borne by the cardholder.

## e.  Interest free (grace) period

The Interest free credit period could range from 48 days (Platinum Card) to 45 days (Cashback/ Live+ Card). This means that a customer who has a billing date of 5th of the month can spend on his Card from 6 May to 5 June, his bill will be generated on 5 June and his Payment Due Date will be 21 June (45 days for cashback/Live+ Card) and (24 June for Platinum Card).

This is applicable provided the credit card outstanding, as shown on monthly credit card statement, is settled fully within 3 days (Grace Period) of payment due date. However, the free credit period will not be applicable for cash advance transactions.

Please note that the free credit period is not valid if any balance of the previous month's bill is outstanding.

## f.   Finance charges

- Cardholders can avail of the 'extended credit facility' by paying the Minimum Payment Due (MPD) indicated in the monthly credit card statement. The MPD is calculated as sum of 100% of all Interest, Fees and Taxes billed in the current statement and 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any) and higher of (Past due*; Over limit amount if any) and 1% of the billed statement balance (excluding any EMI balance, fees, interest and taxes billed), subject to a minimum of ` 100 + Equated Monthly Instalment* (EMI) amounts due (if any), subject to a minimum of ` 100. Interest will be charged on the extended credit as per terms and conditions.
- If Cardholders avail of the extended credit facility by paying an amount less than the statement closing balance, the entire outstanding amount will attract a finance charge from the respective date of transaction at the prevailing rate. All new transactions will also attract a finance charge from the respective date of transaction.
- All cash advance transactions will attract a finance  charge @ 3.75% per month (45% per annum) from the date of withdrawal, until the entire amount along with the charges are cleared.
- Finance charges are computed from the date of transaction at 3.75% per month (45% per annum) or at such modified rates as decided by the Bank from time to time.

## g.  Finance Charge Illustration

Let's say you purchase a watch for ` 1,200 on 01 March and a necklace for /.notdef800 on 10 March. The following interest will be charged on your purchases:

## Finance Illustration for Cashback/Live+ Credit Card and Platinum Credit Card:

| Cashback/Live+ Card                                            | Cashback/Live+ Card   | Platinum Card                                                  | Platinum Card   |
|----------------------------------------------------------------|-----------------------|----------------------------------------------------------------|-----------------|
| Outstanding due in the 20 March statement                      | ` 2,000.00            | Outstanding due in the 20 March statement                      | ` 2,000.00      |
| Payment made on the due date of 04 April                       | ` 100.00              | Payment made on the due date of 04 April                       | ` 100.00        |
| Balance carried forward (revolved)                             | ` 1,900.00            | Balance carried forward (revolved)                             | ` 1,900.00      |
| Interest calculations: (3.75% p.m.)                            |                       | Interest calculations: (3.75% p.m.)                            |                 |
| a) Interest on ` 1,200 for 35 days (from 01 March to 04 April) | ` 51.00               | a) Interest on ` 1,200 for 38 days (from 01 March to 07 April) | ` 56.22         |
| b) Interest on ` 800 for 26 days (from 10 March to 4 April)    | ` 25.00               | b) Interest on ` 800 for 29days (from 10 March to 7 April)     | ` 26.60         |
| c) Interest on ` 1,900 for 15 days (from 05 April to 20 April) | ` 37.00               | c) Interest on ` 1,900 for 12 days (from 08 April to 20 April) | ` 30.45         |
| Total interest charged in the 20 April statement               | ` 113.00              | Total interest charged in the 20 April statement               | ` 115.27        |
| GST @18.00% on Interest                                        | ` 20.00               | GST @18.00% on Interest                                        | ` 20.75         |
| Outstanding due in 20 April statement                          | ` 2,033.00            | Outstanding due in 20 April statement                          | ` 2,036.00      |

Making only the minimum payment every month would result in the repayment stretching till  the  entire  outstanding  is  settled  and  consequent  payment  on  your  outstanding balance during this extended period.

Note: No refund of annual fee will be available if the credit card is terminated.

Tariff structure is subject to change from time to time at the sole discretion of HSBC. The Bank will notify you of any changes in the terms and conditions of this product with prior notice of 30 days.

Please be advised that applicable Indirect Taxes including Goods and Services Tax (GST) would be   recovered on all our fees and charges and any other amount liable to tax under prevailing Indirect Tax Laws. The credit limit and cash withdrawal limit (20% of credit limit or as decided by the Bank from time to time) are communicated to you in your monthly card statement. The available credit limit is provided as part of the monthly card statement.

The Bank reserves its right to reduce the credit limit without any prior notice or intimation. Usage   of the credit card shall be deemed as acceptance of the credit limits granted from time to time.

## h. Illustration for Minimum Payment Due (MPD) Computation:

Assume that you have paid all previous dues in full, and do not have any amount outstanding in your Credit Card Account, and your monthly statement is generated on the 15th of every month.

|   Sr.No. | Transaction Date   | Type     | MPD Contribution   | Amount (INR)   |
|----------|--------------------|----------|--------------------|----------------|
|        1 | 25th Sept          | Purchase | 1%                 | 5,000          |

| 2   | 1st Oct   | Joining Fee                 | 100%   | 999      |
|-----|-----------|-----------------------------|--------|----------|
| 3   | 1st Oct   | GST on Joining Fee          | 100%   | 179.82   |
| 4   | 1st Oct   | Cash Withdrawal             | 1%     | 2000     |
| 5   | 1st Oct   | Cash Advance Fee            | 100%   | 500      |
| 6   | 1st Oct   | GST                         | 100%   | 90       |
| 7   | 15th Oct  | Interest on Cash Withdrawal | 100%   | 69.80    |
| 8   | 15th Oct  | GST on Interest             | 100%   | 12.56    |
|     |           | Total Due (INR)             |        | 8,851.18 |
|     |           | Minimum Payment Due (MPD)   |        | 1,921.18 |

Minimum Payment Due (MPD) will be calculated as below:

MPD = 1% of Purchase and Cash Withdrawal + 100% of Joining Fees, Cash Withdrawal Fee, Interest on cash withdrawal, GST on cash Adv and GST on Interest.

MPD = 1%*(5000+2000) + 100%*(999+179.82+500+90+69.80+12.56) = 1921.18.

## i.   Late payment fee

Late payment fee (Charged if the minimum amount due is not credited in the card within 3 days of payment due date) is 100% of the Minimum Payment Due (MPD) - Subject to minimum fees of ` 250 and maximum fees of ` 1,200 per month. Please note that the Late Payment Fees is levied only if the Minimum Payment Due is not paid within 3 days of the due date.

Illustrative examples of how Late Payment Charges are calculated - Assume you receive a statement for the period 16 October - 15 November, with a payment due date of 7 December. Payment of Minimum Payment Due (MPD) is required to be received in the card account within 3 days of payment due date (10 December) to ensure that no late payment fees are levied. Late payment fees will be levied as per the illustration in the table given below:

| MPD     | Late payment charges   | Description                                                                                                                              |
|---------|------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| ` 100   | ` 250                  | 100% of MPD i.e. on ` 100 is ` 100. Since the minimum fee is ` 250, the late payment fee levied will be ` 250                            |
| ` 250   | ` 250                  | 100% of MPD i.e. on ` 250 is ` 250, hence the late payment fees levied would be ` 250                                                    |
| ` 500   | ` 500                  | 100% of MPD, i.e. ` 500 is ` 500, hence the late payment fees levied would be ` 500.                                                     |
| ` 1,500 | ` 1,200                | 100% of MPD, i.e. on ` 1,500 is ` 1,500. However, since maximum fee applicable is ` 1,200, the late payment fee levied would be ` 1,200. |

## 2.  CREDIT LIMITS

1.  The credit limit and cash withdrawal limit (Up to 20% of credit limit or as decided by the Bank from time to time) are communicated to you in your monthly card statement. The available credit limit is provided as part of the monthly statement. The Bank reserves its right to reduce the credit limit. Usage of the card shall be deemed as acceptance of the credit limits granted from time to time.
2.  Credit limit means the limit up to which the Card Member is authorized to spend on his Credit Card. This limit is specified in the mailer accompanying your HSBC Credit Card.
3.  The credit limit approved on the account is shared between the primary cardholder and the addon Cardholders.
4.  The available credit limit on your credit card account is the applicable credit limit less the 'Total Amount Due'.

The Cardholder should refer to the Bank to ascertain the available credit limit at any point in time The available credit limit is also provided as part of the monthly statement. The Bank reserves its right to reduce the credit limit. Usage of the card shall be deemed as acceptance of the credit limits granted from time to time.

Cardholders are permitted to perform transactions above their sanctioned limit after they have given their requisite content on the HSBC India Mobile app. Customers should note that switching on the Overlimit does not solely guarantee that the transaction will be honored as the final decision will be governed by the bank's internal lending guidelines. In the absence of the consent, all Overlimit transactions will be declined due to insufficient credit limit.

An Overlimit Charge as enumerated in the Tariff of Charges section of the Most Important Terms and Conditions shall be levied for such transactions which exceed your credit limit.

5.  The Cardholder may apply for a review of his assigned credit limit at any time after six months of satisfactory credit card operations.

## 3.  BILLING AND PAYMENTS

Bank shall send statement by your preferred mode of delivering (Online/Physical) on your statement date. You can further view the same on internet banking if not already received by the statement date. Further customer can change the billing cycle by contacting the HSBC customer center)

- a.  Payments made to the Cardholders account will be settled in the following order:
1. Service charges*, 2. Interest/finance charges, 3. Late payment  fee, 4. Annual  fee, 5. Overlimit fee, 6. Instalment handling fee, 7. Instalment processing fee, 8. Return cheque charges, 9. Insurance premium, 10. Principal**

*Service charges include the following:

- Cash Advance Fee, GST, Card Replacement Fee, Statement Reprint Fee, Balance Transfer processing fee, Standing Instruction (SI) failed fee
- **Principal - Includes purchase amount, Balance Transfer principal amount and cash withdrawn on the credit card.
- b.  When the credit card account has an outstanding balance, HSBC will send a monthly itemized statement of account at the mailing address indicating the payments credited and the transactions debited to the cardholders account since the last statement. Non-receipt of the statement would not affect the cardholder's obligations and liabilities. If the due date for payment of outstanding dues of your Card account falls on a Sunday/Public holiday(s), the same shall have to be paid/ debited on the next working day. Due and applicable interest will be calculated inclusive of said Sunday/Public holiday(s) and shall be payable by the Cardholder to the Bank.
- c.  Cardholders may choose to pay only the minimum payment due, as printed on the statement and such payment should be sent within 3 days of payment due date, which is also printed on the statement. If payment is made by cheque, the funds must be realized in the card account within 3 days of the due date. The outstandings carried forward will attract a finance charge as decided by the Bank from time to time. Bank may change the classification logic basis the regulatory guideline from time to time.
- d.  Cardholders can choose from following modes of payment to settle monthly dues. Cardholders should exercise due caution and refrain from making payments through modes other than the ones listed below-
- Cheque/draft payment: The cheque/draft should be made payable to 'HSBC A/c No. XXXX XXXX XXXX XXXX (mention Cardholder's 16-digit credit card number).

Cheque/draft payment can be submitted at:

- Drop-boxes  at  HSBC  branches/ATMs  in  India  (visit  www.hsbc.co.in  for  a  complete  list  of branches and ATMs).
- Mail to The Hongkong and Shanghai Banking Corporation Limited, Clearing Department, M G Road, Fort, Mumbai - 400 001.
- Cash payment: Cash payments can be made at any HSBC branch in India.
- Standing instruction: If the Cardholder is an accountholder with HSBC, he/she can issue a standing instruction for transferring funds from the cardholder's HSBC account to the credit card account.
- Internet Banking: Cardholder can pay bills online conveniently by logging onto HSBC Personal Internet Banking*

*Option available for HSBC accountholders only.

- NACH: Cardholders can make payment directly by authorizing HSBC to debit a Cardholders account with any bank. This facility is available only in Mumbai and Delhi.
- National Electronic Funds Transfer (NEFT): You can make a payment towards your credit card account via NEFT, mentioning the complete 16-digit credit card number.
- ATM/PhoneBanking:  Cardholder  can  access  their  account  with  HSBC  through  ATM/ PhoneBanking facility for making payments against credit card outstandings.

## PayU Payment Service

Pay HSBC Bank Credit Card bills online from any bank account through PayU Payment Service. Transfer money from your bank account to your HSBC Credit Card online using the PayU facility, a third-party website with the URL https://securepayments.payu.in/hsbc-credit-card-payment. Visit www.hsbc.co.in for the terms and conditions of the payment service through PayU.

- e.  Billing disputes resolution
- The  Cardholder  is  deemed  to  have  received  each  statement  of  account  for  the  preceding month, either on actual receipt of the statement of account or 10 days after the dispatch of the statement of account by the Bank, whichever is earlier (prescribed period). Upon receipt of each statement of account and in any event not more than 30 days from the period mentioned above, the Cardholder agrees to immediately notify the Bank in writing of any errors, omissions, irregularities, including any fraudulent or unauthorized transactions or any other objections the cardholder has to that statement of account. If the Cardholder fails to notify the Bank within 30 days, the statement of account and all entries therein, will be conclusive evidence of the correctness of the contents and binding upon the Cardholder and/ or any person claiming under or through such Cardholder without the requirement for any further proof and the Bank will be released from all liability for any transaction (including all charges, damages and losses of any kind whatsoever, taxes, levies, fines, fees or penalties incurred) occurring up to the date of the most recent statement of account except, for transactions the Cardholder gave notice of in accordance with this section.
- For reporting billing discrepancies, Cardholders can either call the customer service center (numbers are provided on the reverse of the monthly statement or at www.hsbc.co.in) or write to - HSBC Credit Card Division, Dispute Desk, P . O. Box 5080, Chennai - 600 028.
- If at any stage, you feel that our service levels are not up to your expectations, you may write to - Manager, Customer Care Centre, The Hongkong and Shanghai Banking Corporation Limited, Rajalakshmi, No. 5 and 7, Cathedral Road, Chennai - 600 086.
- Or you may contact our Customer Service Executive by visiting any of our branches or you may contact our PhoneBanking Service Executives.
- Grievance Redressal Officer Handling Credit Card Complaints

## Mr Sudeep Behari

The Hongkong and Shanghai Banking Corporation Limited NESCO - IT Park Bldg. 3, 9th Floor, Nesco Complex, Western Express Highway, Goregaon (E), Mumbai - 63

Contact number: 040-61268015 / 080-71898015 (Monday to Friday between 9:30 a.m. and 6:00 p.m.)

## E-mail ID: complaints.india@hsbc.co.in

- For  compensation framework for delay in redressal of grievance, please visit https://www. hsbc.co.in/content/dam/hsbc/in/documents/compensation\_policy.pdf
- The time period for reversal of failed POS/online/contactless transactions as well as failed ATM transactions on Credit Card is the same i.e. 5 days. The compensation payable for failure to meet the specified timeline in ` 100 per day of delay.

## 4.  DEFAULT

- In the event of default (if the minimum amount due is not paid by within 3 days of payment due date or breach of any clause of the cardholder agreement), the cardholder will be sent reminders from time to time for payment of any outstanding on credit card account, by post, fax, telephone, e-mail, SMS messaging and/or through third parties appointed for collection purposes to remind, follow-up  and  collect  dues.  Any  third  party  so  appointed,  shall  adhere  to  the  Indian  Banks Association (IBA) code of conduct on debt collection.

The bank will provide seven days' notice period to such cardholder about the intention to report him/her as defaulter to the Credit Information Company.

## The bank will send SMS at T-7 to T+4 days, in this regard T being payment date.

- Recovery of dues in case of death of Cardholder
- i. The whole of the outstanding balance (including unbilled transactions) will become immediately due and payable to HSBC.
- ii.   HSBC will become entitled to recover the total outstanding from the estate of the Cardholder.
- As per Reserve Bank of India guidelines, we provide credit information relating to our credit cardholders  to  Credit  Information  Companies  (CICs)  payable  in  full  to  HSBC  on  suspension/ termination of the agreement for whatever reasons or on the insolvency or death of the credit Cardholder. HSBC will become entitled to recover the outstanding dues together with all expenses, legal fees, finance charges and interest from the estate of the credit cardholder on his death, without prejudice to its rights to continue to charge the finance charges and other charges at prevailing rates till the dues are settled on a monthly basis. The information provided reflects the status as on the previous month-end and includes information regarding, whether the credit card account is regular or delinquent. In the event a credit card account is delinquent as on the date of such reporting and the account is subsequently regularized, the status of the account will only be updated prospectively, at the time of the next  reporting. As per Credit Information Companies (CICs), all changes in customer status are updated within the timeline prescribed from time to time.. To avoid any adverse credit history with Credit Information Companies (CICs), credit Cardholders should ensure that they make timely payment of the amount due on the card account.

## Standard Illustration SMA/NPA classification:

| Loans in the nature of revolving facilities like cash credit/overdraft   | Loans in the nature of revolving facilities like cash credit/overdraft                                                                                        |
|--------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| SMA Subcategories                                                        | Basis for classification - Outstanding balance remains countinuously in excess of the sanctioned limit or drawing power, whichever is lower, for a period of: |
| SMA-1                                                                    | More than 30 days and upto 60 days                                                                                                                            |
| SMA-2                                                                    | More than 60 days and upto 90 days                                                                                                                            |

Example: If due date of a Credit card account is 31 March 2021, and full dues are not received before the lending institution runs the day-end process for this date, the date of overdue shall be 31 March 2021.

If it continues to remain overdue, then this account shall get tagged as SMA-1 upon running dayend process on 30 April 2021 i.e. upon completion of 30 days of being continuously overdue. Accordingly, the date of SMA-1 classification for that account shall be 30 April 2021.

Similarly, if the account continues to remain overdue, it shall get tagged as SMA-2 upon running day-end process on 30 May 2021 and if continues to remain overdue further, it shall get classified as NPA upon running day-end process on 29 June 2021.

Bank will report you as a defaulter to Credit Agencies if you miss payment for minimum amount by 3 days from the due date.

## · Data Submission to Credit Information Companies (CIC's)

## I.  INTRODUCTION

Credit Information Bureau (India) Limited (CIBIL) was incorporated in 2000. CIBIL was promoted by the State Bank of India (SBI), Housing Development Finance Corporation Limited (HDFC), Dun &amp; Bradstreet Information Services India Private Limited (D&amp;B) and Trans Union International Inc. (Trans Union). The Consumer Bureau was launched on 5 April 2004, and the Commercial Bureau was launched on 8 May 2006. In addition to CIBIL, HSBC has engaged with three other credit bureaus in India - Experian, Equifax and CRIF Highmark.

## II.  DATA SUBMISSION

As per the Credit Information Companies (Regulation) Act, 2005 (CICRA), data submission to the credit bureaus is done as per the prescribed timeline. Bureau reporting is done as per the TUDF guidelines in the prescribed Uniform Credit Reporting Format (UCRF).

## III.  FRAUD/ DISPUTE HANDLING

Cards Master Circular explicitly requires disputed cards to be reported to CIC's only after the dispute is settled. To summarize; the process states as follows:

To summarise; the process states as follows:

- i) Bank is required to process temporary credit within 10 working days from complaint received date for all eligible disputes (unsecured transactions without Additional Fact Authentication) reported as unauthorized.
2. ii)   For all transactions which have been reported as unauthorized, however occurred in secured environment (with AFA or Chip &amp; PIN), bank doesn't have a chargeback right as per VISA/ Master Guidelines. For the above two scenarios, since Bureau reporting is done each month as of previous month end data, any dispute raised by customer in the existing month will not coincide with the reporting.
3. iii)  T reatment on dispute of charges is a part of the existing Cards MITC and Bureau reporting would be undertaken basis outcome of response to customer and amendments (if any) would be done on a post-facto basis.
4. iv)  Any future identification of fraud will be a part of amendments on a post facto basis.

## 5.  TERMINATION

- You may terminate this agreement at any time by written notice to HSBC accompanied by the return of the credit card and any additional credit cards cut into several pieces and full clearance of all the outstandings Where this agreement relates to the use of an additional credit card, the usage of the additional card may be discontinued by written notice to HSBC by you. Please destroy the additional credit card by cutting it into several pieces through the magnetic stripe.
- HSBC may at any time, by providing a notice of 30 days, terminate and close the credit card and the credit card account of the credit Cardholder without assigning any reason for the same.
- HSBC may at its discretion recall the outstanding amount on your credit card(s)/add-on card(s) without  assigning  any  reason  thereof.  In  the  event  of  HSBC  recalling  the  entire  outstanding amount, HSBC shall give you reasonable notice for paying the entire outstanding amount.
- Notwithstanding anything to the contrary stated elsewhere in these terms and conditions, HSBC

may at its discretion, cancel the limit granted on your credit card account or credit card/add-on card(s) without assigning any reason therefor. In the event HSBC cancels the limit granted on your credit card account or credit card/add-on card(s) in terms of this clause, HSBC shall intimate you on such cancellation.

- The whole of the outstanding balance on the credit card account, together with the amount of any outstanding credit card transactions effected but not yet charged to the credit card account, will become immediately due.
- Any intimation given by HSBC hereunder will be dee med to have been received by you within seven days of posting to your address last notified in writing to HSBC.
- Closure of the credit card may entail withdrawal of all facilities provided through use of the credit card and/or the credit card number.
- Any request for closure of a credit card shall be honored within seven working days by the credit card-issuer, subject to payment of all dues by the cardholder Subsequent to the closure of credit card, the cardholder shall be immediately notified about the closure through e-mail, SMS, etc. Failure on the part of the card-issuers to complete the process of closure within seven working days shall result in a penalty of 500 per day of delay payable to the customer, till the closure of the account provided there is no outstanding in the account.
- Procedure for surrender/closure of card by cardholder - you can exercise any of the following options to initiate closure of your HSBC Credit Card:
- » Login to HSBC Internet Banking with your user ID and password and submit your request through secure message.
- » You can also call HSBC PhoneBanking and register a card closure request.
- » Alternatively, can submit a written request at any HSBC branch.
- » Please remember to cut your card into pieces across the Chip and magnetic stripe, postsubmission of your closure request. For more details, please visit: FAQs for Credit Cards | Help and Support - HSBC IN
- In case of no activity/transaction on the credit card and/or if the credit card account has remained in-operational for a period of &gt; 12 months or any such period as deemed fit by HSBC, HSBC may exercise its right to close the concerned inactive card(s), linked additional card(s) issued to family members and the dormant/in-operational credit card account by providing a 30 days' notice.
- The Cardholder needs to activate the card within 30 days from card issuance date, else, the card will be deactivated permanently in the next 7 days.

## 6.  LOSS/THEFT/MISUSE OF THE CARD

If the credit card is lost/stolen, the cardholder should report it to HSBC immediately in writing or by calling HSBC PhoneBanking Officers at PhoneBanking number 1800 2673456 or 1800 121 2208 or available on https://www.hsbc.co.in/help/contact/. The Bank is merely acting as a facilitator in taking up the dispute through Visa to the concerning merchant. The Bank is thus not liable for the outcome of the investigation.

- Post bank-induced or customer-induced termination of the credit card, all the accrued rewards and cashback on the credit card shall ipso facto stand immediately and automatically cancelled.
- The Cardholder will not be held liable for any transaction made on the credit card after reporting the loss/theft/misuse to HSBC.
- Although loss or theft may be reported as mentioned in (a) above, the cardholder must confirm to HSBC in writing. A copy of the acknowledged FIR must accompany the written confirmation.
- Should the Cardholder subsequently recover the card, the recovered credit card must not be used. Please destroy the card by cutting it into several pieces through the magnetic stripe.
- In case of loss/theft/ misuse of card, the Bank shall be guided by the policy on limited liability of customers available on website. The policy has been formulated basis the RBI circular on Customer Protection - Limiting Liability of Customers in Unauthorised Electronic

Banking Transactions as updated from time to time. (RBI Circular - ref. DBR.No. Leg. BC.78/09.07.005/2017-18 dated 6 July 2017).

- In the event that you lose your credit card, please:
- -Report the loss to HSBC PhoneBanking immediately to block the card or SMS 'BLOCK' to 575750.
- -Request replacement at HSBC PhoneBanking/Branch/Internet Banking - File a police report for the lost/stolen HSBC Credit Card.
- -Please confirm the loss in writing to, The Manager, Credit Cards, Post Box Number 5080, Chennai - 600 028.
- If you recover your HSBC Credit Card after you have reported its loss, please do not attempt to use it.
- Instead, please destroy the HSBC Credit Card by cutting it into several pieces and report the same to HSBC. For more details, please visit: FAQs for Credit Cards | Help and Support - HSBC IN

## 7.  DISCLOSURES

- The Cardholder acknowledges the right of HSBC to provide details of his/her account including those of any add-on cardholder(s), to third party agencies for the purpose of availing of support services of any nature by the Bank, without any specific consent or authorisation from him/her or any add-on Cardholders.
- The Cardholder further acknowledges that HSBC is authorized to share Cardholder(s), to disclose information to such credit bureaus/credit reference agencies. Such entities may further make available processed information or data or products thereof to banks/financial institutions and other credit grantors.
- HSBC may also provide information relating to credit history/repayment record of the cardholder to a credit information company (specifically authorized by the RBI), in terms of the Credit Information Companies (Regulation) Act, 2005.
- Your HSBC Credit Card transactions outside India must be made strictly in accordance with Exchange Control Regulations of the Reserve Bank of India. Kindly note that a cardholder resident in directly/indirectly outside India in any form towards overseas foreign exchange trading through electronic/internet trading portals is prohibited. The card cannot be used for purchase of prohibited items such as lottery tickets, banned or proscribed magazines, participation in sweepstakes, payment for call back services, and / or such items / activities for which no drawl of foreign exchange is permitted. A cardholder making such transactions would make himself/herself/themselves liable to be proceeded against with for contravention of the Foreign Exchange Management Act (FEMA), 1999 besides being liable for violation of regulations relating to Know Your Customer (KYC) norms/Anti Money Laundering (AML) standards. Any violation of the Exchange Control Regulations arising out of utilization of this HSBC Credit Card is the responsibility of the individual HSBC Credit Cardholder.

If the Bank comes across any prohibited transaction undertaken by the cardholder vide credit   card or online banking, the Bank will immediately close the card and the matter will be reported to the Reserve Bank of India. Cardholder (primary/additional) and he/she would be liable for action under the provisions of the Foreign Exchange Management Act (FEMA), 1999 and any other regulations in force from time to time. Please note that the onus of ensuring compliance with the regulations is with the holder of the international credit card.

The HSBC credit Card is valid for use, both in India as well as abroad. It is, however, not valid for making foreign currency transactions in Nepal and Bhutan.

100% payment has to be mandatorily made through Auto pay(standing Instruction) mode from HSBC Bank NRE/NRO account only for NRI customers.

Cash payment will not be accepted for NRI Customers.

In the event of a payment made from a non NRE/NRO source, where bank is able to establish a

non-NRE/NRO source or has a reason to believe it being from a non-NRE/NRO source, bank reserves the right to deactivate the Card.

- GST or any other applicable taxes: Any charges mentioned anywhere in this Schedule of Fees and Charges are exclusive of the GST or any other applicable taxes which is billed along with the fee that appears on the billing statement and is levied as per the applicable GST or any other applicable taxes.
- The Cardholder will not hold HSBC responsible or liable for, any actions, claims, demands, losses, damages, costs, sustain or incur by way of this scheme.
- All and any disputes arising from the Instant EMI facility shall be subject to the exclusive jurisdiction of the courts of Mumbai.
- In particular, jewelry and gold transactions cannot be converted into EMIs as per the guidelines issued by the Reserve Bank of India from time to time.
- The terms of this offer shall be in addition to and not in derogation of the terms contained in the terms and facility for select Cardholders and nothing contained herein terms and conditions for card usage. The words and expressions used herein shall have the same meaning as in the terms and conditions for card usage.
- As per the RBI Master Direction DBR.AML.BC.No.81/14.01.001/2015-16, updated on 28 April 2023, in line with the requirements of Prevention of Money Laundering Rules, HSBC would like to inform that in case of any update in the documents submitted by the customer at the time of establishment of business relationship/account-based relationship and thereafter, as necessary, customers shall submit to the HSBC the update of such documents. This shall be done within 30 days of the update to the documents for the purpose of updating the records at HSBC's end.
- Bank from time to time utilize services of digital lending partners to increase the reach. Effective 27 November 2023, HSBC has tied up with BankBazaar (A&amp;A Dukaan Financial Services Private Limited) as a digital lending service provider for sale of Credit Cards. Click here for more details about BankBazaar &amp; privacy policies - https://www.bankbazaar.com.