## HSBC Live+ Credit Card

<!-- image -->

<!-- image -->

For details on Banking Codes and Standards Board of India (BCSBI), please refer to page no. 77 of this book.

## Key Things You Should Know

1.  HSBC Live+ credit card is globally valid and has been designed to complement your lifestyle. As a Cardholder you get access to a host of offers ranging from travel privileges to dining, shopping and more.
2.   Unlimited* cashback is the key feature of your HSBC Live+ Credit Card. You will be eligible for cashback on all transactions as follows: 10% cashback on all dining, food delivery and grocery spends and 1.5% unlimited cashback on all other spends.
3. *10% cashback is capped at ` 1,000 for each billing cycle.
4. *1.5% cashback is not applicable on certain categories.
5. *The above cashback terms may be subject to change from time to time and HSBC will provide due 30 day notice in case of any change to these terms through your monthly credit card statements and e-mail communication.

Cashback amount paid on transactions that subsequently get reversed, cancelled or nullified (for any reasons) shall be recovered back from the Cardholder by either being adjusted against cashback of the next statement or by debiting the card account in the next statement.

Customers will get four complimentary lounge access, one per quarter.

3.   This card is enabled with Visa Paywave technology that allows contactless payments on your credit card. Under contactless payments, you are not required to input your PIN at the Point of Sale (POS) terminals that supports contactless payments up to the pre-defined limits set on your card.
4.   HSBC Live+ credit card comes with a Joining fee of ` 999 and an annual fee of ` 999. The annual fee will be reversed in full if spends exceed ` 200,000 per year. (The fee will be levied at the end of the anniversary year and will be reversed subsequently on meeting the spend criteria.)
5.   This card can be used for domestic as well as international transactions. However, you need to request for international usage at the time of application of your credit card. To know more about the validity of your card or for details on international usage, please refer to
4. the Frequently Asked Questions (FAQ) or call the HSBC PhoneBanking.
6.   Please visit the credit cards section of our website www.hsbc.co.in for more details on:
- Free credit up to 45 days on purchases under the applicable terms and conditions
- Lost card liability and how to reduce the chances of your credit card being subject to misuse
- Transaction fee and applicable interest for cash advances against your credit card, finance charge (interest) in case the credit card outstanding is not repaid in full by the due date
7.   You need to pay the minimum payment due (you may choose to pay higher) by the payment due date specified on your monthly card statement to avoid transactions getting declined and levy of late payment charge.
8.   Since you earn unlimited* cashback, there is no separate Rewards programme on yourHSBC Live+ Credit Card. For more details on cashback terms, please refer to the section on Cashback Illustration on Page 20.
9.  Making only the minimum payment every month would result in the repayment stretching till the entire outstanding is settled.
10. You need to pay at least your minimum due amount by the due date. Non-payment would impact:
- Your credit rating (reporting to Credit Bureau - CICs)
- Other credit facilities availed from HSBC
- In addition to the above, the Bank can cancel the credit limit and initiate recovery proceedings to recover the dues
11.  The Bank will notify you of any changes in the terms and conditions of this product with prior notice of 30 days.
12.  Please visit `Personal - credit cards' section of our website www.hsbc.co.in for detailed terms and conditions applicable on your credit card.

## Your Credit Card

<!-- image -->

1. The VISA logo: Any establishment displaying the VISA logo accepts yourHSBC Live+ Credit Card worldwide.
2. Chip: This special embedded feature in yourHSBC Live+ Credit Card allows you to transact with ease while adding to the security of your card. The embedded Chip provides the security features that protects your card from fraudulent usage, especially counterfeiting and skimming card frauds.

## How to Use Your Credit Card

## A.  Credit card activation

The credit card has been sent in a deactivated state. You need to activate your primary and add-on cards (if any) before using the same. Download HSBC India Mobile App and activate ,set your PIN and transaction limits by tap 'Manage Card'  by following simple steps . If you are unable to download the mobile app, please call on 1800 121 4015 from your registered mobile number to activate your card and generate a PIN: Please refer page 35 for terms and conditions pertaining to One time SMS OTP for  credit card activation.

## B.  For purchases at merchant establishments

When using your HSBC Live+ Credit Card to pay for products or services, present your HSBC Live+ Credit Card. There can be 2 ways in which your transaction will be processed:

- a. Contactless payment: Now you can use your credit card for contactless payments without needing to input your PIN at the Point of Sale (POS) terminals enabled for contactless payments:
- Please note that domestic payments through contactless mode is allowed for a maximum of ` 5,000 for a single transaction and for international payments, the same is allowed for a maximum amount equivalent to ` 5,000 for a single transaction. (Any change to these   limit caps will be intimated to the customers in accordance with the local regulatory requirements)
3. Transactions above the threshold amount and certain frequency will require a second factor authentication (Pin Validation) and may be restricted in accordance with the Bank's internal policies and guidelines
- Please note that, you will always have the option to choose whether you want to opt for contactless payment at the Point of Sale (POS) terminals enabled for contactless payments. You can also pay normally by using your PIN

## b. CHIP and PIN:

1. The merchant will dip the card into the card reader in the Point of Sale (POS) terminal.
2. The merchant will enter the amount to be paid by you.
- The POS terminal will ask for your PIN, which will be your 6-digit credit card ATM PIN You will be required to enter your credit card ATM PIN on the POS machine for the purchase transaction to successfully go through.
3. The merchant will hand over the receipt along with your credit card. Some acquirers (banks issuing the POS terminals) might require you to sign a sales slip.

When you use your credit card, the merchant may be required to 'refer' the transaction. This does not mean that it has been 'declined' by HSBC but requires the merchant to contact their bankers for approval. During the approval process, you may need to provide your personal details for Verification. These are intended to minimise risks in case your credit card is stolen or lost or there is any unusual activity on your credit card account. Please contact HSBC PhoneBanking if your transaction is declined without any valid reason being given by the merchant.

## C.  For online purchases (e-commerce websites)

Your HSBC Live+ Credit Card can be used for shopping online at websites where VISA cards are accepted.

1. To shop online with HSBC Live+ Credit Card, you would be required to authenticate the transaction using a One Time Password (OTP).
2. When the online transaction is initiated, a pop-up message will appear on the screen asking you to enter the OTP . The 6-digit OTP will be automatically sent by the Bank to your registered mobile number, via SMS.

4

Board of India

3. Enter the 6-digit OTP on the transaction screen to complete the online transaction.

## Please note:

You will be required to register your mobile number with HSBC if not already done so to receive the OTP by way of an SMS. Please call HSBC PhoneBanking to register your mobile number with HSBC. Primary Cardholders who have registered for Internet Banking and secure pay can continue to use the Verified by VISA (VbV) based password authentication instead of the SMS OTP .

## D.  International Usage

To enhance security on your transactions, credit cards issued on or after 01 December 2013 will have an option of setting up international usage facility in addition to the domestic usage facility. Cardholders who choose only the domestic usage facility will not be able to carry out the following kinds of transactions:

1. Point of Sale (POS) transactions outside India.
2. E-commerce transactions on websites (server) located outside India.
3. Transactions at ATMs located outside India.

## E.   PINs and Passwords

You will need your credit card Personal Identification Number (PIN) to use the card at ATMs and for purchase transactions at merchant establishments on Point of Sale (POS) terminals. We will send this PIN to your registered mobile number by SMS within 3 working days after your credit card is issued subject to successful authentication. Refer section below for details on the process to be followed.

You can change this PIN to one of your preference, by using the PIN change facility at any HSBC ATM.

- We will conform to internationally accepted standards for PIN generation, storage and terminal security relating to PINs and passwords. This will ensure confidentiality and security for your protection
- We will send your credit card PIN by SMS to your mobile number registered on our records

Please follow these steps:

| Step 1   | Once your credit card is issued and/or you request for an ATM PIN at HSBC PhoneBanking/Branch (for existing credit Cardholders), we will send you an SMS notification for your credit card ATM PIN on your registered mobile number as available in our records. You need to respond to this SMS by sending a password or authentication code from your same mobile number.   |
|----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Step 2   | The password is a combination of the first two letters of your first name on the card, date of birth as DD/MM and the last 4-digits of your credit card number (no symbols or spaces). SMS this password to +91 9958418884.                                                                                                                                                   |
| Step 3   | After we validate your password, we will send your credit card PIN by SMS. Please treat your PIN as confidential and memorise it. After you use this PIN, you can change it to one of your preference at any HSBC ATM. It is recommended that you delete the PIN SMS for security reasons.                                                                                    |

If you are unable to validate your password/details through an SMS, or if the validation is not successful after two retry attempts, request you   to contact HSBC PhoneBanking or visit your nearest HSBC India branch and request for a new PIN.

The above process will also apply for regeneration of PIN for existing credit cards. You can place the PIN regeneration request by calling HSBC PhoneBanking or by visiting the nearest HSBC India branch or by logging on to the HSBC Personal Internet Banking service and sending a secure message. The PIN will be sent to your registered mobile number via SMS in one (1) day or will be delivered at your registered communication address with us within seven (7) days, after the PIN regeneration request is successfully placed.

## F.   Telephone Banking Personal Identification Number (PIN):

At HSBC, we are dedicated towards making everyday banking simpler and more convenient for our valued customers. Our PhoneBanking services satisfy your banking needs, as you enjoy convenience from the comfort of your home or even when you're traveling abroad. It's quick, secure and at your fingertips.

To bank over the phone, you will require your HSBC PhoneBanking Personal Identification Number (PIN). You can instantly generate your PhoneBanking PIN using a combination of your debit/credit card number and associated PIN by following the steps below:

| Steps to Generate PhoneBanking PIN   | Banking                                                                                                             | Credit Cards                                                                                                        |
|--------------------------------------|---------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| Step 1                               | Call HSBC PhoneBanking and select the language of your choice. Enter your bank account number followed by symbol #. | Call HSBC PhoneBanking, and select the language of your choice. Enter your credit card number followed by symbol #. |
| Step 2                               | To confirm that you do not have a PhoneBanking PIN press # and to set your PhoneBanking PIN select 1.               | To confirm that you do not have a PhoneBanking PIN press # and to set your PhoneBanking PIN select 1.               |
| Step 3                               | Enter your debit card number followed by symbol #.                                                                  | Enter your credit card number followed by symbol #.                                                                 |

| Step 4   | Select 2 and enter your debit card PIN.                                                                                                         | Select 1 and enter your credit card PIN.                                                                                                        |
|----------|-------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Step 5   | Enter a new 6-digit PhoneBanking PIN of your own choice and re-enter the same to confirm. Your PhoneBanking PIN will be successfully generated. | Enter a new 6-digit PhoneBanking PIN of your own choice and re-enter the same to confirm. Your PhoneBanking PIN will be successfully generated. |

Usage of your Phonebanking Personal Identification Number (PIN) and Personal Banking Number or Credit Card Number for accessing PhoneBanking service will be construed as acceptance of PhoneBanking terms and conditions. The terms and conditions for PhoneBanking service are available on the HSBC website www.hsbc.co.in (https://www.hsbc.co.in/accounts/terms/).

## How to Avoid Misuse of Your Credit Card

Based upon HSBC's experience as a global credit card issuer, we have eveloped the following 18 rules to further significantly reduce your chance of being subjected to credit card fraud.

1. Never keep your credit card loosely in your pockets or bags.
2. Always keep your credit card in the same place within your wallet/purse so that you notice immediately if it is missing.
3. Never leave your credit card unattended. Before you dispose the old card, please cut the same across the magnetic stripe/Chip to avoid any misuse.
4. Always memorise your Personal Identification Number (PIN) and change it on a regular basis.
5. Never keep a copy of your PIN in your wallet/purse and never write your PIN on your credit card.
6. Never disclose your PIN to anyone - not even your family members.
7. Never surrender your credit card to anyone other than a merchant when making a purchase. This includes people claiming to be representatives of HSBC/Visa.
8. Always ensure that the merchant processes the transaction on your credit card in your presence and ensure that they do not note down your credit card number, swipe your credit card twice or fill out two sales slips. Never sign an incomplete sales slip.
9. Always take some time to verify that, upon completion of the purchase, the credit card returned to you is yours.
10.  Always call your closest HSBC PhoneBanking if you have any suspicions that your credit card has been lost, stolen or used fraudulently.
11.  Always keep a copy of your credit card details (credit card account number/ expiry date) and any relevant bank addresses/contact numbers in a safe place other than your purse/wallet.
12.  Always keep track of your credit card's billing statement date. If your credit card statement is not received on time, do not hesitate to contact HSBC to
13. ensure that it has been dispatched to your appropriate mailing address. You can also opt for E-statements to avoid delays.
13.  Always notify HSBC, in writing or on phone, of any changes in your employment and/or residential address and telephone numbers.
14.  Never reveal your credit card number/expiry date/PIN and your personal details to an e-mail soliciting your personal information.
15.  Never reveal your credit card number/expiry date/PIN and your personal details to any telephonic survey.
16.  Never seek help from strangers at the ATM even if offered voluntarily while utilizing your credit card at ATMs.
17.  Never hand the consignment containing your HSBC Live+ Credit Card, once delivered to you, back to the delivery person under any condition.
18.  The payments effected via the contactless feature do not require a second factor authentication and may be restricted in accordance with the Bank's internal policies and guidelines. Transactions above a certain threshold amount and frequency/number of transactions will require a second factor authentication. Customer has a choice to effect the payments with or without the contactless feature subject to the thresholds as mentioned above.
19.  Never disclose the Card Verification Value (CVV) on execution of any physical or internet transaction till you are satisfied with the safety and security of the information being shared.

## Credit Cardholder Privileges

## 1. Extended Credit Facility

You can buy now and just pay the minimum payment due and settle the balance later at a specified finance charge of 3.49%* per month (41.88%* per annum). The calculation of the finance charges is explained in detail in the Tariff Sheet.

*Or at such modified rates as decided by HSBC from time to time.

## 2.   Rewards Programme

Since you can earn unlimited* cashback, there is no separate Rewards programme on your HSBC Live+ Credit Card.

## 3.   Lost Credit Card Liability

The credit Cardholder will not be liable for any transaction made on the credit card after reporting the loss/theft/misuse to HSBC. The credit Cardholder is also covered ^  for misuse of the HSBC Live+ Credit Card up to 24 Hrs. before reporting and 7 days after reporting the loss of card to HSBC, for up to ` 100,000.

^ All insurance benefits listed above are provided directly to credit Cardholders by ICICI Lombard General Insurance Company Limited, whose terms, conditions and decisions, for which the Bank is not liable, will apply. Claims for settlement to be sent directly to ICICI Lombard General Insurance Company limited.All insurance benefits on the credit card are available to valid primary Cardholders only.

## 4.   Loan on Phone

YourHSBC Live+ Credit Card provides you with an easy way to pay for the holiday of your dreams, a new TV or a computer through the exciting new `Loan on Phone' feature. It allows you to pay for your purchases (of a minimum of ` 2,000) on your card in convenient monthly instalments.

EMIs are calculated at a low interest rate on monthly reducing balance. All you need to do is call HSBC PhoneBanking within 50

days of making the purchase to convert it into a loan.

## 5.   Balance Transfer-on-EMI

Balance Transfer-on-EMI (BT-on-EMI) is a unique feature that allows you to transfer the outstanding amount on your other bank credit card to your HSBC Live+ Credit Card and repay in easy monthly instalments at a lower interest rate. You can choose from the available repayment tenure options.

## 6.   Cash-on-EMI

The Cash-on-EMI facility allows the Cardholder to avail of the Cash Advance facility on his/her HSBC Credit Card and repay the same in Equated Monthly Instalments (EMI).

## 7.   Balance Conversion (Balcon)

Convert you entire monthly outstanding balance into easy EMI.

## 8.   Instant EMI

Add value to your shopping experience with your HSBC Credit Card and make your shopping a lot more convenient and rewarding. Now buy a wide range of products and services from electronics to travel and more on your HSBC Credit Card and pay in EMIs at your convenience:

- Pay in Equal Monthly Instalments
- Choose from the available repayment tenure options
- No documentation required
- Earn Cashback even on EMI transactions

The processing fees is applicable basis tenure you choose and the merchant at which the purchase is done.

All products (Points 5 -10), if availed, will reflect along with the first EMI amount on the card statement. Interest rates, processing

Your Voice Matters

HSBC PhoneBanking numbers

fee, foreclosure charges and available tenures, as applicable, will be communicated at the time of availing the product. (Please refer to terms and conditions section of this booklet for details).

For more details on these products on rates, processing fee, foreclosure charges and available tenures, visit 'Credit Cards Features' in the credit card section on our website www.hsbc.co.in or call HSBC PhoneBanking.

## 9.   Worldwide Acceptance

Your HSBC Live+ Credit Card is accepted at over 18 million establishments worldwide and over 100,000 establishments in India.

## 10.   Free Credit Period

You can get up to 45 days free credit on purchases without any finance charge being levied on your HSBC Live+ Credit Card Account.

This is applicable, provided your HSBC Live+ Credit Card outstanding, as shown on your statement, is settled in full by the due date. However, if only part payment is made, the interest-free credit period will not be applicable and finance charges will accrue, based on daily balance on the outstanding from the date of the transaction. (Please refer to the tariff sheet for details). However, the free credit period will not be applicable for cash advance transactions.

## 11. International ATM Access

## · Cash Advance

You have access to cash, round the clock, at over 700,000 ATMs worldwide. These include Visa/Cirrus* and all HSBC ATMs. HSBC Live+ Credit Cardholders can withdraw cash from any of the ATMs/authorised money changers/authorised cash advance merchants up to ` 50,000 per day, within the overall limit specified in the Tariff Sheet. Using the cash advance facility will attract a transaction fee and finance charges at the prevailing rate (refer to the Tariff Sheet on page 19).

Finance charges are applied from the date of withdrawal until the entire amount along with the charges are cleared in full. While withdrawing cash over the counter, you will be required to provide additional identification, such as your driving licence or passport.

At HSBC ATMs in India, you can obtain the following services in addition to cash withdrawals:

- Credit card account balance enquiry
- Minimum payment due enquiry
- Payment due date enquiry
- Deposit cash or cheque for credit to your credit card account
- PIN change
- Request for latest credit card statement

This means that you do not have to wait to receive your statement in the post to settle your HSBC Live+ Credit Card dues.

You will need your credit card Personal Identification Number (PIN) to use the card at ATMs and for purchase transactions at merchant establishments on Point of Sale (POS) terminals. We will send this PIN to your registered mobile number by SMS within 3 working days after your credit card is issued subject to successful authentication.

Refer 'PIN and Passwords' section below for details on the process to be followed.

You can change this PIN to one of your preference, by using the PIN change facility at any HSBC ATM.

*HSBC Live+ credit cardholder can access www.visa.com to get complete details on Visa ATM locations in India and other countries worldwide.

International ATM access will be available only on international usage enabled credit cards.

## 12.   Foreign Exchange Entitlement

You can use your HSBC Live+ Credit Card for making payments for expenses up to the credit limit on your HSBC Live+ Credit Card, irrespective of the foreign exchange entitlement under Foreign Exchange Management Act (FEMA), 1999.

## 13.   Access your Bank Account with HSBC India

Your HSBC Live+ Credit Card gives you the unique benefit of  accessing your bank account with HSBC India (if any) for the following banking transactions.

## HSBC ATM India/Overseas:

- Cash withdrawal
- Balance enquiry
- Transfer of funds
- Statement request (India only)
- Chequebook request (India only)
- Non HSBC ATMs India/Overseas(Visa/Cirrus ATM*)
- Cash withdrawal only

Kindly note that the overseas cash withdrawal facility is not available for credit cards linked to NRO accounts.

*Please note that the facility of accessing your bank account is available if you register your bank account with HSBC for the ATM access facility while applying for your Live+ Credit Card. All cash withdrawals overseas must be in accordance with the exchange regulations of the Reserve Bank of India (RBI). A transaction fee is applicable as detailed in the tariff sheet.

## 14.   Internet Banking

Use your HSBC Live+ Credit Card number and credit card ATM PIN to self-register for Personal Internet Banking (Online@hsbc) and create a user ID and password of your choice. You can instantly track your HSBC Live+

Credit Card transactions, download statements and communicate directly and privately through secure online messaging.

## 15.   PhoneBanking

To bank over the phone, you will require your HSBC PhoneBanking Number (PBN) and Personal Identification Number (PIN). Now you can enquire your balance, pay credit card bills and more without actually stepping into HSBC branch.

## 16. Secure Online Payment Service

HSBC secures the usage of your HSBC Live+ Credit Card on the Internet by issuing a One Time Password (OTP) for enhanced security. The OTP will be sent to your registered mobile number via SMS. For details, please visit www.hsbc.co.in

## 17.   Additional Credit Cards

You can apply for up to three additional credit cards for your spouse, your parents, siblings or your children above 18 years. The additional credit cards held by your family members will share the credit limit on your primary credit card. Charges incurred on your additional HSBC Live+ Credit Card will reflect in the primary HSBC Live+ Credit Card statement. Additional credit Cardholders can also access their bank accounts with HSBC using their HSBC Live+ Credit Card.

The annual fee (if applicable) as detailed in the tariff sheet will be included in your statement of account.

Additional cards will not receive a separate monthly statement. The mailing address for the additional card shall be the same as that for the primary card.

The annual fee dates for your additional card and primary card will be aligned to the higher (occurring later in the year) of the card issuance dates for your HSBC Live+ Credit Card.

## Exclusive Privileges For HSBC Live+ Credit Cardholders

## VISA Global Customer Assistance Services

Global Customer Assistance Services are offered round the clock to HSBC Live+ Credit Cardholders by VISA. HSBC Live+ Credit Cardholders can use the VISA Global Customer Assistance Services for a wide range of legal, medical and other services.

HSBC Live+ credit cardholders can access VISA Emergency Assistance Services in over 70 countries including the following countries:

Australia

: 1-800-450346

Singapore

: 800-4481-250

Canada

: 1-866-639-1911

United Kingdom

: 0800-1695189

Hong Kong

: 800-900-782

United States

: 1-866-765-9644

In addition, VISA Emergency Assistance Services are available by placing a collect call to +1 303 967 1090.

Detailed listing of VISA toll free numbers, for various countries are available online at www.visa-asia.com

In India, the toll free number for assistance is Access Code 000 117 then 866 765 9644

## Payment for VISA Global Customer Assistance Services

All expenses for services rendered will have to be borne by the HSBC Live+ Credit Cardholder. All services provided are subject to the terms and conditions of the VISA Global Customer Assistance Services.

## Lost Card Liability

In the event that you lose your HSBC Live+ Credit Card, please report the loss to HSBC or to the VISA Global Customer Assistance Helplines immediately. You are also required to file a police report for the lost/stolen HSBC Live+ Credit Card and send a copy of the acknowledged FIR directly to ICICI Lombard General Insurance Company Limited to enable them to process the insurance claim. Please read the terms and conditions for card usage section of this booklet for details of the claims procedure. To report a lost credit card, you may call any of our HSBC PhoneBanking in India or VISA Global Emergency Assistance Helplines. Please confirm the loss in writing to, The Manager, Credit Cards, Post Box No. 5080, Chennai - 600 028. The Bank will arrange to replace your HSBC Live+ Credit Card as soon as the instructions, in writing, of the loss and requesting for a replacement card, are received, so that you do not miss the convenience of your HSBC Live+ Credit Card for long.

If you recover your HSBC Live+ Credit Card after you have reported its loss, please do not attempt to use it. Instead, please destroy the HSBC Live+ Credit Card by cutting it into several pieces and report the same to HSBC.

To enhance security on your transactions, credit cards issued on or after, 1 December 2013 will have an option of setting up the international usage facility, in addition to the domestic usage facility. Cardholders who choose only domestic usage facility will not be able to carry out the following kinds of transactions:

- Point of Sale (POS) transactions outside India
- E-commerce transactions on websites (servers) located outside India
- Transactions at ATMs located outside India

If you wish to use the card for international transactions, please place a request with HSBC PhoneBanking OR submit a 'Local/International Card Usage Form' at the nearest HSBC Branch in India.

## Cards Usage

1. All credit cards issued after 1 December 2013 will be set up by default for domestic usage only, unless you have opted for international usage at the time of making an application for the credit card.
2. A limit of USD 15,000 per transaction will apply for international transactions done on Chip and PIN enabled credit cards which are used as magnetic stripe cards (subject to your available credit limit).
3. The per transaction limit of USD 15,000 on international transactions will not apply for Chip and PIN enabled credit cards; however if the Chip and PIN enabled credit card is used as a magnetic stripe card (by swiping it at a POS machine) it will be treated as a magnetic stripe card and the USD 15,000 per transaction limit will apply (subject to your available credit limit).
4. You can choose to allow only domestic transactions on your credit card. If you wish to use the credit card for international transactions (unless you have opted for 'international usage' option at the time of application) please place a request with HSBC PhoneBanking OR submit a 'Local/International Card Usage Form' at the nearest HSBC Branch in India.

Add-on cards will be governed by the rules set for the HSBC Primary Credit Card with respect to international usage.

## Monthly Statement

Your monthly HSBC Live+ Credit Card Account statement is a comprehensive record of all activities on your HSBC Live+ Credit Card for the statement period. If you find any discrepancy in the statement, please write into us immediately. For your convenience, a detailed explanation is given below:

Primary HSBC Live+ Credit Card number: This is your primary HSBC Live+ Credit Card Account number.

Name and address: This is your name and address as per our records. Please notify us of any change in your address/telephone number, immediately to ensure timely receipt of your statements.

Credit card type: This refers to your credit card product type i.e. HSBC Live+ Credit Card.

Statement period: This is the period for which transactions on your HSBC Live+ Credit Card are listed in this statement. Note that only transactions received by HSBC during this period are listed. You may have made other transactions that are in the course of processing and thus not listed.

Credit limit: This is the maximum amount, which can normally be outstanding against your HSBC Live+ Credit Card Account at any given time. Your credit card carries a credit limit on the amount of purchase and cash advance. This limit is specified in the mailer accompanying your credit card. On a month on month basis, please refer to your credit card statement for the applicable credit limit on the credit card and you are required to comply with the same.

Date: This refers to the date on which the transaction takes place.

Transaction details: This section lists all domestic and international purchases and cash advances during the month with a brief description of where the transaction was incurred. The name of the merchant establishment where you used your HSBC Live+ Credit Card may differ from that shown on your statement. This happens when the merchant's trading name differs from its registered company name. Your copy of the sales slip will assist with this reconciliation. All overseas transactions (i.e. made in currency other than INR, or the local currency of Nepal and Bhutan) will also reflect the currency of transaction and the amount in foreign currency denomination. This section also acknowledges payments received and balance brought forward, fees charged and any adjustments.

<!-- image -->

Amount: Lists the corresponding transaction amount in INR against each

purchase, cash advance or payment received. The letter 'CR' against an amount indicates a credit to your account.

Minimum payment due: Minimum payment due is subject to a minimum of ` 100,  Refer below and tariff sheet for more details.

Minimum Payment Due (MPD) is higher of ` 100 OR Sum of:

- a. 100% of all Interest, Fees and Taxes billed in the current statement
- b. 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any)
- c. Higher of (Past due*; Over limit amount if any)
- d. 1% of the billed statement balance (excluding any EMI balance, fees, interest and taxes billed)

*Past due refers to unpaid Minimum Payment Due from the previous cycle This is further elucidated through two examples below:

| Example 1: Non overlimit card with no past due   | Example 1: Non overlimit card with no past due   | Example 2: Overlimit card with past due                  | Example 2: Overlimit card with past due                                           |
|--------------------------------------------------|--------------------------------------------------|----------------------------------------------------------|-----------------------------------------------------------------------------------|
| Credit limit Past due Outstanding MPD:           | ` 50,000 ` 0 ` 10,000 = 1%of ` 10,000 = 100      | Credit limit Past due Outstanding Overlimit MPD: 20,000) | ` 50,000 ` 400 ` 70,000 ` 20,000 = 1%of Rupee 70,000 + higher of (400; = ` 20,700 |

If the credit Cardholder does not pay his/her MPD by the payment due date, the credit Cardholder will be levied with late payment fee.

- *EMI amount will be a part of MPD computation if the Cardholder has availed of any instalment products like Loan-on-Phone (LOP), Balance

Transfer-on-EMI, Cash-on-EMI, etc.

Payment due date : You need to pay the minimum payment due by the payment due date to avoid transactions getting declined and the levy of a late payment fee (Refer to the tariff sheet for details).

However, if your statement shows an amount past due, you need to pay this amount along with the amount overlimit (if any) immediately, to avoid transactions getting declined and the levy of late payment fee.

Messages : Useful and important information is provided to you each month through the statement message printed in the transaction area at the end of the statement.

Rewards summary : This gives you the details of the reward points earned. Opening balance reflects points carried forward from your last statement. Points earned reflects the points earned on the spends incurred in this statement cycle. When you redeem your points, it will be reflected in the points redeemed section. Closing balance reflects your total points accumulated less redeemed.

Please note that transactions on your HSBC Live+ Credit Card do not qualify for any additional reward points.

Payment slips : The total payment due and the payment due date are already included on the payment slip. Please attach this to your cheque/draft payment.

When mailing payments to HSBC or making payment through an HSBC ATM/branch please make the cheque/draft payable to your 'HSBC Account number.' (Write your 16-digit credit card number). On the reverse of the cheque/draft please include your contact telephone number and your full name.

- If you have opted to receive the statement on e-mail, HSBC will send the statement in an electronic format to the e-mail ID specified by you. By registering for the e-mail statement option, you agree, confirm and understand that in the event of you opting or requesting to so receive statements vide e-mail on the e-mail ID provided by you to HSBC, no

physical statement will be sent to you by HSBC. You shall forthwith notify HSBC of any change in your e-mail ID for receiving statements as stated in the credit card application form.

HSBC will be deemed to have delivered the statement to the credit Cardholder forthwith upon the same being delivered and HSBC not receiving a delivery failure notification. Should the credit Cardholder experience any difficulty in accessing the electronically delivered statement, the credit cardholder shall promptly advise HSBC, to enable HSBC to make the delivery through alternate means. Failure to advise HSBC, of such difficulty within 24 hours after receiving the statement shall serve as an affirmation regarding the acceptance of the statement by the credit Cardholder. The credit Cardholder confirms that he/she is aware of all security risks involved in receiving the electronically delivered statement. The credit Cardholder agrees that he/she shall not hold HSBC, in any way responsible for the same.

## Settlement of Outstandings of Overseas Transactions

1. Please ensure that usage of your card is in accordance with the relevant Exchange Control Regulations issued and amended by Reserve Bank of India from time to time and adheres to the provisions under the Foreign Exchange Management Act (FEMA), 1999.
2. All expenses incurred overseas must be strictly in accordance with the Exchange Control Regulations of the Reserve Bank of India (RBI). Please note that the aggregate expenses you incur overseas (i.e. through cash/ traveller's cheques/your bank accounts/credit card) should not exceed the limit set by RBI, as prevailing from time to time.
3. Credit Cardholders holding a Resident Foreign Currency (RFC) or External Earners Foreign Currency (EEFC) account may pay for the overseas transactions incurred on their HSBC Live+ Credit Card account by a debit to their EEFC or RFC account. They may enclose a draft in USD or INR as payment.
4. Please note that the 'total payment due' as shown on your HSBC Live+ Credit Card statement reflects the total outstandings on your HSBC Live+ Credit Card account and includes both, domestic and international transactions. Each international transaction will show the amount in the transaction currency together with the corresponding Rupee equivalent amount.
5. All transactions (domestic and international) incurred by your additional credit Cardholders will also be reflected in your HSBC Live+ Credit Card statement. Additional credit Cardholders are also required to ensure that the expenses they incur overseas are strictly in accordance with the Exchange Control Regulations of the RBI.
6. Foreign exchange transactions can be put through the internet provided the purpose is, otherwise allowed under the Foreign Exchange Management Act (FEMA), 1999.
7. Any payment you make towards your HSBC Live+ Credit Card dues will be applied towards repayment of the total outstandings, either domestic or international, of your HSBC Live+ Credit Card account and not against any

single/specific amount charged to the account.

8. To track your overseas spends in order to ensure that they are within the permissible RBI limits, you will have to convert the equivalent Rupee amount shown on your statement for each overseas transaction to USD, using the day's telegraphic transfer selling rate which can be obtained from your authorised dealer.
9. Your HSBC Credit Card transactions outside India must be made strictly in accordance with Exchange Control Regulations of the Reserve Bank of India. Kindly note that a Cardholder resident in India is notified that collecting and effecting/remitting payments directly/indirectly outside India in any form towards overseas foreign exchange trading through electronic/internet trading portals is prohibited and a Cardholder making such transactions would make himself/herself/themselves liable to be proceeded against with for contravention of the Foreign Exchange Management Act (FEMA), 1999 besides being liable for violation of regulations relating to Know Y our Customer (KYC) norms/Anti Money Laundering (AML) standards.

Any violation of the Exchange Control Regulations arising out of utilization of this HSBC Credit Card is the responsibility of the individual HSBC Credit Cardholder.

If the Bank comes across any prohibited transaction undertaken by the Cardholder vide credit card or online banking, the bank will immediately close the card and the matter will be reported to Reserve Bank of India.

Cardholder (primary/additional) would be liable for action under the provisions of the Foreign Exchange Management Act (FEMA), 1999 and any other regulations in force from time to time. Please note that the onus of ensuring compliance with the regulations is with the holder of the international credit card.

10. Please note : Y our HSBC Live+ Credit Card is valid for use both in India and overseas. It is not however, valid for making foreign currency transactions in Nepal and Bhutan i.e. the transactions in currencies other than the local currency of Nepal/Bhutan or in INR.

## Payment Options

You have the choice of eleven convenient modes of payment to settle your monthly dues:

For payment involving cheque/draft, please make this payable to your 'HSBC Account number \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_' (write your 16-digit HSBC Live+ Credit Card number). On the reverse of the cheque/draft please include your contact telephone number and your full name.

## 1. Standing Instruction

If you are an accountholder with HSBC, you can issue a written Standing Instruction (SI) to have a predetermined percentage of your monthly credit card outstanding automatically debited from your account with HSBC on the payment due date. The account you nominate must be either your sole account or a joint account with 'any' or 'either' signing mandate. The system will automatically debit from your designated account and credit your HSBC Live+ Credit Card account. In case your account is not sufficiently funded and the standing instruction is declined, you shall be liable to pay Standing Instruction fail fee which will be levied on your next statement date.

Kindly note that if you make a manual payment(s) greater in value than your predetermined SI amount, the SI will not get actioned for that month.

## For example:

Outstanding amount = ` 50,000 Standing Instruction = 10% of outstanding amount = ` 5,000.

In this case, if a manual payment is made for an amount greater than ` 5,000, then the SI will not get executed.

## 2. National Automated Clearing House

You can make your payment directly by authorising us to debit from an account (4 days prior to your due date) that you hold with any bank. To use this facility , just fill in the application form (please refer to page 25). This facility is available only in Mumbai and New Delhi.

## 3. Internet Banking

You can pay your bills online conveniently by logging into HSBC Personal Internet Banking*.

*Option available for HSBC accountholders only.

## 4. Electronic Fund Transfer

You can make a payment towards your HSBC Live+ Credit Card account via National Electronic Fund Transfer (NEFT), mentioning the complete 16-digit HSBC Live+ Credit Card number.

## 5. VISA BillDesk

Pay HSBC Bank Credit Card bills online from any bank account through Bill Payment Service. Transfer money from your bank account to your HSBC Credit Card online using the BillDesk facility, a third party website with the URL http://billdesk.com/hsbccard/. Visit www.hsbc.co.in for the terms and conditions of the payment service through BillDesk.

## 6. VISA Money Transfer

Transfer money from your bank account to your HSBC VISA Credit Card online using VISA Money Transfer. Please check with your bank, where you maintain your account, for more details on this payment option.

## 7. Mail Cheque/Draft

You can mail a cheque/draft, to the HSBC branch closest to you. Collection charges will not be levied for any HSBC cheques, or other bank cheques which are both payable and deposited in Ahmedabad, Bengaluru, Chandigarh, Chennai, Coimbatore, Gurgaon, Hyderabad, Jaipur, Ernakulam, Kolkata, Mumbai, New Delhi, Noida and Pune, but will be levied (as per the tariff sheet) for cheques payable in other cities. In order to avoid being charged a late payment fee, please ensure that your cheque reaches us within three working days prior to your payment due date as this will ensure that your cheque is cleared in good time. You are requested not to deposit any post- dated cheques while settling your HSBC Live+ Credit Card dues.

## 8. PhoneBanking

You can use our HSBC PhoneBanking service to pay your HSBC Live+ Credit Card bills conveniently. This facility of payment of credit card bills through HSBC PhoneBanking is available only to those credit Cardholders who maintain savings/current accounts with HSBC. For further details, please contact HSBC PhoneBanking.

Please note that payments made through Internet Banking and HSBC PhoneBanking will take place on the next working day.

## 9. Through ATMs

You can settle your HSBC Live+ Credit Card bills by depositing cash or a cheque into your HSBC Live+ Credit Card account using HSBC ATMs in India, at any time of the day or night. If you are an accountholder and have opted for the ATM access to your bank account with HSBC (as detailed in the privileges section of this booklet), you can also transfer funds from your savings or current account to your HSBC Live+ Credit Card account in settlement of your dues. Payment will reflect in the HSBC Live+ Credit Card account at the end of the processing day/ working day.

## 10.  Over the counter

You can also make your payments by cash or cheque, quoting your 16-digit HSBC Live+ Credit Card number, at any HSBC branch in India and your cash or cheque will be deposited into your HSBC Live+ Credit Card account. Please note that a charge of ` 100 will be levied as cash payment charge (HSBC Credit Card bill payment made in cash at HSBC Branches).

TheHSBC Live+ Credit Card is issued by The Hongkong and Shanghai Banking Corporation Limited, India with its India Corporate Office at 52/60 Mahatma Gandhi Road, Mumbai - 400 001, India (HSBC), on the applicable terms and conditions (Please refer to the terms and conditions section of this booklet).

## 11.  HSBC Mobile Banking

Pay when you are on the move by logging into HSBC Mobile Banking. (You need to be registered for Internet Banking to access Mobile Banking).

## 12.  PayU Payment Service

Pay HSBC Bank Credit Card bills online from any bank account through PayU Payment Service. Transfer money from your bank account to your HSBC Credit Card online using the PayU facility, a third party website with the URL https://securepayments.payu.in/hsbc-credit-card-payment.

Visit www.hsbc.co.in for the terms and conditions of the payment service through PayU.

## Tariff Sheet

| Standard joining fees                                                                                                                                                                   | ` 999                                                                                                                                                                                 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Standard annual fees                                                                                                                                                                    | ` 999 (Waived off for annual spends of ` 200,000 or more). Fee will be charged at the end of the anniversary year and will be reversed off subsequently on meeting the spend criteria |
| Balance transfer charges:                                                                                                                                                               | Rate of interest: 10.99% p. a. to 15.99% p. a. across tenures                                                                                                                         |
| Balance transfer charges:                                                                                                                                                               | Processing fee: 1.5% subject to a minimum of ` 200                                                                                                                                    |
| Standard annual fees for Premier Customers                                                                                                                                              | Nil                                                                                                                                                                                   |
| Free credit period                                                                                                                                                                      | Up to 45 days Please note that the free credit period is not valid if any balance of the previous months' bills are outstanding                                                       |
| Finance charges on extended credit                                                                                                                                                      | 3.75% per month (45% per annum) computed from the date of transaction or at such modified rates as decided by HSBC from time to time                                                  |
| Finance charges on cash advance and transactions in categories such as money transfer (wire transfer), foreign currency purchase, money orders, traveler cheques, debt repayments, etc. | 3.75% per month (45% per annum) computed from the date of transaction                                                                                                                 |

| Minimum Payment Due (MPD) on credit usage                                               | Higher of ` 100 OR Sum of: a. 100% of all Interest, Fees and Taxes billed in the current statement b. 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any) c. Higher of (Past due*; Over limit amount if any) d. 1%of the billed statement balance (excluding any EMI balance, fees, interest and taxes billed) *Past due refers to unpaid Minimum Payment Due from the previous cycle   |
|-----------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Charge in case of bounced cheque, dishonoured SI or unsuccessful payment through NACH   | ` 500                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Cash advance limit # (against credit card account)                                      | Up to 20% of the credit limit                                                                                                                                                                                                                                                                                                                                                                                                 |
| Transaction fee for cash advances against your credit card account at branches and ATMs | 2.5% of transaction amount (subject to a minimum amount of ` 500) 2                                                                                                                                                                                                                                                                                                                                                           |
| Transaction fee for cash withdrawal against your bank account at ATMs overseas          | ` 100 at ATMs overseas                                                                                                                                                                                                                                                                                                                                                                                                        |
| Transaction fee for cash withdrawal against your bank account                           | Nil                                                                                                                                                                                                                                                                                                                                                                                                                           |

NOTE: All fees will be charged along with applicable taxes.

| Overlimit fee                                                                                                  | 2.5% of the overlimit amount or INR 500 (whichever is higher) + applicable GST                     |
|----------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------|
| Late payment fee (Charged if the minimum amount is not credited in the card within 3 days of Payment Due Date) | 100% of the minimum payment due (subject to a minimum of ` 250 and a maximum of ` 1,200 per month) |
| Currency conversion charge for foreign currency transactions                                                   | 3.5%                                                                                               |
| Balance enquiry on the credit card at other bank ATMs                                                          | Nil                                                                                                |
| Cash payment charge (HSBC Credit Card bill payment made in cash at HSBC branches and drop-boxes)               | ` 100                                                                                              |

## Finance Charge Illustration

Let's say you purchase a watch for ` 1,200 on 01 March and a necklace for ` 800 on 10 March. The following interest will be charged on your purchases:

| Outstanding due in the 20 March statement                      | ` 2,000.00   |
|----------------------------------------------------------------|--------------|
| Payment made on the due date of 04 April                       | ` 100.00     |
| Balance carried forward (revolved)                             | ` 1,900.00   |
| Interest calculations: (3.49% p.m.)                            |              |
| a) Interest on ` 1,200 for 35 days (from 01 March to 04 April) | ` 51.00      |
| b) Interest on ` 800 for 26 days (from 10 March to 04 April)   | ` 25.00      |
| c) Interest on ` 1,900 for 15 days (from 05 April to 20 April) | ` 37.00      |
| Total interest charged in the 20 April statement               | ` 113.00     |
| GST @18.00% on interest                                        | ` 20.00      |
| Outstanding due in the 20 April statement                      | ` 2033.00    |

Making only the minimum payment every month would result in the repayment stretching till the entire outstanding is settled and consequent payment on your outstanding balance during this extended period.

## Note:

No refund of annual fee will be available if the credit card is terminated. Tariff structure is subject to change from time to time at the sole discretion of HSBC. The Bank will notify you of any changes in the terms and conditions of this product with prior notice of 30 days. Please be advised that applicable Indirect Taxes including Goods and Services Tax (GST) would be recovered on all our fees and charges and any other amount liable to tax under prevailing Indirect Tax Laws.

The credit limit and cash withdrawal limit (20% of credit limit or as decided by the Bank from time to time) are communicated to you in your monthly card statement.

The available credit limit is provided as part of the monthly card statement.

The Bank reserves its right to reduce the credit limit without any prior notice or intimation. Usage of the credit card shall be deemed as acceptance of the credit limits granted from time to time.

## Cashback Illustration

Let's say the Bill cycle/statement date of the case is 2 nd  of every month. Following table provides the:

| Bill Statement date                                                          | 2 nd of every month   |
|------------------------------------------------------------------------------|-----------------------|
| Transaction made on 5 th of April (on dining)                                | ` 5,000               |
| Transaction made on 10th of April (on online shopping)                       | ` 2,000               |
| Next bill statement                                                          | 2 nd of May           |
| Due date                                                                     | 17 th of May          |
| Eligible cashback amount to be posted within 45 days from the statement date | 17 th of June         |
| Eligible Cashback amount (10% of ` 5,000 + 1.5% of ` 2,000)                  | ` 530                 |

Transactions will be eligible for Cashback as follows,

- -10% cashback on all dining, food delivery and grocery transactions (capped upto ` 1,000 per billing cycle)
- -1.5% unlimited cashback on other spends
- -No cashback on following categories: Fuel related (MCC 5541, 5983, 5172, 5542, 5552), e-wallets (MCC 6540), payment of property management fees, rental commissions, rental payments or any such payments made through MCCs 6513, 7012, 7349, Business to Business txns made through MCCs 7399, 7311, 7372, 5045, 5047, 5065, 5072, 5111, 5013, 2741, 5137, 5192, 5193, 5131, 7361, 5085, 7333, 5039, 7379, 5021, 5199, 5122, 5099, 5198, 5139, 7829, 7395, 5051, 5046, 5169, 7375, 5074, 8734, 5044, 2842, 2791, education and government related txns carried out through MCCs 9399, 8299, 8220, 8211, 8241,

9311, 8244, 8249, 9222, 9402, 9211, 9405, 9950, 9223, 8351), Insurance (MCC 6300, 5960), Jewelry &amp; Antique items (MCC 5944, 5094, 5932,

5937), Gambling (MCC 7995), Tolls and Bridge Fees (MCC 4784), Financial and Non-Financial Institutions (MCC 6011, 6010, 6012, 6051), Security Broker Services (MCC 6211), Collection Agencies (MCC 7322), Charity (MCC 8398, 8641), Money Transfers (MCC 4829) and Wholesale Clubs (MCC5300)

Cashback amount paid on transactions that subsequently get reversed, cancelled or nullified (for any reasons) shall be recovered back from the Cardholder by either being adjusted against cashback of the next statement or by debiting the card account in the next statement.

Customers need to make the minimum payment due by the due date as mentioned in the credit card statement every month.

## Late Payment Charges Illustrative examples of how Late Payment Charges are calculated

Late payment fee (Charged if the minimum amount due is not credited in the card by the payment due date) is 100% of the Minimum Payment Due (MPD) - Subject to minimum fees of ` 250 and maximum fees of ` 1,200 per month. Please note that the Late Payment Fees is levied only if the Minimum Payment Due is not paid by the due date. Illustrative examples of how Late Payment Charges are calculated - Assume you receive a statement for the period 16 October - 15 November, with a payment due date of 07 December. Payment of Minimum Payment Due (MPD) is required to be received in the card account by the payment due date (07 December) to ensure that no late payment fees are levied. Late payment fees will be levied as per the illustration in the table given below:

| MPD ( ` )   | Late payment charges ( ` )   | Description                                                                                                                            |
|-------------|------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|
| ` 100       | ` 250                        | 100% of MPDi.e. on ` 100 is ` 100. Since the minimum fee is ` 250, the late payment fee levied will be ` 250                           |
| ` 250       | ` 250                        | 100% of MPDi.e. on ` 250 is ` 250, hence the late payment fees levied would be ` 250                                                   |
| ` 500       | ` 400                        | 100% of MPD, i.e. ` 500 is ` 500, hence the late payment fees levied would be ` 500                                                    |
| ` 1,500     | ` 1,200                      | 100% of MPD, i.e. on ` 1,500 is ` 1,500. However since maximum fee applicable is ` 1,200, the late payment fee levied would be ` 1,200 |

Banking Codes and Standards Board of India

## Payment Hierarchy

Payment made to the Cardholder's account will be first settled in the order of occurrence to the extent of minimum payment due, by the following 'plans' i.e. EMI, cash advances, purchase outstanding and balance transfer in descending order of interest rates, and within a given 'plan'. the payment will be allocated to a predefined order of:

1. Service charges*
2. Interest/finance charges
3. Late payment fee
4. Annual fee
5. Overlimit fee
6. Instalment handling fee
7. Instalment processing fee
8. Return cheque charges
9. Insurance premium
10.  Principal**

The excess payment (if any) over and above minimum payment due will be allocated to the same hierarchy as defined above.

In addition, the allocation of payment will be such that the transaction/fees billed after your last statement but not yet paid, will get paid off before any charges/ fees incurred after your last statement date and are yet to be reflected in your statement.

*Service charges include the following:

Cash Advance Fee, GST, Card Replacement Fee, Statement Reprint Fee, Balance Transfer Processing Fee, Standing Instruction (SI) Failed Fee.

**Principal - includes purchase amount, Balance Transfer principal amount and cash withdrawn on the credit card.

## Debit Mandate Form NACH/ECS/DIRECT DEBIT

UM RN

gggggggggggggggggggg

Date

gg gg gggg

Sponsor Bank Code

ggggggggggg

Utility Code

gggggggggggggggggg

Tick (  )

I/We hereby authorise

to debit

CREATE g

MODIFY g

Bank account no.

gggggggggggggggggggggggggggggg

CANCEL g

with Bank                                                                                                     IFSC

ggggggggggg

or MICR

ggggggggg

an amount of Rupees

FREQUENCY

g Mthly

g Qtly

g H-yrly

g Yrly

g As and when presented                DEBIT TYPE

g Fixed Amount

g Maximum Amount

Client ID                                                                                                                                                                         Phone No.

Ref. ID                                                                                                                                                                               E-mail ID

`

D   D      M  M      Y    Y    Y    Y

I agree for the debit of mandate processing charges by the Bank whom I am authorising to debit my account as per latest schedule of charges of the Bank.

<!-- image -->

- This is to confirm that the declaration has been carefully read, understood and made by me/us. I am authorising the User entity/Corporate to debit my account
- I have understood that I am authorised to cancel/amend this mandate by appropriately communicating the cancellation/amendment request to the User entity/Corporate or the Bank where I have authorised the debit

## Summary of Key Features and Terms

## HSBC Live+ credit card

| Quick facts            |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |                                                               |
|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------|
| Live+ Credit Card      | The HSBC Live+ Credit Card is designed to complement your lifestyle and is a symbol of recognition and status wherever you go. Your card comes packed with features designed to suit your lifestyle and taste that you are already accustomed to: This card can be used at merchant establishments having Point of Sale payment facility (including contactless feature) and can also be used for online transactions on e-commerce websites. HSBC cards provide enhanced security through an embedded Chip to protect your card from fraudulent usage and PIN verification for your purchase transactions at merchant establishment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | HSBC Live+ credit card Service Guide and Cardholder Agreement |
| HSBC Live+ Credit Card | Unlimited* HSBC Live+ Credit Card is the key feature of your HSBC Live+ Credit Card. You will be eligible for cashback on all transactions as follows: • 10% HSBC Live+ Credit Card on all dining, food delivery and grocery transactions (capped upto ` 1,000 per billing cycle) • 1.5% unlimited HSBC Live+ Credit Card on other spends • No HSBC Live+ Credit Card on following categories: Fuel related (MCC 5541, 5983, 5172, 5542, 5552), e-wallets (MCC 6540), payment of property management fees, rental commissions, rental payments or any such payments made through MCCs 6513, 7012, 7349, Business to Business txns made through MCCs 7399, 7311, 7372, 5045, 5047, 5065, 5072, 5111, 5013, 2741, 5137, 5192, 5193, 5131, 7361, 5085, 7333, 5039, 7379, 5021, 5199, 5122, 5099, 5198, 5139, 7829, 7395, 5051, 5046, 5169, 7375, 5074, 8734, 5044, 2842, 2791, education and government related txns carried out through MCCs 9399, 8299, 8220, 8211, 8241, 9311, 8244, 8249, 9222, 9402, 9211, 9405, 9950, 9223, 8351), Insurance (MCC 6300, 5960), Jewelry &Antique items (MCC 5944, 5094, 5932, 5937), Gambling (MCC 7995), Tolls and Bridge Fees (MCC 4784), Financial and Non-Financial Institutions (MCC 6011, 6010, 6012, 6051), Security Broker Services (MCC 6211), Collection Agencies (MCC 7322), Charity (MCC 8398, 8641), Money Transfers (MCC 4829) and Wholesale Clubs (MCC5300) *The above HSBC Live+ Credit Card terms may be subject to change from time to time and HSBC will provide due notice of 30 days in case of any change to these terms | HSBC Live+ credit card Service Guide and Cardholder Agreement |

|                                                                                                                                                                                                      | HSBC Live+ Credit Card amount paid on transactions that subsequently get reversed, cancelled or nullified (for any reasons) shall be recovered back from the cardholder by either being adjusted against cashback of the next statement or by debiting the card account in the next statement.   | HSBC Live+ Credit Card amount paid on transactions that subsequently get reversed, cancelled or nullified (for any reasons) shall be recovered back from the cardholder by either being adjusted against cashback of the next statement or by debiting the card account in the next statement.   |                                                                                                               |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------|
| Low Interest Instalment Plans                                                                                                                                                                        | Choose from a varied low interest option to repayment in instalments such as: • Balance transfer on EMI • Loan on Phone • Cash on EMI                                                                                                                                                            | • Balance conversion                                                                                                                                                                                                                                                                             | Refer page 57 to 67 of Terms and Conditions section of this booklet                                           |
| ATM Facility                                                                                                                                                                                         | For customers holding a bank account with HSBCIndia, the facility of accessing bank account through the credit card at ATM's is available on request                                                                                                                                             | For customers holding a bank account with HSBCIndia, the facility of accessing bank account through the credit card at ATM's is available on request                                                                                                                                             | Refer page 10 of Service Guide section of this booklet                                                        |
| Other benefits                                                                                                                                                                                       | Other benefits include: • VISA Bill Desk online bill payment service • eStatement • PhoneBanking service                                                                                                                                                                                         | • One time password for secured transactions • Personal Internet Banking service                                                                                                                                                                                                                 | Refer page 17, 18 of Service Guide section of this booklet                                                    |
| Financials                                                                                                                                                                                           | Financials                                                                                                                                                                                                                                                                                       | Financials                                                                                                                                                                                                                                                                                       | For more information                                                                                          |
| For details on the annual fee, finance charge, transaction fee for cash advance and other charges please refer to the Tariff Sheet in the Service Guide. Illustration on Finance Charge calculation. | For details on the annual fee, finance charge, transaction fee for cash advance and other charges please refer to the Tariff Sheet in the Service Guide. Illustration on Finance Charge calculation.                                                                                             | For details on the annual fee, finance charge, transaction fee for cash advance and other charges please refer to the Tariff Sheet in the Service Guide. Illustration on Finance Charge calculation.                                                                                             | Refer page 19 of Service Guide section of this booklet Refer page 21 of Service Guide section of this booklet |

| Other Key Terms                           | Other Key Terms                                                                                                                                                                                                                                                                                                                                       | For more information                                                         |
|-------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|
| Credit Limit                              | The card carries a credit limit on the amount of purchase and cash advance. Wemay vary the credit limit on the card at any time as we consider appropriate based on periodic assessment of credit risks associated with the card account                                                                                                              | Refer page 38 of Terms and Conditions section of this booklet                |
| Additional Cardholder                     | Individual receiving a supplementary card at the request of the primary Cardholder An additional Cardholder will be responsible for the use of the supplementary card. The primary Cardholder will be responsible for the use of his primary card as well as the use of each supplementary card by an additional Cardholder and for repayment of dues | Refer page 42 of Terms and Conditions section of this booklet                |
| Notification of unauthorised transactions | You should notify our contact centre of any transaction not authorised by you                                                                                                                                                                                                                                                                         | Refer page 89 of Most Important Terms and Conditions section of this booklet |
| Payment hierarchy                         | The sequence in which we apply payments and credits to the card account to repay the statement balance payment will first be settled in the order of occurrence to the extent of Minimum payment due, first by the following 'plans'                                                                                                                  | Refer page 22 of Service Guide section of this booklet                       |
| Repayment                                 | You may repay the statement balance in full or in part subject to paying the Minimum Payment Due and finance charges                                                                                                                                                                                                                                  | Refer page 15 of Service Guide section of this booklet                       |
| Protecting the Card                       | You and any additional Cardholder are responsible for taking appropriate security measures to prevent the card from being misused                                                                                                                                                                                                                     | Refer page 6 of Service Guide section of this booklet                        |

## Your Voice

- At HSBC, we want to make sure that you get the best of service from us - service which you, our valued customer, deserves. If at any stage, you have any queries or feel that our service levels are not up to your expectations, here is what you can do:
- Write to us: The Manager, Customer Care Centre, The Hongkong and Shanghai Banking Corporation Limited, Rajalakshmi, No. 5 and 7, Cathedral Road, Chennai - 600 086
- Visit the nearest HSBC Branch
- Full terms and conditions contained in the credit card Cardholder agreement apply to your Live+Credit Card. The information contained in the table providing the summary of key terms summarises key product features and is not intended to replace any terms and conditions. The full terms and conditions will prevail in the event of any inconsistency between the full terms and conditions and the summary of key terms.

## Terms and Conditions ofHSBC Live+ Credit Card

THEHSBC Live+ Credit Card IS ISSUED BY THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMITED, INDIA WITH ITS INDIA CORPORATE OFFICE AT, 52/60 MAHATMA GANDHI ROAD, MUMBAI - 400 001, INDIA (HSBC), ON THE FOLLOWING TERMS AND CONDITIONS:

Important: Before you use your credit card, please read these terms and conditions carefully. By using the credit card, you are accepting the terms and conditions set out below and will be bound by them.

Unless the context requires otherwise the terms defined shall have the same meaning attributed to them herein:

## Definitions

1. 'Account' shall mean any account with HSBC, including aHSBC Live+ Credit Card Account, Savings Account(s), Current Account(s), Fixed Deposit Account(s) and/or any loan/overdraft account.
2. 'Additional Credit Cardholder/Add-on Cardholder' means an applicant who is an individual to whom aHSBC Live+ Credit Card bearing that individual's name is issued by HSBC although the liability is shared, jointly and severally, with the primary credit Cardholder.
3. 'Alerts' means the customised messages sent as Short Messaging Service (SMS) to the credit Cardholder over his mobile phone.
4. 'Applicant' means: any person who has signed theHSBC Live+ Credit Card application form, which is accepted by The Hongkong and Shanghai Banking Corporation Limited (HSBC).
5. 'Authentication' means validation of an online transaction using the OTP.
6. 'Billing cycle' means the period for which the credit card statement is generated.
7. 'Cashback' means the amount that is credited back to the Cardholders's credit card account and is adjusted against the amount payable by the Cardholder for that billing cycle.
8. 'Credit Card' means, theHSBC Live+ Credit Card issued by HSBC to an applicant.
9. 'Credit Card Account' means the account opened and maintained by HSBC for the purpose of use of theHSBC Live+ Credit Card account as per the terms and conditions contained herein.
9. 'Chip' means, Chip embedded in HSBC India Credit Card issued by HSBC India to a Cardholder. The embedded Chip provides enhanced security features. In addition to this, the Chip card also has a magnetic stripe (magstripe card) to support fall back transactions on the Chip card.
10. 'Contactless' or 'Contactless payment' means the feature enabled with Visa payWave for contactless payments. Visa payWave is a technology that allows contactless payments on your credit card. Under contactless payments, you are not required to input your PIN at the Point of Sale (POS) terminals that supports contactless payments up to the pre-defined limits set on your card.
11.  A 'Credit Card Upgrade' is defined as changing the card type (Classic/ Live+) to a higher category card. For e.g. Classic Credit Card toHSBC Live+ Credit Card to Credit Card.
12. A 'Credit Card Downgrade' is defined as changing the card type to a lower category card. For e.g. Premier Credit Card to Advance Credit Card.

13.  A 'Credit Card Transfer' is defined as changing the card type to a card of equivalent category. For e.g. Credit Card to an Advance Credit Card.
14. 'Credit Cardholder' means an applicant who has been issued a Chip Credit Card by HSBC.
15. 'Credit Limit' means the maximum amount that can be outstanding against the credit card account at any point of time.
16. 'CSP' means the Cellular Service Provider with whom HSBC has an arrangement for providing the facility.
17. 'Fallback' refers to the payment transaction effected on the credit card by swiping the card on a Point of Sale (POS) terminal which is not enabled on Chip cards. Such POS transactions are processed based on the information contained in the magnetic stripe of the card instead of information on the Chip and will be treated as magnetic stripe card transactions and USD 15,000 per transaction limit will thereby apply for international transactions (subject to your available credit limit).
18. 'Finance Charge' means the interest that is levied on the Live+ Credit Card account when the full payment is not made by the due date. A description of the finance charge computation and associated interest rate can be found in the Tariff Sheet on page 19 in the service guide section of this booklet.
19. 'HSBC' means The Hongkong and Shanghai Banking Corporation Limited, India, its successors and assignees also referred to as 'The Bank'.
20. 'International Transactions' mean transactions carried out by the credit Cardholder on his/her internationally valid Credit Card outside India, Nepal and Bhutan.
21. 'Late Payment Fee' is the charge levied on the Credit Card account when the credit Cardholder fails to make a payment for an amount more than or equal to his minimum payment due by the payment due date as mentioned in the monthly Credit Card statement.
22. 'Merchant Establishments' shall mean establishments wherever located which honour the Live+ Credit Card and shall include amongst others, stores, shops, restaurants, hotels, airline organisations and mail order advertisers,
11. including mail order outlets (whether retailers, distributors or manufacturers), advertised by HSBC or VISA International.
23. 'Minimum Payment Due' means minimum payment at such rates applicable from time to time and as advised by HSBC in the tariff sheet. The Minimum Payment Due (MPD) calculation is explained in page 14 of the service guide section of this booklet.
24. 'Net Outstanding Balance' means the amount outstanding on the statement billing date including, the unbilled instalments in addition to outstanding amounts on purchases, cash withdrawals, balance transfers and Loan-onPhone transactions on the credit card.
25. 'Payment Due Date' means the date by which payment must be received by HSBC.
26. 'Person' means any individual, corporation, firm, company, institution, or other natural or legal person whatsoever.
27. 'Primary Credit Cardholder/Credit Cardholder' means an applicant in whose name HSBC has determined to open a primary Credit Card account.
28. 'Product Provider' means third parties who are in the business of providing products and services.
29. 'Service Provider' means third party utility service provider or any other service provider, for e.g. CSP , Electricity Distributor, Gas Distribution Agencies, Insurance Providers, etc.
30. 'SMS' refers to short message service which allows you to receive text messages sent through a mobile service network.
31. 'SMS Facility' means the facility of receiving alerts through the Short Message Service offered by cellular service providers.
32. 'Statement' means a monthly statement of the Credit Card account sent by HSBC to a credit Cardholder setting out the financial liabilities on that date, of the primary credit Cardholder and any additional credit Cardholder to HSBC in respect of the Credit Card account.
33. 'Total Payment Due' means total payment due in the current month.

34. 'Transaction' means any instruction given by an individual using a Credit Card directly or indirectly to HSBC to effect action on the Credit Card (examples of 'transaction' instructions could be a sales slip, a cash advance slip or a mail order coupon).
35. 'Verbal Application' means Credit Cardholder's request/consent obtained on a recorded telephonic interaction with HSBC or its representatives.
36. 'PIN' means a Personal Identification Number used in conjunction with a card.
37. 'POS' refers to electronic Point of Sale swipe terminals that permit the debiting of the card account for purchase transactions at merchant establishments.
38. 'Dip' refers to inserting the Chip card at the POS terminal slot/Chip reader for initiating the card payment transaction by processing the information in the Chip.
39. 'Swipe' refers to the act of swiping the card in the POS terminal slot/ reader for initiating the card payment transaction by processing the information in the magnetic stripe at the back of the card.
40. 'One Time Password (OTP)' means any password(s) or other means of authentication as we may specify from time to time, which will facilitate your making online credit card payments through the internet in a secure manner.
41. 'ECOM' means transactions done through online platform/website.
42. 'We' , 'our' and 'us' means The Hongkong and Shanghai Banking Corporation Limited.
43. 'You' , 'your' means the person to whom we issue a card (whether a primary card or add-on card).
- 'International Usage' means the usage of the credit card for -
- Point of Sale (POS) transactions carried out outside India
- E-commerce transactions on a website (server) which is located outside India
- Transactions at ATMs located outside India
44. 'Local/Domestic Usage' means the use of the credit card to carry out transactions within India.
45. Dormant/Inoperative Account: A dormant/inoperative account is a credit card account which is not operated upon for a period of 12 months or as applicable from time to time by HSBC.

## Exclusions and Exceptions

We shall not be responsible or liable to you for any inconvenience, loss or damage or embarrassment incurred or suffered in any of the following events:

- a. HSBC, a merchant, or other bank or financial institution or any other party refuses to accept the credit card or to accept any transaction for any reason whatsoever; or
- b. HSBC, its servants, agents or contractors are unable to perform any of its obligations under this agreement, whether due directly or indirectly, to the failure of any machine, data processing system or transmission link or industrial or other dispute, any act of God or anything beyond the control of HSBC, its servants, agents or contractors or as a consequence of any fraud or forgery;
- c. Any malfunction, defect or error in any ATM or other machines or systems whether belonging to or operated by HSBC or otherwise, howsoever caused;
- d. Any rejection of your credit card or the PIN of your credit card by any ATM or other machines or any failure to effect or complete any transaction, howsoever caused;
- e. Any neglect, refusal or inability on our part to authorise or approve any credit card or to honour or effect any other transaction on the account for any reason whatsoever; or
- f. Any damages to or loss of or inability to retrieve any data or information that may be stored in your credit card or any microchip or circuit or device in your credit card, howsoever caused.

We shall not be liable in any way for the goods purchased or services rendered and paid for by the use of the credit card or the delivery, quality

HSBC PhoneBanking numbers

or performance of such goods or services.

We shall also not be responsible for any benefits, discounts or programmes of any merchant or other person that we may make available or introduce to you. We shall be entitled to charge to and debit from the account in respect of all transactions effected by use of your credit card, or the PIN of your credit card in spite of the non-delivery or non-performance of or any defect in those goods or services or the failure of any person to provide or make available to you any of those benefits, discounts or programmes. You must seek redress in respect of such goods, services, benefits, discounts and programmes from that person directly.

In the event of any dispute between you and any merchant or bank or financial institution or any other person, your liability to us shall not in any way be affected by such dispute or any counterclaim, right of set-off or contractual right which you may have against such merchant or bank or financial institution or person. We shall not in any event be responsible or liable to you for any consequential or indirect economic loss, howsoever caused, incurring or arising.

On credit cards without international usage facility, transactions originating from outside India are not permitted by RBI. Hence, such transactions will be declined by HSBC.

You may not assign your rights under this agreement.

We may at our discretion make available to you from time to time additional benefits, services or programmes in connection with the use of your credit card. Such benefits, services or programmes shall nevertheless not form part of our legal relationship with and obligations to you.

You hereby acknowledge that any merchant may at any time and from time to time without prior notice restrict, exclude, modify or suspend the benefits and/ or privileges accorded to credit Cardholders under any privilege schemes at that participating merchant.

TheHSBC Live+ Credit Card is valid worldwide.

On the request of the primary credit Cardholder, HSBC may issue add-on credit card(s) to the person(s) who is/are not of age less than 18 years. The primary credit Cardholder shall irrevocably confirm all dues in respect of the HSBC Credit Card(s) utilised for services availed of and goods purchased from eligible service establishments/merchants and any add-on Cardholder(s) will be payable by the primary credit Cardholder and the primary credit Cardholder guarantees the payment towards the same in his/her capacity as the principal Cardholder. The primary credit Cardholder acknowledges that the existence of this account and details thereof (including details of credit card transactions and any defaults committed by the primary credit Cardholder), will be recorded with credit reference agencies and such information (including processed information) may be shared with banks/financial institutions and other credit grantors for the purpose of assessing further applications for credit by the primary credit Cardholder and/or members of his household, and for occasional debt tracing and fraud prevention. The primary credit Cardholder authorises HSBC to share information relating to his/ her credit card account, including information relating to any add-on Cardholder(s).

If you are a primary Cardholder, you are required to ensure that each additional Cardholder uses and handles his card and related matters in accordance with this agreement.

1. If the credit Cardholder needs to surrender the credit card to HSBC, the same shall be cut into several pieces through the magnetic stripe before surrendering the same. If the credit card is surrendered without cutting into several pieces, the credit Cardholder shall remain liable for any misuse that takes place subsequent to the credit card being surrendered to HSBC. This applies to any method (mail, personal handover, etc.) that is used to surrender the credit card.
2. The credit Cardholder must sign the credit card immediately upon receipt, must not permit any other person to use it and should safeguard the credit card from misuse by retaining it under the credit Cardholder's personal control at all times.
3. The credit Cardholder shall destroy his old credit card, on receipt of renewal credit card, by cutting it into several pieces. The renewed credit card shall be sent to the credit Cardholder before the expiry of the old credit card at the

discretion of HSBC upon evaluation of the conduct of the credit card account. HSBC reserves the sole right of renewing the credit card account on expiry.

The credit Cardholder must sign a sales slip, cash advance slip, or mail order coupon whenever the credit card is used and should retain the copy. Copies of the sales or cash advance slip may be furnished by HSBC at an additional charge. Any sales, cash advance slip, or mail order coupon not personally signed by the credit Cardholder but which can be proved as being authorised by the credit Cardholder will be the credit Cardholder's liability.

The credit Cardholder is required to authenticate the purchases at merchant outlets in India using their 6-digit ATM PIN at the electronic Point of Sale (POS) terminal, in addition to signing the sales slip, to complete the payment.

- a. The merchant will dip the Chip card into the POS terminal's card reader and enter the amount to be paid by the credit Cardholder.
- b. The POS terminal will ask for a PIN, which will be the credit Cardholder's 6-digit Credit card ATM PIN.
- c. The credit Cardholder will be required to enter his/her credit card ATM PIN on the Point of Sale (POS) machine in addition to signing the charge slip for the purchase transaction to successfully go through.
- d. The merchant with hand over a copy of the sales slip along with the Chip card to the credit Cardholder.
4. In the case of contactless transactions, the customer can use the HSBC Live+ Credit Card for contactless payments without needing to input the PIN at the Point of Sale (POS) terminals enabled for contactless payments. Please note that domestic payments through contactless mode is allowed for a maximum of ` 2,000 for a single transaction and for international payments, the same is allowed for a maximum amount equivalent to ` 5,000 for a single transaction.

For any transaction which is above the aforesaid limits would necessarily require PIN for authentication.

The Cardholder will have the option to choose between contactless payment at the Point of Sale (POS) terminals enabled for contactless payments and can also pay normally by using the PIN.

Customers can place a request to set up contactless limits lower than the thresholds mentioned as per his/her requirement.

5. The credit Cardholder will be responsible for all facilities granted by HSBC in respect of the credit card and for all transactions and charges accrued on these facilities, notwithstanding the termination of this agreement.
6. The credit card is acceptable at any VISA merchant outlet worldwide depending on the brand of credit card used. Whilst HSBC will not accept responsibility for any dealing the merchant may have with the credit Cardholder including but not limited to the supply of goods or services, HSBC will try and assist the credit Cardholder, wherever possible. For this, the credit Cardholder, should notify HSBC of the complaint immediately along with supporting documents. Should the credit Cardholder have any complaints concerning any VISA merchant establishment, the matter should be resolved by the credit Cardholder with the merchant establishment and failure to do so will not relieve the credit Cardholder from any obligations to HSBC.
7. HSBC accepts no responsibility for any surcharge levied by any merchant establishment and debited from the credit card account with the transaction amount.
8. All charges for jewellery, electronic goods and cash will be approved selectively at HSBC's discretion in the first six months of credit card membership.
9. The payments effected via the contactless feature do not require a second factor authentication and may be restricted in accordance with the Bank's internal policies and guidelines. Transactions above a certain threshold amount and frequency/number of transactions will require a

second factor authentication. Customer has a choice to effect the payments with or without the contactless feature subject to the thresholds as mentioned above.

10.  The credit Cardholder will be responsible for any standing instructions issued by the credit Cardholder on the credit card in relation to other service providers. The credit Cardholder will also be responsible for advising the service provider directly of any change in the credit card number for payment mandates/direct debits the credit Cardholder has authorized on the credit card, irrespective of the change being an outcome of instructions/action emanated from the credit Cardholder or from HSBC. HSBC accepts no responsibility for any disputes between the credit Cardholder and such other service provider(s). Disputes, if any, must be resolved directly between the credit Cardholder and such service provider(s).
11.  HSBC shall be under no liability, whatsoever, in respect of any loss or damage arising directly or indirectly out of decline of a charge because of exceeding foreign exchange entitlements as prescribed by RBI guidelines issued from time to time, on HSBC becoming aware of the credit Cardholder exceeding his entitlements.
12.  Utilisation of the credit card must be in strict accordance with the Exchange Control Regulations of the Reserve Bank of India (RBI). In the event of the credit Cardholder's failure to comply with the same, the credit Cardholder shall be liable for action under the Foreign Exchange Management Act, 1999 and may be debarred from holding HSBC's credit card worldwide, either at the instance of HSBC or the RBI. The credit Cardholder shall indemnify and hold harmless HSBC from and against any and all consequences arising from the credit Cardholder/the additional credit Cardholder not complying with the Exchange Control Regulations of the RBI.
13.  Non-Resident Indians can hold an international credit card; provided all dues arising out of its use in India/abroad are met out of an NRE/NRO account held with HSBC or by inward remittances.
14.  The credit Cardholder shall not use the credit card as payment for any illegal purchase.
15.  HSBC reserves the right to honour, refer or decline any transaction on the credit card, at its sole discretion and without assigning any reason whatsoever.
16.  International Usage to enhance security on your transactions, credit Cardholders will have an option of setting up the international or domestic usage facility. Cardholders who choose the domestic usage facility will not be able to carry out the following kinds of transactions:
- Point of Sale (POS) transactions outside India
- E-commerce transactions on websites (servers) located outside India
- Transactions at ATMs located outside India

If you wish to use the card for international transactions please place a request with HSBC PhoneBanking OR submit a 'Local/International Card Usage Form' at the nearest HSBC Branch in India.

- a. All credit cards will be set-up by default for Domestic usage only, unless you have opted for international usage at the time of making an application for the credit card.
- b. A limit of USD 15,000 per transaction will apply for international transactions on magnetic stripe cards (subject to your available credit limit).

The per transaction limit of USD 15,000 on international transactions will not apply for Chip and PIN-enabled credit cards; however if the Chip credit card is used as a magnetic stripe card (by swiping it at a POS machine) it will be treated as a magnetic stripe card and the USD 15,000 per transaction limit will apply (subject to your available credit limit). If you need any clarifications, please call HSBC PhoneBanking or visit the nearest HSBC branch in India.

## Card Activation

## Terms and Conditions on SMS OTP for Card Activation.

One Time Password for activating your new HSBC Credit Card

1. By using this One Time Password (OTP) service (the 'Service'), you will be deemed to have accepted and agreed to comply with these terms, which shall

- operate in addition to all other applicable terms, including our applicable data policies, the terms and conditions governing the use of your credit card, the terms and conditions governing the use of HSBC's Credit Card.
2. When activating the HSBC Credit Card newly issued to you for whom the Service is applicable, you are required to enter an OTP sent to you via SMS on your registered mobile number with the bank for acceptance and activation of the HSBC Credit Card.
3. If you cannot provide the OTP or the authentication through the Service fails, the credit card may not be activated. We will not be liable for any delay in receipt of SMS due to mobile network congestion or handset limitations.
4. Credit Cardholders will be responsible for the accuracy of his/her personal details provided by him/her to HSBC. Credit Cardholders must inform HSBC immediately of any change in his/her particulars.
5. Credit Cardholders will ensure that his/her mobile phone and number is able to receive text messaging both in India and overseas. Credit Cardholders will be responsible for any fee imposed by his/her respective mobile phone service provider.
- This Service is subject to the terms and conditions of the Cardholder's agreement with his/her mobile phone service provider.
6. Credit Cardholders acknowledge and agree that the sending of any SMS alert by HSBC and/or its receipt by credit Cardholders may be delayed or prevented by factor(s) outside of HSBC's control.
7. You are fully responsible and liable for all transactions made by after activating the card using the OTP received by you.
8. You must not allow any unauthorised access or give any other person access to the credit card and OTP used for accessing the Service. You are required to keep the OTP secret at all times and must not disclose it to:
- a. any person or write it down or
- b. record it in a manner that could result in its disclosure or misuse.
9. If you discover that your credit card details or the OTP may have
- been used in an unauthorised way, you must notify us as soon as reasonably practical by calling our PhoneBanking numbers. In certain circumstances, we may also require you to make a police report accompanied by any other information we may require.
10.  You accept that you are responsible for the use of the Service and agree to act prudently and in good faith, including by taking the measures listed below to safeguard the security of the Service and the OTP . You must also follow HSBC's security recommendations (copies of which are provided on HSBC's website) and any other notices relating to the Service from time to time issued. If you fail to observe any such notices and/or your responsibilities under these terms, you are liable for all claims, losses, liabilities and other consequences arising from or in connection with the use of the Service.
11.  HSBC will be entitled to prescribe or amend these terms and conditions including methods for the use of the Service, as well as the channel for provision or use of the Service, as HSBC deems appropriate.
12.  HSBC will cease to provide the Service:
- a. if these terms and conditions are not complied with;
- b.    if the credit card account is closed;
- c. upon the death or contractual incapacity of the credit Cardholder;
- d. upon written request of the credit Cardholder;
- e. at HSBC's own discretion.
13.  HSBC reserves the right to begin charging a fee for such a Service by giving 30 days prior notice to the credit Cardholder.

## One Time Password for Secured Transactions

1. By using this One-Time Password (OTP) service (the 'Service'), you will be deemed to have accepted and agreed to comply with these terms, which shall operate in addition to all other applicable terms, including our applicable data policies, the terms and conditions governing the use of your credit card, the terms and conditions governing the use of HSBC's website (which include the website conditions of use) and any

- security measures provided by HSBC from time to time for ECOM or the service.
2. When engaging in an ECOM or other transactions for which the service is applicable, you are required to enter an OTP sent to you via SMS before the Merchant accepts your credit card to pay for the Transactions. If you cannot provide the OTP or the authentication through the Service fails, the merchant may not accept your credit card to pay for the Transactions concerned. We will not be liable for any merchant's refusal to accept your credit card for the said payment for any reason whatsoever.
3. Credit Cardholders will be responsible for the accuracy of his/her personal details provided by him/her to HSBC. Credit Cardholders must inform HSBC immediately of any change in his/her particulars.
4. Credit Cardholders will ensure that his/her mobile phone and number is able to receive text messaging both in India and overseas. Credit Cardholders will be responsible for any fee imposed by his/her respective mobile phone service provider.
5. This service is subject to the terms and conditions of the Cardholder's agreement with his/her mobile phone service provider.
6. Credit Cardholders acknowledge and agree that the sending of any SMS alert by HSBC and/or its receipt by credit Cardholders may be delayed or prevented by factor(s) outside of HSBC's control.
7. HSBC will not be liable for any or all losses, damages, expenses, fees, costs, (including legal costs on a full indemnity basis), that may arise, directly or indirectly, in whole or in part, from (a) the non-delivery, the delayed delivery, or the misdirected delivery of an alert; (b) the non-receipt of an alert; (c) inaccurate or incomplete content in an alert; (d) reliance on or use of the information provided in an alert for any purpose; or (e) any third party, whether authorised or not, obtaining credit Cardholder's account information contained in the alert by accessing the credit Cardholder's mobile phone.
8. You are fully responsible and liable for all transactions made by using the OTP received by you.
9. You must not allow any unauthorised access or give any other person access to the credit card and OTP used for accessing the service.
10.  You are to keep the OTP secret at all times and must not disclose it to any person or write it down or record it in a manner that could result in its disclosure or misuse.
11.  If you discover that your credit card details or the OTP may have been used in an unauthorised way, you must notify us as soon as reasonably practicable by calling our customer services, helpline numbers. In certain circumstances, we may also require you to make a police report accompanied by any other information we may require.
12.  You accept that you are responsible for the use of the service and agree to act prudently and in good faith, including by taking the measures listed below to safeguard the security of the service and the OTP . You must also follow HSBC's security recommendations (copies of which are provided on HSBC website) and any other notices relating to the service from time to time issued. If you fail to observe any such notices and/or your responsibilities under these terms, you are liable for all claims, losses, liabilities and other consequences arising from or in connection with the use of the Service.
13.  HSBC will be entitled to prescribe or amend these terms and conditions including methods for the use of the service, as well as the channel for provision or use of the service, as HSBC deems appropriate.
14.  HSBC will cease to provide the service:
- a. if these terms and conditions are not complied with;
- b. if the credit card account is closed;
- c. upon the death or contractual incapacity of the credit Cardholder;
- d. upon written request of the credit Cardholder;
- e. in the event of improper operation of the credit card account by the credit Cardholder; or
- f. at HSBC's own discretion.
15.  HSBC reserves the right to begin charging a fee for such a service by giving 30 days prior notice to the credit Cardholder.

<!-- image -->

HSBC PhoneBanking numbers

Kindly note that to shop online with the HSBC Live+ Credit Card or on the merchant IVR system, the Cardholder would be required to authenticate the transaction using One Time Password (OTP). The OTP will be automatically sent by HSBC's system to the Cardholder's registered mobile number via SMS when the ECOM is initiated. At the HSBC Verified by VISA (VbV) authentication screen the credit Cardholder will be required to enter the 6-digit OTP to complete the ECOM. Similarly in case of an IVR transaction, the Credit Cardholder will be required to enter the 6-digit OTP using the phone keypad.

## Credit Limit

1. Your Credit Card carries a credit limit on the amount of purchase and cash advance. Please refer to your Credit Card statement on a month on month basis for the applicable credit limit on your Credit Card which you are required to comply with in relation to your Credit Card.
2. In the event of exceeding the credit limit assigned, an over limit fee is levied by HSBC, once every billing cycle, at the prevailing rate.
3. In case the credit Cardholder exhausts the credit limit sanctioned, the credit card will not be invalidated, but all transactions initiated by the credit Cardholder beyond the credit limit sanctioned will be declined till the credit card account is funded fully or partly so as to bring the outstanding within the credit limit.
4. The credit limit and cash withdrawal limit (up to 20% of credit limit or as decided by the Bank from time to time) are communicated to you in your monthly card statement. The available credit limit is provided as part of the monthly statement. The Bank reserves its right to reduce the credit limit. Usage of the card shall be deemed as acceptance of the credit limits granted from time to time.
5. The credit limit approved on the account is shared between the primary Cardholder and add-on (additional) credit Cardholder(s) (if any).
6. The credit Cardholder understands that HSBC may conduct periodic reviews of the account based on the credit Cardholder's payment
7. patterns and/or based on HSBC's policy and discretion. In such an event, the credit Cardholder will be informed about the revised credit limit. Usage of the credit card shall be deemed as acceptance of the credit limit granted from time to time.
7. The credit Cardholder may apply for a review of his/her assigned credit limit at any time after the first six months of satisfactory credit card operations. HSBC may at its sole discretion, as a result of a reasonable assessment of credit risks associated with the credit card account or the credit Cardholder based on information available to HSBC, reduce the credit limit of such accounts as it thinks fit without prior notice to the credit Cardholder. HSBC may also at its sole discretion, without prior notice to the credit Cardholder, reduce the credit limit where the minimum payment due has not been received by the payment due date.
8. Further, the credit Cardholder may request HSBC for an increase in his credit limit. In any such case, HSBC may request the credit Cardholder for financial documents declaring his/her income, and may, at its sole discretion, increase the credit limit. A credit Cardholder may also request HSBC for a decrease in the credit limit, subject to the minimum limits set by HSBC. The Credit Cardholder expressly understands that if the credit limit is reduced, further enhancements will be at the discretion of the Bank. Further, the credit Cardholder expressly agrees that while processing a credit Cardholder's request for an increase in credit limit, HSBC may share this information with credit reference agencies.
9. HSBC may offer the credit Cardholder an increase in his/her credit limit based on periodic review of the credit card account. HSBC will take the consent of the credit Cardholder prior to effecting the increase in credit limit through any of the following channels - SMS, E-mail, Voice Response or physical letter. HSBC's decision in matters pertaining to credit limit increase will be final and binding.

## Billing

1. All the credit card transactions will be posted in the credit card account.

2. When the credit card account has an outstanding balance, HSBC will send a monthly itemised statement of account. This statement will provide details on:
- a. Net outstanding balance.
- b. Total payment due.
- c. Minimum payment due.
- d. 'Payment due date'. If payment is made by cheque, the funds must be realised in the card account at least three working days before the payment due date.
3. Non-receipt of statement would not affect the credit Cardholder's obligations and liabilities.
4. A purchase and a subsequent credit for cancellation of goods/services like air/ rail tickets are two separate transactions. The credit Cardholder must pay for the purchase transaction as it appears on the credit card statement to avoid the charging of any fee. The refund will only be credited to the credit card account (less cancellation charges) as and when received from the merchant. If the credit is not posted to the credit card account within 30 days from the date of refund, the credit Cardholder must notify HSBC.
5. It is also necessary that a copy of the credit note should be sent along with the credit Cardholder's notification to HSBC.
6. All charges incurred in foreign currency will be billed in the credit Cardholder's billing statement in INR. The credit Cardholder authorises HSBC and Visa to convert charges incurred in a foreign currency to the Indian Rupee equivalent thereof at such rate as HSBC and Visa may from time to time designate. For transactions incurred overseas on a, settles the transaction with the issuing bank in USD irrespective of the currency of spends.
7. For reporting billing discrepancies, Cardholders can either call the HSBC PhoneBanking service (numbers are provided on the reverse of the monthly statement or at www.hsbc.co.in) or write to HSBC Credit Card Division, Dispute Desk, PO Box 5080, Chennai - 600 028.
11. All grievances escalations should be marked to Chief Nodal Officer, The Hongkong and Shanghai Banking Corporation Limited, 'Rajalakshmi',

No. 5 and 7, Cathedral Road, Chennai - 600 086, India.

E-mail: nodalofficerinm@hsbc.co.in You may contact the Nodal Officer Team at the following contact number between 09:30 a.m. and 06:00 p.m., Monday to Friday. Ph.: +91 44 - 3911 1217. The Reserve Bank of India has appointed an Ombudsman who can be approached for redressing customer grievances if they have not already been redressed by HSBC. The credit Cardholder can approach the Ombudsman if he does not receive a response within 60 days from HSBC or if he/she is not satisfied with the response.

## Payment

1. Cheques/Drafts forwarded to HSBC for clearance of dues must be drawn on payable at any city where HSBC has a branch. Cheques/Drafts drawn or deposited outside these areas are subject to a collection charge at the then prevailing rate. Payments will be credited to the credit card account on receipt, but should the payment instrument/NACH subsequently be dishonoured, the credit card account may be suspended, the credit card would be cancelled and the full outstanding balance will become immediately due and payable. HSBC will, at its sole discretion, take necessary measures to recover the money and this may include filing a criminal case under the Negotiable Instruments Act.
2. If the payment of the whole of the statements closing balance is received by HSBC on or before the payment due date, no finance charge will be payable.
3. If you will be away from India, you should make arrangement as appropriate to settle the HSBC Credit Card Account before your departure or make arrangements to pay by the due date.
4. If the credit Cardholder wishes to have the extended credit facility and pay HSBC an amount less than the statements total payment due, the entire outstandings from the date of the transaction will attract a finance charge. All new transactions will also attract a finance charge from the date of transaction at the prevailing rate once the account uses the extended credit facility . This charge will be debited on the last day of the billing cycle and will be applied on daily balances.

<!-- image -->

5. While settling the credit card dues post-dated cheques should not be deposited.
6. If the minimum payment due is not paid by the payment due date, a late payment fee will be debited from the credit card account on the last day of the billing cycle. HSBC also reserves the right to levy penal finance charges at a rate higher than the current rate, in case the minimum payment due is not received before the payment due date.
7. Returns, reversals and refunds will not be treated as payments and will not affect the minimum payment due.
8. The payment will be applied to the items on the credit card statement in accordance with the Payment Hierarchy described on page 24 of the service guide section of this booklet.
9. The credit Cardholder is deemed to have received each statement of account for the preceding month, either on actual receipt of the statement of account or 10 days after the dispatch of the statement of account by HSBC, whichever is earlier (prescribed period). Upon receipt of each statement of account and in any event not more than 30 (thirty) days from the period mentioned above, the credit Cardholder agrees to immediately notify HSBC of any errors, omissions, irregularities, including any fraudulent or unauthorised transactions or any other objections the credit Cardholder has to that statement of account. If the credit Cardholder fails to notify HSBC within 30 (thirty) days, the statement of account and all entries therein, will be conclusive evidence of the correctness of the contents and binding upon the credit Cardholder and/or any person claiming under or through such credit Cardholder with the requirement for further proof and HSBC will be released from all liability for any transaction (including all charges, damages and losses of any kind whatsoever, taxes, levies, fines, fees or penalties suffered and or incurred) occurring up to the date of the most recent statement of account except for transaction which the credit Cardholder gave notice of in accordance with this section.
10.  Duplicate statements will only be provided for up to the last six months
7. on the request of the credit Cardholder and payment of the assessed fee as per the tariff sheet. Duplicate statement requests placed via ATMs will also be charged the fee as per the tariff sheet.
11.  HSBC has the sole discretion to appoint agents for recovery of outstanding or initiate any other actions allowed by law for recovery of all monies owed to HSBC without any specific communication in this regard.
12.  HSBC shall not pay any interest to the Cardholder on any credit balance in the Cardholder's credit card account.

## Fees

1. Annual membership fees if applicable on the primary and add-on credit card(s) will be billed in the credit card statement on card issuance/ renewal. These fees may vary depending on the offer under which the HSBC Credit Card has been availed by the credit Cardholder. The fees will not be refunded if the credit card is terminated either by HSBC or the Cardholder.
2. All cash advances attract a transaction fee at the prevailing rate. The fee will be debited from the credit card account at the time of posting of the cash advance. Cash advances will also be subject to a finance charge calculated on daily balances from the date of withdrawal until the entire amount, along with the charges, are cleared. The finance charge will be debited from the credit card account on the last day of the billing cycle.

## Lost or Stolen Credit Card

1. In the event the credit card is lost or stolen, the credit Cardholder must report the occurrence to any office of HSBC in India or any Visa Global Emergency Assistance Helplines in writing or by calling the PhoneBanking service. OR
2. The Cardholder may also send an SMS from his/her registered mobile number to block the lost card. The SMS should be sent in the following format 'BLOCK&lt;space&gt;HSBC&lt;space&gt; &lt;Last 4-digits of your card number&gt;' to '575750' . The credit Cardholder must also file a

Police Complaint with the local police station and send a copy of the Report to HSBC.

2. The credit Cardholder will not be liable for any transaction made on the credit card after reporting the loss/theft/misuse to HSBC.
3. Although loss or theft may be reported as mentioned above (1), the credit Cardholder must confirm to HSBC in writing. A copy of the acknowledged police complaint must accompany the written confirmation. The credit Cardholder agrees to indemnify HSBC fully against any liability (civil or criminal), loss, cost, expenses or damages that may arise due to loss or HSBC or getting lost and misused before HSBC is informed.
4. Provided the credit Cardholder has in all respects complied with the terms and conditions, a replacement credit card may be issued at the sole discretion of HSBC at the applicable fee.
5. Should the credit Cardholder subsequently recover the credit card, the recovered credit card must not be used. The credit Cardholder should destroy the credit card by cutting it into several pieces through the magnetic stripe.

## Lost Card Liability

Your liability for unauthorised transactions on the Lost Card. The HSBC Live+ Credit Cardholder has nil lost credit card liability after reporting and registering the loss of the HSBC Live+ Credit Card to HSBC. The credit Cardholder is also covered ^  for misuse of his/her HSBC Live+ Credit Card up to 24 hours before reporting and registering, for up to ` 100,000. For more details, please visit www. hsbc.co.in/Live+ credit card section.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

^ All insurance benefits listed above are provided directly to credit Cardholders by ICICI Lombard General Insurance Company Limited, whose terms, conditions and decisions, for which the Bank is not liable, will apply. Claims for settlement to be sent directly to ICICI Lombard General Insurance Company Limited.

All insurance benefits on the credit card are available to valid primary Cardholders only.

## Terms and conditions for Lost Card Liability

## General terms and conditions

- All insurance benefits listed are provided directly to credit Cardholders by ICICI Lombard General Insurance Company Limited, whose terms, conditions and decisions, for which the Bank is not liable, shall apply
- HSBC does not hold any warranty and/or make representation about quality, delivery of the cover, processing of the claims or settlement of the claims by ICICI Lombard General Insurance Company Limited in any manner whatsoever
- Claims for settlement to be sent directly to ICICI Lombard General Insurance Company Limited
- The insurance benefits are available to you regardless of other existing insurance that you may avail of. You may be asked to submit additional documents, as per the requirements of the case
- The Bank will not be liable for any delayed settlement of claims
- Both the above covers are reimbursable
- Reimbursement would be restricted to the lower of loss incurred and maximum sum insured
- For any further queries or assistance related to the policy, exclusions and claim settlements, you can write to hsbccustomer@almondz.com or call on toll free 1800 2666

## Lost Card Liability Cover terms and conditions

- The policy covers all fraudulent utilisation of lost or stolen HSBC Live+ Credit Cards
- The cover is valid for 24 hours prior to reporting and 7 days post reporting
- Pre-delivery frauds are not covered
- All PIN-based transactions are not covered
- Claim should be registered by the Cardholder within a maximum period of 30 days from the date of filing Police Complaint with the local police station or within 15 days from the statement period end date, mentioned on the credit

<!-- image -->

card statement bearing details of the fraudulent transactions

- Counterfeit cards are not covered

## Claims Procedure

For lost card reporting and online fraud protection cover on HSBC Live+ Credit Card, Cardholder should write to hsbccustomer@almondz.com or call on toll free 1800 2666.

Within 10 days ICICI Lombard General Insurance Company Limited will communicate with the claimant and ask for the required documents. The following documents need to be submitted along with the duly filled claim form:

- Copy of the front side of your credit card (in case of online fraud protection cover only)
- Original/Attested copy of the Police Complaint by a Gazetted Officer
- Copy of sales slips/statement indicating fraudulent transactions
- Occurrence/incident report indicating how and when the card was lost
- Resident proof of the claimant
- ID proof of the claimant
- Recent photo of the claimant
- Any other document as may be required by the company

Customers shall call ICICI Lombard General Insurance on 1800 2666 or write to hsbccustomer@almondz.com to make a claim and obtain the proper forms and instructions within 24 hours from discovering an unauthorised charge was made on your lost or stolen credit card;

File a police report within a maximum of 24 hours of discovering unauthorised charges or ATM withdrawals;

To the extent your credit card was not lost or the object of theft, report the unauthorised charges, or ATM withdrawal(s), to the credit account issuer(s), and to us, within 24 hours of your discovery of a loss;

You shall complete and return any documents including but not limited to claim forms, police reports, demands, notices, and any other documents we may ask you to provide;

The claims form and accompanying documents must be returned to us within 3 days of making the original claim.

In case the documents are not received from the customer within 3 months of intimation, the claim shall be considered as closed. However, before closing the claim, ICICI Lombard General Insurance Company Limited shall send a letter to the customer that the claim is closed because of the nonreceipt of documents.

- On admissibility, ICICI Lombard General Insurance Company Limited shall make the payment to the beneficiary. The payment shall be made within 10 days of receipt of all complete documents
- The settlement amount will be paid by an account payee cheque in favour of the Cardholder

## Additional Credit Cards

In case the credit Cardholder requests and authorises HSBC to issue an additional credit card to the person(s), who is/are not less than 18 years of age, for operation on his/her credit card account, the credit Cardholder irrevocably confirms that any fees, charges, interests, etc. and all dues in respect of the additional credit card(s) utilised for services availed and goods purchased from eligible service establishments/merchants by the additional Cardholder(s) will be payable by the credit Cardholder and the credit Cardholder guarantees the payment towards the same in his/her capacity as the primary credit Cardholder.

The credit Cardholder authorises HSBC to share credit card and the transaction(s) details of the additional card(s) with other credit card issuers and/or financial institutions and/or other entities and/or other regulatory authorities as HSBC may deem fit.

## Change of Credit Card Type

1. For the purpose of credit card upgrade/downgrade/transfer, the

hierarchy in increasing order will be - Classic, Live+ and Premier.

2. HSBC has the right to downgrade the credit card type of the credit Cardholder basis the spending and payment pattern of the credit Cardholder or any other behavioral criteria which HSBC may deem fit. The credit Cardholder will however be informed of any change in card type.
3. The credit Cardholder may apply for credit card upgrades or transfers.
4. HSBC's decision in matters pertaining to change of credit card type shall be final and binding.

## Fuel Surcharge

Fuel purchases made at petrol pumps with either HSBC Electronic Draft Capture (EDC) terminals or other bank EDC terminals will be levied the applicable fuel surcharge amount at the time of purchase and this will appear on the HSBC Live+ Credit Cardholder's monthly statement of account.

HSBC has the right to change the contract regarding fuel surcharge, modify the slabs or remove them completely, without prior notice.

## Railway Surcharge

In line with the current Visa rules, all railway transactions made at the reservation counter will attract a service charge of ` 10 or 2.5% of the transaction amount, whichever is higher. For bookings made on the Indian Railways, website for train reservations, these service charges will be in line with the Bank whose payment gateway is used for making the payment. In addition, the railways will also levy a processing charge of ` 30 per transaction. This charge is not levied by HSBC but by the acquiring bankers to the railways.

## Rewards Programme

1. Transactions on your HSBC Live+ Credit Card do not qualify for any reward points.
2. In cases where existing HSBC Credit Card Customers who intend to upgrade or transfer from an existing HSBC Credit Card to HSBC Live+ Credit Card will have to redeem the reward points available on the existing Credit Card before
3. migration to this card. There will be no option to carry forward the reward points from the old Credit Card to new HSBC Live.
3. Unlimited* cashback is the key feature of the HSBC Live+ Credit Card. The Cashback eligibility will be as follows:
- a. 10% cashback on all dining, food delivery and grocery transactions (capped upto ` 1,000 per billing cycle)
- b. 1.5% unlimited cashback on other spends
- c. No cashback on following categories: Fuel related (MCC 5541, 5983, 5172, 5542, 5552), e-wallets (MCC 6540), payment of property management fees, rental commissions, rental payments or any such payments made through MCCs 6513, 7012, 7349, Business to Business txns made through MCCs 7399, 7311, 7372, 5045, 5047, 5065, 5072, 5111, 5013, 2741, 5137, 5192, 5193, 5131, 7361, 5085, 7333, 5039, 7379, 5021, 5199, 5122, 5099, 5198, 5139, 7829, 7395, 5051, 5046, 5169, 7375, 5074, 8734, 5044, 2842, 2791, education and government related txns carried out through MCCs 9399, 8299, 8220, 8211, 8241, 9311, 8244, 8249, 9222, 9402, 9211, 9405, 9950, 9223, 8351), Insurance (MCC 6300, 5960), Jewelry &amp; Antique items (MCC 5944, 5094, 5932, 5937), Gambling (MCC 7995), Tolls and Bridge Fees (MCC 4784), Financial and Non-Financial Institutions (MCC 6011, 6010, 6012, 6051), Security Broker Services (MCC 6211), Collection Agencies (MCC 7322), Charity (MCC 8398, 8641), Money Transfers (MCC 4829) and Wholesale Clubs (MCC5300)
8. *The above cashback terms may be subject to change from time to time and HSBC will provide due notice of 30 days in case of any change to these terms.
4. Cashback amount paid on transactions that subsequently get reversed, cancelled or nullified (for any reasons) shall be recovered back from the cardholder by either being adjusted against cashback of the next statement or by debiting the card account in the next statement.
5. The eligible cashback amount will be credited to the Credit Card account within 45 days of the statement date.

For example, for a Credit Card account with a bill cycle date of 2 nd  of every month, for transaction done between 2 May 2019 to 1 June 2019, the eligible cashback amount will be credited to the account by 17 July 2019.

## Premium Offers

1. HSBC has entered into marketing arrangements with leading service/ Product providers to provide premium offers to its credit Cardholders. The offers may include preferential pricing and/or service benefits.
2. All disputes between a credit Cardholder and the service provider/ product provider shall be resolved between them and HSBC shall not be responsible for the quality of any of the offerings by the respective marketing partner.

## ATM Related

Where an 'Any Time Money' or other facility has been incorporated in the credit card, so that it may be used to effect banking transactions (on any account other than the credit card account) at Automated Teller Machines (ATMs), the use of such a facility will be subject to the relevant HSBC ATMs terms and conditions in addition to the terms and conditions herein.

## SMS Alerts

## 1. Availability

- 1.1  The SMS facility is made available to the credit Cardholder, at the sole discretion of HSBC and may be discontinued by HSBC at any time, without notice. The SMS facility is currently available only to Resident Indian credit Cardholders with accounts with HSBC branches in India.
- 1.2  The SMS facility is available in certain specific regions and to subscribers of mobile phones of certain specific CSPs in India. The credit Cardholder understands that unless he is a subscriber of the specific CSPs, the SMS facility will not be available.
- 1.3  The alerts will be sent to the credit Cardholder only if the credit
- Cardholder is within the cellular circles of the CSPs or in circles forming part of the roaming network of such CSPs.
- 1.4  HSBC may, if feasible, extend the facilities to other cellular circles as well as to the credit Cardholders, who are subscribers of such other CSPs, from time to time.

## 2. Process

The credit Cardholder acknowledges that alerts will be implemented in a phased manner. HSBC may, from time to time, change the features of any   alert.

## 3. Receiving Alerts

- 3.1  The credit Cardholder is responsible for intimating to HSBC any change in his phone number or e-mail address or account details.
- 3.2  The credit Cardholder acknowledges that to receive alerts, his mobile phone must be in a 'switched on' mode. If the credit Cardholder's mobile phone is kept 'switched off' for a continuous period 48 hours from the time of delivery of an alert message by HSBC, that particular message would not be received by the credit Cardholder.
- 3.3  The credit Cardholder acknowledges that the SMS facility is dependent on the infrastructure, connectivity and services provided by the CSPs and other service providers engaged by HSBC for the purpose of providing the SMS facility. The credit Cardholder accepts that timeliness, accuracy and readability of alerts sent by HSBC will depend on factors affecting the CSPs and other service providers. HSBC shall not be liable for non-delivery or delayed delivery of Alerts, error, loss or distortion in transmission of alerts to the credit Cardholder.
- 3.4  HSBC shall endeavour to provide the SMS facility on a best-effort basis and the credit Cardholder shall not hold HSBC liable for nonavailability of the SMS facility or non-performance by any CSPs or other service providers or any loss or damage caused to the credit Cardholder as a result of use of the SMS facility (including, relying

on the alerts for the credit Cardholder's investments or business purposes) for causes which are not attributable to HSBC. HSBC shall not be liable in any manner to the credit Cardholder in connection with the use of the SMS facility.

- 3.5  The credit Cardholder acknowledges that the transaction alert by way of the SMS facility may be delayed due to circumstances beyond the Bank's control. The Cardholder is also made aware that in case of telecommunication network congestion/technical issues, if the Bank is unable to provide online authorization, the stand-in processing functionality of Visa automatically makes the authorization decision on the Banks behalf to avoid inconvenience to the Cardholder.

In such circumstances, transaction alert by way of SMS will not be available.

- 3.6  The credit Cardholder accepts that each alert may contain certain account information relating to the credit Cardholder. The credit Cardholder authorises HSBC to send account related information, though not specifically requested, if HSBC deems that the same is relevant.
- 3.7  You must always ensure that you have informed us of your current mobile number/e-mail ID so that you receive alerts promptly. Failure to keep your contact information with us updated, may result in you being liable for any loss suffered as a result of misuse of your cards.

## 4. Withdrawal or Suspension of SMS facility

HSBC may, in its discretion, withdraw temporarily or suspend either wholly or in part, the SMS facility at any time, without prior notice, when any maintenance work or repair is required to be carried out or in case of any emergency or for security reasons, which necessitate the suspension or temporary withdrawal of the SMS facility. HSBC will notify you in advance incase of scheduled maintenance work or repair.

## 5. Fees

HSBC may at its sole discretion revise the charges/fees for use of any or all of the SMS facility by notice to the credit Cardholder. The credit Cardholder may at any time discontinue or unsubscribe to the said SMS facility after providing a 30-day notice period to HSBC. The credit Cardholder shall be liable for payment of such airtime or other charges which may be levied by the CSP in connection to the receiving of alerts, as per the terms and conditions of the CSP and HSBC is in no way concerned with the same.

## 6. Disclaimer

- 6.1  HSBC will not be liable for loss of any information/instructions/alerts in transmission nor be responsible for security of the transmission.
- 6.2  HSBC will not be concerned with any dispute between the credit Cardholder and the CSP and makes no representation or gives no warranty with respect to the quality of the service provided by the CSP or guarantee for timely delivery or accuracy of the contents of each alert.

## 7. Disclosure

The credit Cardholder accepts that all information will be transmitted to and/ or stored at various locations and be accessed by personnel of HSBC (and its affiliates). HSBC is authorised to provide any information or details relating to the credit Cardholder or his account to the CSPs or any service providers so as to enable them to provide any services to the credit Cardholder.

## 8. Liability and Indemnity

The credit Cardholder shall not interfere with or misuse in any manner, whatsoever, the SMS facility and in the event of any damage due to improper or fraudulent use by the credit Cardholder, the credit Cardholder shall be liable in damages to HSBC. In consideration of HSBC providing the SMS facility, the credit Cardholder agrees to indemnify and keep safe, harmless and indemnified HSBC from and against all actions, claims, demands, proceedings, loss, damages, costs, charges and expenses, whatsoever, which HSBC may at any time incur, sustain, suffer or be put to as a consequence of or arising out of acting in good faith acting by omission or refusing to act on any instructions given by use of the SMS facility. The credit Cardholder shall indemnify HSBC for any unauthorised access by any other person to any information given by the credit Cardholder or breach of confidentiality.

## 9. Amendment

HSBC may amend the above terms and conditions at any time without prior notice to the credit Cardholder and such amended terms and conditions will thereupon apply to and be binding on the credit Cardholder.

## Services by Third Parties

Travel benefits and preferential offers on leading brands are offered on the credit card by a select range of marketing partners. HSBC makes no representations about the quality of their services and will not be responsible if the service is in any way deficient or otherwise unsatisfactory.

## Disputes

1. These terms and conditions will be governed by and be construed in accordance with the laws of India. All disputes are subject to the exclusive jurisdiction of the courts in Mumbai, irrespective of whether any other court may have concurrent jurisdiction in the matter.
2. The credit Cardholder shall be liable for all costs associated with the collection of dues, legal expenses and decretal amounts with interest, should it become necessary to refer the matter to any agent or where legal resources for enforcement of payment have been taken.

## Disclosure of Information

1. When requested by HSBC, the credit Cardholder shall provide any information, records or certificates relating to any matters that HSBC deems necessary. The credit Cardholder authorises HSBC to verify the information furnished by whatever means or from whichever source HSBC deems necessary. If the data is not provided or incorrect data is provided, HSBC, at its discretion, may refuse renewal of the credit card or cancel the credit card forthwith and demand payment of all outstandings on the credit card account.

The credit Cardholder expressly recognises and accepts that HSBC shall be absolutely entitled and have full power and authority to sell, transfer or assign any or all outstandings and dues on the credit card account to any third party of HSBC's choice and written intimation by HSBC to the credit Cardholder of any such action shall bind the credit Cardholder to accept any such third party as the creditor and to pay such outstandings and dues to the third party relieving the credit Cardholder of any such obligation to HSBC.

2. If the minimum payment due does not get paid by the credit Cardholder, the credit Cardholder's name may be liable for inclusion in the defaulter database to be shared with other lenders and credit rating agencies. The right to do so lies with HSBC.
3. HSBC reserves the right to disclose the credit Cardholder's information to any court of competent jurisdiction, quasi-judicial authorities, law enforcement agencies and any other wing of central government or state government.
4. The existence of HSBC Live+ Credit Card Account and details thereof (including details of credit card transactions and any defaults committed by the credit Cardholder), will be recorded with credit reference agencies and such information (including processed information) may be shared with banks/financial institutions and other credit grantors for the purpose of assessing further applications for credit by the credit Cardholder and/ or members of the credit Cardholder's household, and for occasional debt tracing and fraud prevention. The credit Cardholder accordingly, authorises HSBC to share information relating to the credit Cardholder's credit card account, including information relating to any add-on credit Cardholder(s).
5. HSBC may also provide information relating to credit history/repayment record of the credit Cardholder(s) to a credit information company (specifically authorised by RBI), in terms of the Credit Information Companies (Regulation) Act, 2005.
6. As per RBI guidelines, HSBC provides credit information relating to its credit Cardholders to Credit Information Companies (CICs) on a monthly basis. The information provided reflects the status as at the

- previous month-end and includes information regarding whether the credit card account is regular or delinquent. In the event of a credit card getting delinquent as on the date of such reporting and the account is subsequently regularized, the status of the account will only be updated prospectively, at the time of the next monthly reporting. As per Credit Information Companies (CICs), all changes in the credit Cardholder's status are updated within a maximum of 30 days. To avoid any adverse credit history with Credit Information Companies (CICs), the credit Cardholders should ensure that they make timely payment of the amount due on the credit card account.
7. The credit Cardholder acknowledges that HSBC remains entitled to assign any activities to any third party agency at its sole discretion. The credit Cardholder further acknowledges the right of HSBC to provide details of the credit card account, including those of any add-on credit Cardholder(s), to third party agencies for the purpose of availing of support services of any nature by HSBC, without any specific consent or authorisation from the credit Cardholder and/or any add-on credit Cardholders.
8. The credit Cardholder understands that as a precondition relating to grant of loans/advances/other non-fund based credit facilities to the credit Cardholder, HSBC requires consent for the disclosure by the credit Cardholder, of information and data relating to the credit Cardholder/add-on credit Cardholder(s), of the credit facility availed of/to be availed of by the credit Cardholder, obligations assumed/to be assumed by the credit Cardholder, in relation thereto and default, if any, committed by the credit Cardholder in discharge thereof.
- i. Accordingly, the credit Cardholder hereby agrees and gives consent and confirms that the credit Cardholder has obtained consent from the add-on Cardholder(s) for the disclosure by HSBC of all or any such; (a) information and data relating to the credit Cardholder/add-on Cardholder(s) (b) the information or data relating to any credit facility availed of/to be availed of by the credit Cardholder and (c) default, if any, committed by the credit Cardholder in discharge of the credit Cardholder's obligation, as HSBC may deem appropriate and necessary,
- to disclose and furnish to Credit Information Companies (CICs) and any other agency authorised in this regard by RBI.
- ii. The credit Cardholder undertakes on his/her behalf and on behalf of the add-on Cardholder(s) that (a) the Credit Information Companies (CICs) and any other agency so authorised may use, process the said information and data disclosed by HSBC; and (b) the Credit Information Companies (CICs) and any other agency so authorised may furnish for consideration, the processed information and data or products thereof prepared by them, to banks/financial institutions and other credit grantors, as may be specified by the RBI in this regard. If at the time of application for the credit card, the credit Cardholder has agreed to share his name and other contact details for communication of marketing/promotional offers, then the credit Cardholder expressly authorises HSBC to use information or data relating to the credit Cardholder/Add-on Cardholder(s), including credit information, whether provided by the credit Cardholder or otherwise, in connection with the offer, sale or distribution of HSBC's products and services to the credit Cardholder/add-on Cardholder(s). Accordingly, from time to time, HSBC will communicate various features/ products/promotional offers which offer significant benefits to its credit Cardholders and may use the services of third party agencies to do so. The credit Cardholder should intimate HSBC if he/she does not wish to be informed about such benefits through telephone calls/SMSs. Alternatively, the credit Cardholder may enroll in the 'Do Not Call (DNC)' registry.

## General

1. In addition to any general right to set-off or other right conferred by law or under any other agreement, HSBC may, without notice, combine or consolidate the outstanding balance on the credit card account with any other account(s) which the credit Cardholder may maintain with HSBC and set-off or transfer any money outstanding to the credit of such other

<!-- image -->

- account(s), in or towards the satisfaction of the credit Cardholder's liability to HSBC under this agreement.
2. Visa pay Wave enabled Contactless payment: Now you can use your credit card for contactless payments without needing to input your PIN at the Point of Sale (POS) terminals enabled for contactless payments:
- Please note that domestic payments through contactless mode is allowed for a maximum of ` 5,000 for a single transaction and for international payments, the same is allowed for a maximum amount equivalent to ` 5,000 for a single transaction. (Any change to these limit caps will be intimated to the customers in accordance with the local regulatory requirements) Transactions above the threshold amount and certain frequency will require a second factor authentication (Pin Validation) and may be restricted in accordance with the Bank's internal policies and guidelines
- Please note that, you will always have the option to choose whether you   want to opt for contactless payment at the Point of Sale (POS) terminals enabled for contactless payments. You can also pay normally by using your PIN
3. The credit Cardholder will promptly notify HSBC in writing of any changes in the employment and/or office and/or residential address and telephone numbers of the credit Cardholder.
4. In case the credit Cardholder fails to notify HSBC of any change in his/ her telephone number(s) or the address(es) and this results in HSBC's inability to confirm transactions that appear suspicious, the credit Cardholder shall remain liable for any misuse that takes place as a consequence of this inability.
5. The Bank reserves a right to block transactions/allow operations in a newly opened/existing accounts maintained with the Bank, if the account deliverables/welcome letter/welcome pack/bank correspondences not limited to Account statements, etc., are returned undelivered and Bank is unable to contact the Accountholder at the address/contact number provided by them at the time of account

opening/updated in Bank records.

6. HSBC India reserves the right to revise policies, features and benefits offered on the credit card and alter these terms and conditions from time to time and may notify the credit Cardholder of any such alterations through any of the modes of communication including (but not limited to) monthly statements, by e-mail, posting on HSBC India website, etc. Such changes (other than those which are a result of regulatory requirements) will be made after giving notice of at least 30 days on a best effort basis. If the change is to the credit Cardholder's disadvantage, the credit Cardholder may within 60-days of the change being effected and without notice, close his/her credit card account on payment of all the outstanding dues accrued on the credit card but without having to pay any extra charges (in respect to the change made). The credit Cardholder will be bound by such alterations unless the credit card is returned to HSBC for cancellation within 60 days period of notification/ change.
7. The credit Cardholder acknowledges that HSBC is not responsible for any of the services provided by third parties.
8. The credit Cardholder can pay his/her dues by account payee cheques, payable to HSBC with the credit card number duly mentioned on the cheque. The credit Cardholder will issue separate cheques for separate HSBC Primary Credit Cards held by the credit Cardholder. HSBC may exceptionally accept payments in cash not exceeding Indian Rupees fifty thousand only. Any instructions to transfer the excess credit balance in the credit card account to the credit Cardholder's savings account or current account may not be carried out.
9. HSBC may accept/act on verbal instructions from the credit Cardholder and/or his/her nominated user using HSBC's PhoneBanking service with respect to the operations and/or termination of the credit card account. HSBC shall not be liable for any loss or damage suffered by the credit Cardholder in the event that HSBC (in HSBC's absolute discretion) acts in good faith on such instructions.

10.  HSBC is authorised to act on any instructions, which HSBC at its sole discretion understands having emanated from the credit Cardholder by the use of the credit Cardholder's Internet/PhoneBanking PIN, and is not expected to verify the identity of the persons giving these instructions purportedly in the credit Cardholder's name. The credit Cardholder is expected to safeguard his/her PIN at all times and shall be liable for all transactions/instructions processed by the use or purported use of our Internet/PhoneBanking service and/or the PIN thereof, for whatsoever purpose.
11.  The Bank and other members of the HSBC Group are required to and may take any action to meet Compliance Obligations relating to or in connection with the detection, investigation and prevention of Financial Crime ('Financial Crime Risk Management Activity') and act in accordance with the laws, regulations and requests of public and regulatory authorities operating in various jurisdictions which relate to Financial Crime. The Bank may take, and may instruct (or be instructed by) any other member of the HSBC Group to take, any action which it or such other member, in its sole and absolute discretion, considers appropriate to take in accordance with all such laws, regulations and requests.

Such action may include but is not limited to (a) screening, intercepting and investigating any instruction, communication, drawdown request, application for services, or any payment sent to or by you, or on your behalf, (b) investigating the source of or intended recipient of funds (c) combining customer information with other related information in the possession of the HSBC Group, and/or (d) making further enquiries as to the status of a person or entity, whether they are subject to a sanctions regime, or confirming your identity and status (e) share information on a confidential basis with such HSBC Group offices whether located in India or overseas in relation to prevention of Financial Crime.

Exceptionally, our Financial Crime Risk Management Activity may lead to us delaying, blocking or refusing the making or clearing of any payment, the processing of your instructions or application for Services or the provision of all or part of the Services. To the extent permissible by law, neither we nor any other member of HSBC Group shall be liable to you or any third party in respect of any loss (whether direct or consequential and including, without limitation, loss of profit or interest, however it arose) that was suffered or incurred by you or a third party, caused in whole or in part in connection with the undertaking of Financial Crime Risk Management Activity.

In certain circumstances, the action which the Bank may take may prevent or cause a delay in the processing of certain information. Therefore, neither the Bank nor any member of the HSBC Group warrants that any information on the Bank's systems relating to any payment messages or other information and communications which are the subject of any action taken pursuant to this clause is accurate, current or up-to-date at the time it is accessed, whilst such action is being taken.

## For the purpose of the present clause :

'Compliance Obligations' means obligations of the HSBC Group to comply with: (a) laws or international guidance and internal policies or procedures, (b) any demand or request from authorities or reporting, disclosure or other obligations under laws, and (c) laws requiring us to verify the identity of our customers.

'Financial Crime' includes money laundering, terrorist financing, bribery, corruption, tax evasion, fraud, evasion of economic or trade sanctions, and/ or any acts or attempts to circumvent or violate any laws relating to these matters.

12.  HSBC will not be responsible if any merchant establishment refuses to accept the credit card or is unable to transact on the credit card or levies a surcharge on the credit card. However, the credit Cardholder should notify HSBC of this complaint. HSBC is not responsible or liable for any defect or deficiency in respect of goods and services charged to the credit card. Any dispute should be settled directly by the credit Cardholder with the merchant establishment and failure to do so will not relieve the credit Cardholder of any obligations to HSBC. The existence of a claim or dispute shall not relieve the credit Cardholder of his/her obligation to pay all charges and the credit Cardholder agrees to pay promptly such charges, notwithstanding any dispute or claim

<!-- image -->

whatsoever. No claim by the credit Cardholder against a merchant establishment will be the subject of a set off or counterclaim against HSBC.

13.  An e-version of the HSBC Credit Card welcome pack will be sent to your e-mail ID registered with the Bank. If your e-mail ID is not registered with the Bank, you will receive a paper version of the same at the correspondence address registered with the Bank. In case you wish to receive paper version of HSBC Credit Card welcome pack (irrespective of registering your e-mail ID) you can also place a request for the same through HSBC PhoneBanking.
14.  The credit Cardholder may request and opt to receive the statement on e-mail pursuant to which HSBC will send the Statement in an electronic format to the e-mail ID specified by the credit Cardholder. The credit Cardholder agrees, confirms and understands that in the event of the credit Cardholder opting or requesting to so receive statements vide e-mail on the e-mail ID provided by him/her to HSBC, no physical statement will be sent to the credit Cardholder by HSBC. The card member shall forthwith notify HSBC of any change in his/her e-mail ID for receiving statements as stated in the credit card application form. HSBC will be deemed to have delivered the statement to the  credit Cardholder forthwith upon the same being delivered and HSBC not receiving a delivery failure notification. Should the credit Cardholder experience any difficulty in accessing the electronically delivered statement, the credit Cardholder shall promptly advise HSBC, to enable HSBC to make the delivery through alternate means. Failure to advise HSBC, of such difficulty within 24 hours after receiving the statement shall serve as an affirmation regarding the acceptance of the statement by the credit Cardholder. The credit Cardholder confirms that he/she is aware of all security risks involved in receiving the electronically delivered statement. The credit Cardholder agrees that he/she shall not hold HSBC, in any way, responsible for the same.

15.  In case of no activity/transaction on the credit card and/or if the credit card account has remained inoperational for a period of &gt; 12 months or any such period as deemed fit by HSBC, HSBC may exercise its right to close the concerned inactive card(s), linked additional card(s) issued to family members and the dormant/inoperational credit card account by providing a 30 days' notice.

16.  Closure/termination of account: close the credit card and the credit card account of the credit Cardholder

HSBC may at any time, by providing a notice of 30 days, terminate and without assigning any reason for the same.

The credit Cardholder specifically acknowledges that once his credit card account is closed, the privileges (including but not limited to all benefits and services accrued reward points not redeemed) of the credit card shall stand withdrawn. Reinstatement of the credit card account is neither automatic nor attendant and will take place solely at the discretion of HSBC. The credit Cardholder also acknowledges that the aforementioned takes precedence over any communication in this context that the credit Cardholder might receive during the normal course.

If HSBC exits an arrangements with a co-brand partner of certain credit card(s) or any credit card product proposition, HSBC shall intimate the credit Cardholder of the same in advance and provide an option to the credit Cardholder, on best effort basis, to switch to an alternate credit card. If the credit Cardholder is not contactable or if the credit Cardholder's decision is unavailable by the end of a designated period, HSBC shall have the right to convert the current credit card of the credit Cardholder to an alternate credit card to avoid any inconvenience to the credit Cardholder that may arise due to discontinuance of the concerned credit card/credit card product that the credit Cardholder held. If during the transition from one credit card to another, there is no change in terms and conditions, HSBC can exercise its right to convert the existing credit card of the credit Cardholder to the new credit card without advance intimation. In either of the cases, switch to alternate credit card

product is subject to HSBC's internal credit policy.

17.  Amount, if any, lying to the credit of the credit card account shall be returned back to the credit Cardholder on the closure/termination of the credit card account, subject to no circumstances arising, which are beyond the control of HSBC.
18.  In line with the requirements of the Bank's policy, the Know Your Customer (KYC) documents along with other documentation need to be submitted at the time of opening a new account or as and when requested by the Bank. The Bank reserves a right to allow/restrict operations in a newly opened/ existing accounts maintained with the Bank, if the customer is not able to satisfy the due diligence requirements in line with the Bank's policy.
19.  a.    Individual Accounts: You are responsible for fulfilling any obligation that you may have with respect to the filing of returns or other required documentation in respect of and the payment of all relevant taxes, including, without limitation, all income, capital gains, wealth and estate duties, stamp duties, GST , value added tax and any other applicable taxes. The creation and continued operation of your account and/or the acquisition, holding or disposal of investments or assets in such account, as well as any income, distributions or losses realized in relation to the operation of the account may expose you to tax consequences depending on a number of factors including, but not limited to, your applicable domicile, your place of residence, your citizenship or the type of assets you hold in your account. Certain countries may have tax legislation with extraterritorial effect regardless of your place of domicile, residence or citizenship. The Bank does not provide any legal or tax advice and you should seek legal and/or tax advice from an independent legal and/or tax adviser. You acknowledge and agree that the Bank has no liability in respect of any of your tax obligations and/or any legal and/or tax advice provided to you by third parties.
- b.    Non Individual Accounts: Customer (and each Connected Persons) is responsible for fulfilling its own obligations with respect to the filing of
5. returns or other required documentation in respect of reporting and payment of all relevant taxes, including, without limitation, all income, capital gains, wealth and estate taxes. The creation and continued operation of the account and/or the acquisition, holding or disposal of investments or assets in such account, as well as any income, distributions or losses realised in relation to the operation of the account may expose you (or any Connected Person) to tax consequences depending on a number of factors including, but not limited to, applicable domicile, place of residence, citizenship, place of incorporation or the type of assets held in the account. Certain countries may have tax legislation with extra-territorial effect regardless of place of domicile, residence, citizenship or incorporation. The Bank does not provide any legal or tax advice and you (and each Connected Person) should seek legal and/or tax advice from an independent legal and/or tax adviser. You acknowledge and agree that the Bank has no liability in respect of any of your tax obligations (or those of any Connected Persons) and/or any legal and/or tax advice provided to you by third parties.
20.  The privileges of the credit card may be withdrawn and the credit card may be placed on hold or suspended by HSBC, including but not limited to the occurrence of an Event of Default (in its absolute discretion without assigning any reason therefore by giving a notice of 30 days to the credit Cardholder) either temporarily or permanently.
7. Notice for withdrawal of privileges, placing on hold or suspension either temporarily or permanently or closure of the credit card and the credit card account shall be deemed to be given when a notice is issued to the last address of the credit Cardholder known to HSBC in the ordinary course of post/courier service. HSBC shall not be held accountable for delays/nonreceipt of such notice in the post/courier service.
8. Your HSBC Credit Card transactions outside India must be made strictly in accordance with Exchange Control Regulations of the Reserve Bank of India. Kindly note that a Cardholder resident in India is notified that collecting and effecting/remitting payments directly/indirectly outside India in any form

towards overseas foreign exchange trading through electronic/internet trading portals is prohibited and a Cardholder making such transactions would make himself/herself/themselves liable to be proceeded against with for contravention of the Foreign Exchange Management Act (FEMA), 1999 besides being liable for violation of regulations relating to Know Your Customer (KYC) norms/Anti Money Laundering (AML) standards. Any violation of the Exchange Control Regulations arising out of utilisation of this HSBC Credit Card is the responsibility of the individual HSBC Credit Cardholder.

If the Bank comes across any prohibited transaction undertaken by the Cardholder vide credit card or online banking, the Bank will immediately close the card and the matter will be reported to the Reserve Bank of India. Cardholder (primary/additional) and he/she would be liable for action under the provisions of the Foreign Exchange Management Act (FEMA), 1999 and any other regulations in force from time to time. Please note that the onus of ensuring compliance with the regulations is with the holder of the international credit card. International spends both online and POS will be eligible for Cashback.

## Termination

1. The credit Cardholder may terminate the HSBC Live+ Credit Card at any time by written notice to HSBC accompanied by the return of the credit card and any additional credit cards cut into several pieces and full clearance of all the outstandings. In case of an additional credit card, the usage of the additional credit card may be discontinued by written notice to HSBC by the credit Cardholder. The credit Cardholder should destroy the additional credit card by cutting it into several pieces through the magnetic stripe.
2. HSBC may at its discretion recall the outstanding amount on the HSBC Live+ Credit Card(s)/add-on credit card(s) without assigning any reason thereof. In the event of HSBC recalling the entire outstanding amount, HSBC shall give reasonable notice in writing for paying the entire
3. outstanding amount, at the last known address of the credit Cardholder.
3. Notwithstanding anything to the contrary stated elsewhere in these terms and conditions, HSBC may at its discretion, without notice to the credit Cardholder, cancel the limit granted on the credit card account or credit card/add-on credit card(s) without assigning any reason thereof. In the event HSBC cancels the limit granted on the credit card account or credit card/add-on credit card(s) in terms of this clause, HSBC shall intimate the credit Cardholder on such cancellation.
4. The whole of the outstanding balance on the credit card account, together with the amount of any outstanding credit card transactions effected but not yet charged to the credit card account, will become immediately due and payable in full to HSBC on suspension/termination of the HSBC Live+ Credit Card for whatever reasons or on the insolvency or death of the credit Cardholder. HSBC will become entitled to recover the outstanding dues together with all expenses, legal fees, finance charges and interest from the estate of the credit Cardholder on his death, without prejudice to its rights to continue to charge the finance charges and other charges at prevailing rates till the dues are settled.
5. Any intimation given by HSBC hereunder will be deemed to have been received by the credit Cardholder within 10 days of posting on the address last notified in writing to HSBC.
6. Closure of the credit card may entail withdrawal of all the facilities provided through use of the credit card and/or the credit card number.
7. Inactive accounts:
- a. The privileges of the credit card may be withdrawn and the credit card cancelled by HSBC at any time, including on the occurrence of an Event of Default (at its absolute discretion and without giving notice thereof to the credit Cardholder or assigning any reason therefor) either temporarily or permanently.
- b. In case of temporary withdrawal of the credit card, the privileges of the credit card membership may be reinstated by HSBC at its

- discretion but will be considered as a fresh credit card membership. In case of a permanent withdrawal, HSBC may refuse to readmit a credit Cardholder permanently. However, it is made distinctly clear that withdrawal (whether temporary or permanent) shall constitute cessation of card membership altogether until the credit Cardholder is re-admitted. In case the charge facilities are at any time withdrawn (whether temporarily or permanently) the same shall constitute automatic withdrawal of all attendant benefits, privileges and services attached to credit card membership. Credit card membership may be withdrawn and account closed at any time without reference to the validity period embossed on the credit card. Further, HSBC may also restrict, terminate or suspend the use of the credit Cardholder's account at any time without prior notice, if HSBC reasonably believes it necessary for business or security reasons.
- c. Use of the credit card after notice of withdrawal of its privileges is fraudulent and subjects the credit Cardholder to legal proceedings.
- d. Notice of withdrawal or request to surrender shall be deemed given when a notice posted to the last address of the credit Cardholder known to HSBC would have been received in the ordinary course of post/courier service. HSBC shall not be held accountable for delays/nonreceipt of such withdrawal notices in the post/courier service. Notice of withdrawal may also be deemed given by an oral or written request made by a merchant establishment on behalf of HSBC.
- e. Subject to verification, the credit Cardholder can terminate the card membership/terms and conditions at any time by writing to HSBC or intimating the request for closure to 24-Hour PhoneBanking service.
- f. Upon termination of credit card membership of the credit Cardholder for any reason whatsoever, whether at the instance of the credit Cardholder or HSBC, the credit Cardholder shall remain liable for all charges incurred by the use of the credit card. The credit Cardholder acknowledges and agrees (subject to any default or other notice required by law) to immediately pay to HSBC the total outstanding
- balance on the credit card/the account, including without limitation all amounts due to HSBC under the terms and conditions (including all transactions and other amounts not yet charged to the credit card/ the Account). It is expressly understood that the account will not be considered as closed by the Bank until the credit Cardholder has paid all such due amounts.
- g. The credit Cardholder specifically acknowledges that once his account is closed, the privileges (including but not limited to all benefits, services and accrued reward points not redeemed) of the credit card stand withdrawn, reinstatement of the same is neither automatic nor attendant and will take place solely at the discretion of HSBC. The credit Cardholder also acknowledges that the aforementioned takes precedence over any communication in this context that the credit Cardholder might receive during the normal course.

## Events of Default

1. In the event of default, the credit Cardholder will be sent reminders from time to time for payment of any outstanding on the credit card account, by post, fax, telephone, e-mail, SMS and/or through third parties appointed for collection purposes to remind, follow-up and collect dues. Any third party so appointed shall adhere to the Indian Banks Association (IBA) code of conduct on debt collection.
2. The credit Cardholder understands that HSBC may conduct periodic reviews of the account based on the credit Cardholder's payment patterns and/or based on HSBC's policy and discretion. HSBC reserves its right to reduce the credit limit without any prior notice or intimation. In such an event, the credit Cardholder will be informed about the revised credit limit. Usage of the credit card shall be deemed as acceptance of the credit limit granted from time to time.
2. Recovery of dues in case of death of the credit Cardholder.
- The whole of the outstanding balance (including unbilled transactions) will become immediately due and payable to HSBC

- HSBC will become entitled to recover the total outstanding from the estate of the Cardholder

Notwithstanding anything stated hereinabove, HSBC shall be entitled to give notice to the credit Cardholder declaring that all sums of interest, costs, charges and expenses and other sums remaining outstanding under or in respect of the credit card are due and payable and upon such declaration, the same will become due and payable forthwith, notwithstanding anything to the contrary in this terms and conditions or in any other agreement(s) or instruments. The following events shall qualify as an Event of Default (hereinafter referred to as 'Events of Default') and at the option of HSBC, HSBC will, at its sole discretion, have the right to close the account, in case of an Event of Default.

3. Non-payment/delay in payment of dues: Non-payment or delay in payment of any dues payable on the credit card and/or in payment of any other amounts (including but not limited to rewrites/settlements) or any part thereof due and payable to HSBC in terms of these terms and conditions and in case such dues or other amount remains unpaid for thirty (30) days from the due date thereof.
4. Non-performance of covenants: Breach or non-performance of any other covenants, conditions or agreements on the part of the credit Cardholder under these terms and conditions.
5. Supply of misleading information: Furnishing of false, misleading or incorrect information in any material respect by the credit Cardholder to HSBC in the credit card application or otherwise.
6. Failure to furnish information/documents: Failure to furnish any information and/or documents required by HSBC by the credit Cardholder.
7. Non-payment/non-delivery of cheque(s)/other payment mechanism: If a cheque in respect of any monthly due or other payment is dishonoured or if a cheque/NACH/SI in respect of any payment is not paid on the due date thereof or if a cheque/NACH in respect of any payment is not paid
6. on the due date thereof.
8. Death of the credit Cardholder.
8. 9.
9. Default on other loans/facilities If the credit Cardholder defaults or commits any breach of any terms, covenants and conditions of any loans/facilities provided by HSBC or any other banks, financial institutions or other persons, to the credit Cardholder.
10.  Insolvency

If the credit Cardholder commits an act of insolvency or makes an application for declaring himself an insolvent or an order of insolvency is passed against the credit Cardholder.

11.  Material Adverse Change There occurs any material adverse change in the financial condition of the credit Cardholder or any other event or circumstance, which in the sole opinion of HSBC prejudicially affects the Bank's interest.
12.  Involvement in civil litigation and criminal offence In case the credit Cardholder is involved in any civil litigation or commits any criminal offence or if proceedings by any statutory authority/court of law for any misconduct or breach/violation of any law or regulations or code of conduct, etc., are initiated against the credit Cardholder; or
13.  The credit Cardholder commits any act which in the sole opinion of HSBC jeopardises HSBC's interest.
14.  Default incurred with any other bank or financial institution Without prejudice to any other rights, HSBC may have under these terms and conditions, on the occurrence of an Event of Default, the credit Cardholder shall be sent reminders from time to time by HSBC or any agency(ies) appointed by HSBC for settlement of any outstanding dues on the account or for taking any remedial action on the account/ credit Cardholder, by visits (of representatives of HSBC/third parties appointed by HSBC in this regard), post, fax, telephone, e-mail and SMS/

Your Voice Matters

HSBC PhoneBanking numbers

text messaging. In case the credit Cardholder commits any of the aforesaid Event of Default, then notwithstanding anything to the contrary herein contained or in any other agreement, document or instrument between the credit Cardholder and HSBC, HSBC shall be entitled at its absolute discretion to interalia:

- Call upon the credit Cardholder to immediately pay the entire outstanding balance on the credit card together with interest and all sums payable thereunder to HSBC under these terms and conditions and/or any other agreements, documents or instruments executed by and between the credit Cardholder and the Bank
- Exercise HSBC's right of lien and set-off all monies and accounts standing in the credit Cardholder's name in HSBC. HSBC, at any time and without notice, will have lien and the right to set-off on all monies belonging to the credit Cardholder and/or add-on credit Cardholder standing to their credit in any account/custody of HSBC, if upon demand by HSBC, the balance amount on the credit card account is not repaid within the prescribed time
- -Without prejudice to the above, HSBC shall have the right to proceed against the credit Cardholder independent of any right of lien/set-off to recover the outstanding dues from the credit Cardholder
- -If any dues or outstanding payable by the credit Cardholder to HSBC hereunder remains due and payable for a period of 7 (seven) consecutive months or more, the credit Cardholder shall be reported as a 'willful defaulter' with the RBI or any other authority

## Balance Transfer-on-EMI

1. The Balance Transfer on EMI facility allows an HSBC Credit Cardholder (Cardholder) to avail of the Balance Transfer facility on his/her HSBC Credit Card (HSBC Card) and repay the same in Equated Monthly Instalments (EMIs).
2. The minimum amount that can be transferred from any other bank credit card account to the HSBC Card is ` 5,000 subject to the availability of the credit
3. limit in your HSBC Card.
3. The Cardholder can choose from multiple tenure options from 3 months, 6 months, 9 months, 12 months, 18 months and 24 months.
4. The Equated Monthly Instalment (EMI) amount will be billed to the HSBC Card every month on your statement date. Balance Transfer transaction will block the available credit limit on the Cardholder's HSBC Card up to the amount of Balance Transfer on EMI availed of including applicable charges and Goods and Services Tax (GST).
5. The maximum amount that can be transferred from other bank credit cards to the HSBC Card is up to 95% of the credit limit on the Cardholder's HSBC Card subject to available balance as on the date of approval of the Cardholder's application. If amount requested to be transferred from other bank credit cards to the Cardholder's HSBC Card is greater than 95% of the available credit limit on the Cardholder's HSBC Card, Balance transfer (Including Interest) will be processed for an amount that equals to 95% of the credit limit.
6. During the Balance Transfer term, the balance transferred will also be included for computing the minimum payment due, as mentioned in the credit card statement from HSBC.
7. Minimum Amount Due: The Balance Transfer EMI due for the month is included as part of the minimum amount due appearing in the Cardholder's monthly statement. The minimum amount due appearing on the Cardholder's monthly statement is calculated as a percentage of the total outstanding retail balance + monthly EMI due on Balance Transfer on EMI. Non-payment of the entire total payment due on the HSBC Card by the payment due date will result in the levy of standard credit card interest rates on the balance outstanding. If only minimum amount due (as defined above) is paid, the standard credit card interest rates will be levied on the balance outstanding. However, if such partial payments do not cover the amount of EMI for the month, standard finance charges (including late payment fee) will be levied also.

As an illustration: Balance Transfer EMI = ` 1,000

Other outstanding balances = ` 2,000

Total closing balance for the month = ` 3,000

Minimum payment instruction = 5% of outstanding retail balance + EMI due on Balance Transfer

Minimum payment due = (5% x ` 2,000) + ` 1,000 = ` 1,100

Scenario I: Amount paid = ` 1,200

Amount outstanding = Total payment due - Amount paid = ` 1,800

3,000

Total closing balance for the month = `

Finance charges at the applicable rate will apply on ` 1,800 in the next billing cycle

Scenario II: Amount paid = ` 3,000

Amount outstanding - 0 No finance charges will apply

8. The balance transferred will also be included for computing the minimum payment due, as mentioned on the credit card statement from HSBC.
9. The other bank card from which the balance is to be transferred to the HSBC Card must be nondelinquent and current. HSBC will conduct a 'dummy authorisation for ` 1,000' on the other bank credit card. If the authorisation is successful, Balance Transfer transaction will be approved subject to regular Balance Transfer approval conditions.
10.  Balance Transfer Proceeds will be credited to other Bank's credit card account through NEFT only. Only on Cardholder's specific request HSBC will send Demand Draft favouring the other Bank credit card account for the approved Balance Transfer amount to the Cardholder's registered mailing address. However, in absence of any specific request, NEFT would be a preferred way for all Balance transfer proceeds.
11.  Balance Transfer processed through NEFT cannot be reversed once the request has been processed and the amount has been credited to the other Bank credit card account.
12.  If the amount (as mentioned in the verbal or written application form) to be transferred to the HSBC Card exceeds the maximum eligibility of the available credit limit on the date of acceptance by HSBC, HSBC will automatically transfer the amount which is equal to the customer's eligibility , and this policy is informed to the Cardholder at the time of application.
13.  The Cardholder should continue to make payments on the other bank credit card until the Cardholder receives confirmation in a subsequent HSBC Card statement that the Balance Transfer amount from the other bank credit card has been transferred to the HSBC Card.
14.  If the Cardholder has subscribed for the 'Credit Card Account Settlement Option' to automatically settle the credit card outstandings by a debit to the Cardholder's HSBC Current/Savings account, there will be a 5% minimum payment deducted from the outstanding instead of 100% Credit Card Account Settlement Option.
15.  Kindly note that according to the new payment hierarchy effective 5 August 2013, the payments will first be apportioned to the extent of minimum payment due, first by the following 'plans' i.e. EMI, Cash advances, Purchase outstanding and Balance Transfer in descending order of interest rates, and within a given 'plan', the payment will be allocated in a predefined order of Service charges, Finance charges, Late payment charges, Annual fee and Other fees.
16.  In the event a Cardholder transfers different amounts under different Balance Transfer options, the repayment will be allocated to the Balance Transfers in increasing order of the interest rates, i.e. the repayment will be apportioned first to the highest interest Balance Transfer for the Cardholder.
17.  Please note that the payment made will be apportioned as per the payment hierarchy. In case the amount paid does not clear the EMI amount (partly or fully), the remaining EMI amount will be added in the next month's minimum amount due along with standard interest rate charged on the said amount.

18.  Kindly note that according to the new payment hierarchy effective from 5 August 2013, the payments will first be apportioned to the extent of minimum payment due, first by the following 'plans' i.e. EMI, cash advances, purchase outstanding and Balance Transfer in descending order of interest rates, and within a given 'plan', the payment will be allocated in a predefined order of Service charges, Finance charges, Late payment charges, Annual fee and Other fees.
19.  The Cardholder can transfer outstanding balance from one or more other bank credit cards under the same or different Balance Transfer options, within this limit.
20.  HSBC reserves the right to decline or reduce the amount of any Balance Transfer request. Pre-payment charges on foreclosure of Balance Transfer on EMI will apply at the rate of 3% on the outstanding amount of the loan, subject to a minimum of ` 250.
21.  You can transfer balances from more than one other bank credit cards under the same of different Balance Transfer options, within this limit. The Balance Transfer transaction will block the available credit limit on the Cardholder's credit card up to the amount of Balance Transfer on EMI availed including applicable charges and Goods and Services Tax (GST).
22.  Upon completion of the 'Balance Transfer term', if applicable, balance amount is merged with the other outstanding on the credit card and interest will be charged as per regular rate applicable, as communicated to the Cardholder from time to time. To avail of the Balance Transfer facility, HSBC may request the Cardholder to submit a copy of his/her latest other bank credit card statement.
23.  The Cardholder should continue to make payments on the Cardholder's other bank credit card until the Cardholder receives confirmation in a subsequent HSBC Card statement that the account with the other issuer has been credited.
24.  In the event a Cardholder transfers different amounts under different Balance Transfer options, the repayment will be allocated to the Balance Transfers in
8. decreasing order of the interest rates i.e. the repayment will be apportioned first to the highest interest Balance Transfer for the Cardholder.
25.  In case a Cardholder has availed of two or more separate Balance Transfers of the same tenure, the repayment will be allocated in the same sequence that the Balance Transfers have been applied for.
26.  Any outstanding balance at the end of the Balance Transfer term, if applicable, cannot be transferred to another Balance Transfer option being offered by HSBC at that time.
27.  HSBC shall not be held liable for the service charges or late payment charges debited to your other bank credit card account due to decline or delay in execution of your Balance Transfer request. Per extant Reserve Bank of India (RBI) guideline, no advances should be granted by banks for purchase of gold in any form, including primary gold, gold bullion, gold jewellery, gold coins, units of gold Exchange Traded Funds (ETF) and units of gold mutual funds. Accordingly, conversion of such transaction into an Equated Monthly Instalment (EMI) scheme is prohibited.
28.  This facility cannot be availed of to transfer balance from another HSBC Credit Card.
29.  In case the Cardholder wants to apply for two Balance Transfers on the same other bank credit card, the subsequent request will be processed only 8 days after the previous Balance Transfer request.
30.  The entire balance outstanding on the credit card (including any balances transferred) will become payable immediately upon closure of the credit card whether such closure is initiated by the Bank or by the Cardholder.
31.  HSBC reserves the right at any time without previous notice to add, alter, modify, change or vary all or any of these terms and conditions or to replace, wholly or in part, this scheme by another scheme, whether similar to this scheme or not, or to withdraw it altogether. HSBC may at its discretion discontinue the Balance Transfer facility at any time during the pendency of the facility, foreclose the loan and debit the entire outstanding amount to the credit card.

32.  Please note that basis Goods Service Tax (GST) regulations and notified GST rates, Central GST and State/Union Territory GST or Inter-State GST , as applicable, would apply on our fees and charges with effect from 01 July 2017.
33.  If the Cardholder closes his HSBC Credit Card before all instalments have been posted, the outstanding amount will be debited to the card account as one consolidated amount.
34.  Payments made in excess of the card outstanding will not automatically be adjusted against un-billed EMIs and will hence not result in prepayment of the Balance Transfer on EMI facility. To pre-close the Balance Transfer on EMI facility, the Cardholder should contact HSBC PhoneBanking.
35.  In case of Balance Transfer on EMI, the EMI instalments will be treated as purchase outstanding for the purpose of payment apportionment. EMI payable towards Balance Transfer on EMI will be set-off first before any payment is apportioned towards other outstanding.
36.  Any payment made in excess of the Total Payment Due will only be adjusted to the future purchase outstanding in accordance to the ' payment hierarchy' as defined herein. In case there is no purchase outstanding, the payment made in excess of the Total Payment Due will be adjusted in accordance with the 'payment hierarchy', (EMI, Cash advances, Purchase outstanding and Balance Transfer in descending order of interest rates).
37.  No request for changes in the billing cycle shall be entertained during the entire loan period. The loan period is defined as the loan tenure selected by the Cardholder at the time of request.
38.  Nothing contained in this scheme shall be construed as an obligation on HSBC to continue the scheme after the scheme termination date.
39.  HSBC will not be responsible or liable for any direct or indirect loss, damage, actions, claims, demands, costs, charges, and expenses whatsoever that may be suffered, as a result of participating in the offer.
40.  All existing guidelines/rules related to the Balance Transfer including approval of Balance Transfer will be applicable. In case of any contradiction between these terms and conditions and the existing guidelines/rules, these terms and conditions shall prevail at all times.
41.  All and any disputes arising from the Balance Transfer on EMI facility shall be subject to the exclusive jurisdiction of the courts of Mumbai.
42.  The terms of this offer shall be in addition to and not in derogation of the terms contained in the Cardholder's agreement. This offer is by way of a special facility for select Cardholders and nothing contained herein shall prejudice or affect the terms and conditions of the Cardholder's agreement. The words and expressions used herein shall have the same meaning as in the Cardholder's agreement.
12. By participating in this offer, the Cardholders shall be deemed to have accepted all the terms and conditions in totality.

## Loan on Phone

1. The Loan on Phone offer is applicable only to select HSBC Live+ Credit Cardholders. To check your eligibility, please contact the HSBC's PhoneBanking Officers.
2. Loan on Phone (LOP) is a facility by which the credit Cardholder can make purchases on the Live+ Credit Card and then convert the purchase amount into instalments. The credit Cardholder can make the purchase at any merchant establishment and pursuant to the purchase get the transaction converted into an LOP . The LOP will not get processed, if there has been a reversal of the transaction or a chargeback dispute towards the said purchase transaction.
3. LOP facility can be offered only within 50 calendar days of the purchase transaction.
4. A processing fee will be applicable on availing a Loan on phone. This will reflect along with the first Equated Monthly Instalment (EMI) amount on the credit card statement.
5. The loan will be offered for various tenures available to choose.

6. The value of the transaction should be greater than ` 2,000 to be eligible for conversion to a LOP . Other debit transactions like cash withdrawals and card fees will not be eligible for this facility.

The EMI amount will be billed to the credit card every month on the same date as the first instalment date.

The annual rate of interest to be charged, processing fees and foreclosure charges, if applicable, will be communicated at the time of accepting the Loan on Phone request. The processing fee will reflect along with the first Equated Monthly Instalment (EMI) amount on the card statement. The EMI amount will be billed to the Credit Card every month on the same date as the first instalment date.

7. Minimum payment due: The LOP EMI due for the month is included as part of the minimum payment due appearing in the credit Cardholder's monthly statement. The minimum payment due appearing on the credit Cardholder's monthly statement is calculated as a percentage of the total outstanding retail balance + Monthly EMI due on LOP EMI. Non-payment of the entire total payment due on the credit card by the payment due date will result in the levy of standard credit card interest rates on the balance outstanding if minimum payment due (as defined above) is paid only, the standard credit card interest rates will be levied to the balance outstanding. However, if such partial payments do not cover the amount of EMI for the month, the balance EMI would also be subject to the applicable finance charge (including the late payment fee).

## As an illustration:

- 12-month LOP facility availed of under LOP facility = ` 10,750
- LOP instalment for the month = ` 1,000
- Other outstanding balances = ` 2,000
- Total payment due for the month = ` 3,000
- Minimum payment due = (5% x ` 2,000) + ` 1,000 = ` 1,100

## Scenario I:

- Amount paid = ` 1,200
- Amount outstanding = Total payment due - Amount paid = ` 1,800 Finance charges at the applicable rate will apply on ` 1,800 in the next billing

cycle

## Scenario II:

- Amount paid = ` 3,000
- Amount oustanding = 0

No finance charges will apply.

8. Kindly note that according to the new payment hierarchy, the credit Cardholders' payments will first be apportioned to fees and charges, outstanding on Balance Transfer, cash advances and purchase transactions in that order. Also note that the LOP EMIs will be treated as purchase outstanding for the purpose of payment apportionment. EMI payable towards LOP EMI will be set off first before any payment is apportioned towards other outstanding. Please note in case the amount paid does not clear the EMI amount (partly or fully), the remaining EMI amount will be added in the next month's minimum amount due along with applicable interest charged on the said amount.
9. Prepayment charges on foreclosure of the loan will apply as applicable.
10.  If the credit Cardholder defaults on payment of any of the EMIs, HSBC reserves the right to foreclose the LOP outstanding and debit the entire outstanding amount.
11.  If the credit Cardholder closes his credit card before all instalments have been posted, the outstanding loan amount will be debited to the credit card account as one consolidated amount.
12.  HSBC reserves the right to foreclose the loan and debit the entire outstanding amount, if the earlier payments are overdue.
13.  Any LOP requests by add-on Cardholders will be billed to the primary credit card.
14.  No request for change in card franchisee (Visa) will be entertained during the entire tenure of LOP .
15.  No request for changes in the billing cycle shall be entertained during the entire tenure of LOP . The loan tenure is defined as the loan tenure selected by the credit Cardholder at the time of request.
16.  Nothing contained in this facility shall be construed as an obligation on HSBC

- to continue the LOP facility after the facility termination date.
17.  HSBC reserves the right at any time without previous notice to add, alter, modify, change or vary all or any of these terms and conditions or to replace, wholly or in part, this facility by another facility, whether similar to this facility or not, or to withdraw it altogether. HSBC may at its discretion discontinue the LOP facility at any time during the pendency of the facility, foreclose the loan and debit the entire outstanding amount to the credit card.
18.  The credit Cardholder will not hold HSBC responsible for or liable for, any actions, claims, demands, losses, damages, costs, charges and expenses that a credit Cardholder may suffer, sustain or incur by way of this LOP facility.
19.  All and any disputes arising from the LOP facility shall be subject to the exclusive jurisdiction of the courts of Mumbai. The terms of this offer shall be in addition to and not in derogation of the terms contained in the terms and conditions for card usage. This offer is by way of a special facility for select credit Cardholders and nothing contained herein shall prejudice or affect these terms and conditions.

'For details on the applicable interest rate and processing fee, please visit www.hsbc.co.in or contact our HSBC's PhoneBanking Officers'.

Please note that basis Goods Service Tax (GST) regulations and notified GST rates, Central GST and State/Union Territory GST or Inter-State GST , as applicable, would apply on our fees and charges with effect from 01 July 2017.

## Cash-on-EMI

The Cash-on-EMI facility is brought to you by The Hongkong and Shanghai Banking Corporation Limited, India (HSBC) and any participation is voluntary. This offer is applicable to only selected HSBC Credit Cardholders (hereinafter referred to as the 'Cardholder').

1. The Cash-on-EMI facility allows the Cardholder to avail of the cash advance facility on his/her HSBC Credit Card (Card) and repay the same in Equated Monthly Instalments (EMI's). This facility will be
2. available till further notice. Availing/use of the Cash-on-EMI facility will be deemed to be unconditional acceptance of the terms and conditions and the Cardholder will be bound by the same.
2. The Cash-on-EMI proceeds will be credited to the Bank account provided by the Cardholder through NEFT only. Only on Cardholder's specific request amount will be provided in the form of an Cashier Order issued by debit to the Cardholder's account. The Cashier Orders under this facility will be issued in favour of the Cardholder only and will be dispatched to the Cardholder's registered mailing address. However, in absence of any specific request, NEFT would be a preferred way for all Cash on EMI proceeds.
3. Cashier Orders if any issued on specific request from customer for Cash-on-EMI will be valid for the period mentioned on the Cashier Order. If the Cashier Order issued, is not presented for encashment within the said period, the same will be cancelled.
4. Cardholders also have an option to receive the Cash-on-EMI amount credit to their resident savings/current account with HSBC. In such cases, the recipient account should belong to the Cardholder as a Resident Individual or Resident Joint (either or survivor) account. It is the sole responsibility of the Cardholder to provide an accurate and valid HSBC account number accordingly.
5. Cash-on-EMI processed through NEFT cannot be reversed, once the request has been processed and the amount has been credited to the other bank account.
6. If the NEFT request is rejected for any reason, HSBC will arrange to send the facility in the form of a Cashier Order and the same will be dispatched to the Cardholder's mailing address on record. HSBC shall not be liable for any direct or consequential loss or damage suffered by the Cardholder on account of any delay in receipt of the Cashier Order by the Cardholder.
7. The proceeds of the Cash-on-EMI facility cannot, however, be used for the purpose of investment in equity shares, convertible bonds

- and debentures and units of equity oriented mutual funds.
8. The amount of cash advance disbursed will be at the sole discretion of HSBC. The minimum amount eligible for the Cash-on-EMI facility will be ` 5,000.
9. The Cash-on-EMI tenure applicable to your loan is mentioned on the payment advise sent with the Cashier Order or on the e-mail/SMS sent in case of NEFT transfer.
10.  A processing fee, subject to minimum of ` 200 will be applicable on the amount of each cash advance transaction availed under the Cash-on-EMI facility. The applicable processing fees will be communicated at the time of availing the facility and the same will reflect along with the first   EMI amount on the card statement. The annual rate of interest applicable to your loan is mentioned on the payment advise sent with the cashier order or the e-mail/SMS sent in case of NEFT .
11.  Prepayment charges on foreclosure of the loan will apply at the rate of 3% on the outstanding principal amount of the loan, subject to a minimum of ` 250.
12.  The maximum amount that can be offered is up to 95% of the credit limit on the Cardholder's HSBC Credit Card subject to available balance  as on the date of approval of the Cardholder's application. If the outstanding balance on the HSBC Credit Card exceeds 95% of the credit limit on the date of acceptance by HSBC, HSBC will not be able to process the request and the same will be intimated to the customer.
13.  The credit limit on the Card account will be reduced to the extent of the principal amount of the Cash-on-EMI availed including applicable charges and Goods and Services Tax (GST). The limit will be released as and when EMIs are billed and paid for in the subsequent months.
14.  The first EMI will be reflected in the Card statement generated on the subsequent billing date. The subsequent EMI amount will be billed to the Card account every month on the same date as the first EMI date.
15.  Minimum Amount Due: The Cash-on-EMI due for the month is included as part of the minimum amount due appearing in the Cardholder's
- monthly statement. The minimum amount due appearing on the Cardholder's monthly statement is calculated as a percentage of the total outstanding retail balance plus any other EMI due plus monthly EMI due on Cash-on-EMI.
16.  Non-payment of the entire total payment due on the Card by the payment due date will result in the levy of standard credit card interest rates on the balance outstanding. If only the minimum amount due (as defined above) is paid, the standard credit card interest rates will be levied on the balance outstanding. However, if such partial payments do not cover the amount of EMI for the month, standard finance charges (including late payment fee) will also be levied.

## Illustration:

- 12-month cash advance availed of under Cash-on-EMI facility = ` 10,750
- Cash-on-EMI instalment for the month = ` 1,000
- Other outstanding balances = ` 2,000
- Total payment due for the month = ` 3,000
- Minimum payment due = (5% x ` 2,000) + ` 1,000 = ` 1,100

## Scenario I:

- Amount paid = ` 1,200
- Amount outstanding = Total payment due - Amount paid= ` 1,800 Finance Charges at the applicable rate will apply on ` 1,800 in the next billing cycle.

## Scenario II:

- Amount paid = ` 3,000
- Amount rolled over = 0
- No finance charges will apply
17.  Kindly note that according to the new payment hierarchy, the Cardholders payments will first be apportioned to fees and charges, outstanding on Balance Transfer, cash advances and purchase transactions in that order.
18.  Also note that the Cash-on-EMI instalments will be treated as purchase outstanding for the purpose of payment apportionment. EMI payable towards Cash-on-EMI will be set off first before any payment is apportioned towards

Your Voice Matters

- other outstanding. Please note, in case the amount paid does not clear the EMI amount (partly or fully), the remaining EMI amount will be added in the next month's minimum amount due along with the standard interest charged on the said amount.
19.  If the Cardholder defaults on payment of any of the EMIs, HSBC reserves the right to foreclose the Cash-on-EMI outstanding and debit the entire outstanding amount.
20.  Payments made in excess of the Card outstanding will not automatically be adjusted against unbilled EMIs and will hence, not result in prepayment of the Cash-on-EMI facility. To pre-close the Cash-on-EMI facility , the Cardholders should contact HSBC PhoneBanking.
21.  If the Cardholder closes his Card before all applicable EMIs are posted to the Card account, the outstanding Cash-on-EMI amount will be debited to the Card account as one consolidated amount.
22.  If the Cardholder defaults on payment of any of the EMIs, HSBC reserves the right to foreclose the Cash-on-EMI outstanding and debit the entire outstanding amount.
23.  Requests for change in Card franchisee (Visa) shall not be entertained during the tenure of the Cash-on-EMI facility.
24.  No request for changes in the billing cycle shall be entertained during the tenure of the Cash-on-EMI facility.
25.  HSBC reserves the absolute right to add, alter, modify, change or vary all or any of these terms and conditions or to replace, wholly or in part, this scheme by another scheme, whether similar to this scheme or not, or to withdraw it altogether, at any time without any prior notice. HSBC may at its discretion discontinue the Cash-on-EMI facility at any time during the pendency of the facility, foreclose the loan and debit the entire outstanding amount to the credit card.
26.  Cardholders will not hold HSBC responsible for or liable for, any actions, claims, demands, losses, damages, costs, charges and expenses that a Cardholder may suffer, sustain or incur by availing of the Cash-on-EMI facility .
27.  All disputes arising from the Cash-on-EMI facility shall be subject to the
- exclusive jurisdiction of the courts of Mumbai.
28.  The terms of this offer shall be in addition to and not in derogation of the other terms contained in the terms and conditions for card usage. This offer is by way of a special facility for select Cardholders and nothing contained herein shall prejudice or affect the terms and conditions of the terms and conditions for card usage. The words and expressions used herein shall have the same meaning as in the terms and conditions for card usage.

This offer is by way of a special facility for select credit Cardholders and nothing contained herein shall prejudice or affect these terms and conditions. For details on the applicable interest rate and processing fee, please visit www.hsbc.co.in or contact our HSBC's PhoneBanking Officers'.

## Balance Conversion

1. Cardholders can convert the retail outstanding balance on the HSBC Credit Card into loan and pay back in instalments (hereinafter referred to as 'Offer' or 'Balcon' or 'Balance Conversion').
2. Any participation is voluntary. This offer is applicable to only selected HSBC Credit Cardholders (hereinafter referred to as the 'Cardholder'). To check your eligibility, please contact the HSBC's PhoneBanking Officers.
3. In Balcon, the Cardholder can convert the retail outstanding balance, due to HSBC, either billed or unbilled by request.
4. Balcon can be offered only on the outstanding balance on the day of request and will not be applicable to balance for which the payment has been made and/or credit received on the said card account.
- a. If the Cardholder uses his card for further purchases, the amount requested on the day of the request will be considered and processed. The conversion will not be applicable for further purchases made on the card.
- b. If the Cardholder makes a part payment on his outstanding balance, post placing a Balance Conversion request to HSBC, the conversion will be processed for the outstanding balance as applicable, post the payment

- or credit subject to the maximum amount on the day of request.
5. The value of the balance being converted should be greater than ` 5,000 to be eligible for Balance Conversion.
6. The annual rate of interest charged and the processing fees will be communicated at the time of the conversion being requested. The interest rate and the processing fees communicated at the time of accepting the Balance Conversion request will be charged for all accepted requests. The processing fee will reflect along with the first Equated Monthly Instalment (EMI) amount on the card statement.
7. The Balance Conversion will be offered for various tenures available to choose.
8. HSBC reserves the right to decline the request taken for Balance Conversion if the same does not meet the HSBC's internal guidelines at the time of booking the same.
9. The EMI amount will be billed to the credit card every month on the same date as the first instalment date.
10.  The Balance Conversion EMI due for the month is included as part of the minimum amount due appearing in the Cardholder's monthly statement.
11.  The 'Minimum amount due' appearing on the Cardholder's monthly statement is calculated as a percentage of the total outstanding retail balance plus Monthly EMI due on Balance Conversion. Non-payment of the entire total payment due on the card by the payment due date will result in the levy of standard credit card interest rates on the balance outstanding. If only the minimum amount due is paid, then the standard credit card interest rates will be levied on the balance outstanding.
- However, if such partial payments do not cover the amount of EMI for the month, the balance EMI would also be subject to standard finance charge (including the late payment fee).

## As an illustration:

- 12-month Balance Conversion availed of under Balcon facility = ` 10,750
- Other outstanding balances = ` 2,000
- Balcon instalment for the month = ` 1,000
- Total payment due for the month = ` 3,000
- Minimum payment due = (5% x ` 2,000) + ` 1,000 = ` 1,100

## Scenario I:

- Amount paid = ` 1,200
- Amount outstanding = Total payment due - Amount paid = ` 1,800 Finance charges at the applicable rate will apply on ` 1,800 in the next billing cycle

## Scenario II:

- Amount paid = ` 3,000
- Amount outstanding = 0

No finance charges will apply.

12.  Kindly note that according to the payment hierarchy, the Cardholders payments will first be apportioned to fees and charges, outstanding on Balance Transfer (BT), cash advances and purchase transactions in that order. Also note that the Balcon EMI instalments will be treated as purchase outstanding for the purpose of payment apportionment. EMI payable towards Balance Conversion EMI will be set off first before any payment is apportioned towards other outstanding. Please note, in case the amount paid does not clear the EMI amount (partly or fully), the remaining EMI amount will be added in the next month's minimum amount due along with standard interest charged on the said amount.
13.  If the Cardholder has signed up for a Standing Instruction (SI) to automatically settle the credit card outstanding (minimum amount due or total amount due or a % of total amount due) by a debit to his/her current/savings account, a new SI has to be submitted. The current SI signed up for may not cover monthly EMI due towards LOP , Cash-on-EMI, Balance Transfer-on-EMI and hence, the need to resubmit a new SI. Cardholders have to arrange for making payments against the credit card outstanding (including EMIs) by the payment due dates, till such time new SI is activated on their account.
14.  Prepayment charges on foreclosure of the loan will apply at the rate as applicable.
15.  If the Cardholder defaults on payment of any of the EMIs, HSBC reserves the right to foreclose the Balance Conversion outstanding and debit the entire outstanding amount.

16.  If the Cardholder request for closure of his credit card before all instalments has been posted, the outstanding loan amount will be debited to the credit card account as one consolidated amount. The credit card will be closed post payment of complete outstanding on the credit card.
17.  HSBC reserves the right to foreclose the Balcon and debit the entire outstanding amount, if the earlier payments are overdue.
18.  Any Balcon requests by add-on Cardholders will be billed to the primary card.
19.  No request for change in card franchisee (Visa) will be entertained during the Balcon tenure.
20.  No request for changes in the billing cycle shall be entertained during the Balcon tenure.
21.  Nothing contained in this scheme shall be construed as an obligation on HSBC to continue the offer after the termination date.
22.  HSBC reserves the right at any time without prior notice to add, alter, modify, change or vary all or any of these terms and conditions or to replace, wholly or in part, this offer by another offer, whether similar to this offer or not, or to withdraw it altogether. HSBC may at its discretion discontinue the Balance Conversion Offer at any time during the pendency of the Offer, foreclose the loan and debit the entire outstanding amount to the credit card.
23.  The Cardholder will not hold HSBC responsible or liable for, any actions, claims, demands, losses, damages, costs, charges and expenses that a Cardholder may suffer, sustain or incur by way of this facility.
24.  All and any disputes arising from the Balance Conversion shall be subject to the exclusive jurisdiction of the courts of Mumbai only. The terms of this Offer shall be in addition to and not in derogation to the terms contained in the terms and conditions for card usage. This Offer is for select Cardholders and nothing contained herein shall prejudice or affect the terms and conditions of the terms and conditions for card usage.

## Instant EMI

1. This offer of 'Instant EMI' facility is brought to you by The Hongkong and Shanghai Banking Corporation Limited, India (HSBC) and any participation is voluntary. This offer is applicable to HSBC Credit Cardholders. To check your eligibility, please contact the HSBC's PhoneBanking Officers.
2. Instant EMI is a facility by which the Cardholder can make purchases on the HSBC Credit Card and then convert the purchase amount into instalments. The Cardholder can make the purchase at select merchant establishment and get the transaction converted into an Instant EMI.
3. Instant EMI facility is available at select merchants only and additions/ deletions may be made to the list without any prior notice to the Cardholder.
4. The Instant EMI facility is subject to final approval from HSBC and the customer notes that in certain exceptional circumstances including but not limited to customers, card going delinquent, blocked, etc., between the time of purchase and settlement by the Bank, the EMI facility may be rescinded, post the transaction approval.
5. The value of the transaction should be greater than ` 2,000 to be eligible for conversion to an Instant EMI. Other debit transactions like cash withdrawals and card fees will not be eligible for this facility.
6. The rate of interest and processing fees applicable will be charged as mentioned on the consent form signed by the Cardholder at the time of placing the request for conversion of transaction into Instant EMI.
7. The tenure of the loan will be chosen by the Cardholder at the time of placing the request for Instant EMI from the available options. The tenure chosen by the Cardholder will be mentioned on the consent receipt and cannot be changed at a later stage.
8. The Equated Monthly Instalment (EMI) amount will be billed to the credit card every month on the same date as the first instalment date.
9. Minimum amount due: The Instant EMI instalment due for the month is included as part of the minimum amount due appearing in the Cardholder's monthly statement. The minimum amount due appearing on the Cardholder's monthly statement is calculated as a percentage

HSBC PhoneBanking numbers

of the total outstanding retail balance plus Monthly EMI due on Instant EMI. Non-payment of the entire total payment due on the card by the payment due date will result in the levy of standard credit card interest rates on the balance outstanding. If minimum amount due (as defined above) is paid only, the standard credit card interest rates will be levied on the balance outstanding. However, if such partial payments do not cover the amount of EMI for the month, the balance EMI would also be subject to standard finance charge (including the late payment fee).

## As an illustration:

- 12-month Instant EMI facility availed = ` 10,750
- Other outstanding balances = ` 2,000
- Instant EMI instalment for the month = ` 1,000
- Other outstanding balances = ` 2,000
- Total payment due for the month = ` 3,000
- 1,100
- Minimum payment due = (5% x ` 2,000) + ` 1,000 = ` Scenario I:
- Amount paid = ` 1,200
- Amount outstanding = Total payment due - Amount paid = ` 1,800 Finance charges at the applicable rate will apply on ` 1,800 in the next billing cycle.

## Scenario II:

- Amount paid = ` 3,000
- Amount outstanding = 0

## No finance charges will apply.

10.  Kindly note that according to the payment hierarchy, the Cardholders payments will first be apportioned to fees and charges, outstanding on Balance Transfer, cash advances and purchase transactions in that order. Also note that the Instant EMI instalments will be treated as purchase outstanding for the purpose of payment apportionment. EMI payable towards Instant EMI will be set off first before any payment is apportioned towards other outstanding.

Please note, in case the amount paid does not clear the EMI amount (partly or fully), the remaining EMI amount will be added in the next month's minimum amount due along with standard interest charged on the said amount.

11.  Prepayment charges on foreclosure of the loan will apply at the rate of 3% on the outstanding principal amount of the loan, subject to a minimum of ` 250.
12.  In an event the Cardholder cancels a transaction (purchase) post its conversion to Instant EMI option, a charge of 1% of the transaction amount subject to minimum of ` 150 will be levied.
13.  If the Cardholder defaults on payment of any of the EMIs, HSBC reserves the right to foreclose the Instant EMI outstanding and debit the entire outstanding amount.
14.  If the Cardholder closes his credit card before all instalments have been posted, the outstanding loan amount will be debited to the credit card account as one consolidated amount.
15.  HSBC reserves the right to foreclose the loan and debit the entire outstanding amount if the earlier payments are overdue.
16.  Any Instant EMI requests by add-on Cardholders will be billed to the primary card. And such requests shall be binding upon the primary Cardholder and the primary and add-on Cardholders shall be jointly and severally liable for the transaction and for availing of this facility.
17.  No request for change in card franchisee (Visa) will be entertained during the entire loan period.
18.  No request for changes in the billing cycle shall be entertained during the entire loan period. The loan period is defined as the loan tenure selected by the Cardholder at the time of request.
19.  Nothing contained in this scheme shall be construed as an obligation on HSBC to continue the scheme after the scheme termination date.
20.  HSBC reserves the right at any time without prior notice to add, alter, modify, change or vary all or any of these terms and conditions or to replace, wholly or in part, this scheme by another scheme, whether similar to this scheme or not, or to withdraw it altogether. HSBC may at its discretion discontinue the Instant EMI facility at any time during the pendency of the facility, foreclose the loan and debit the entire outstanding amount to the credit card.

## Most Important Terms and Conditions and Tariff Sheet

To get the complete version, please visit www.hsbc.co.in

## 1.  Fees and Charges

- a.    Joining fee for Cashback/Live+ Primary Cardholder is INR 999 for all variants.

Joining fee for add-on cardholder(s) is NIL for all variants.

## b. Annual membership fees

Annual membership fees are applicable on the primary and add-on credit card(s). These fees may vary depending on the offer under which the HSBC Credit Card has been availed of by the Cardholder. These fees, including fees for any add-on Cardholder(s), as applicable, are charged to the Cardholders credit card account on issuance/renewal and the same would be reflected in the monthly credit card statement of the month in which it is charged. No refund of fees will be available, if the credit card is terminated. Current charges are mentioned in the tariff sheet given below.

## c. Cash advance fees

The Cardholder has access to cash, round the clock, at HSBC/Visa ATMs in India and overseas. A transaction fee of 2.5% of the transaction amount (subject to a minimum of ` 500) would be levied on all such transactions at the time of posting of the cash advance and would be billed to the Cardholder in the next monthly statement. The transaction fee is subject to change at the sole discretion of HSBC.

Cash advance transactions are also subject to a finance charge at the prevailing rate calculated on daily outstanding balances from the date of withdrawal. The finance charge will be debited to the credit card account on the last day of the billing cycle.

## d. Service charges levied for certain transactions

- Fees and charges, as may be applicable from time to time, are payable by the cardholders for specific services provided to the

cardholder or for defaults committed by the Cardholder with reference to his/her card account

- Tariff structure is subject to change from time to time at the sole discretion of HSBC. Such changes will be made with prospective effect giving notice of at least 30 days.
- Please be advised that applicable Indirect Taxes including GST would be recovered on all our fees and charges and any other amount liable to tax under prevailing Indirect Tax HSBC Maharashtra GST No. - 27AAACT2786P3ZL Address: 52/60, Mahatma Gandhi Road, Fort, Mumbai - 4000 01 HSN (Harmonised System Nomenclature) Code: 997113 - Credit Card services
- I/We hereby declare that though our aggregate turnover in any preceding financial year from 2017-18 onwards is more than the aggregate turnover notified under sub-rule (4) of rule 48, we are not required to prepare an invoice in terms of the provisions of the said sub-rule
- Late payment charge will be applicable, if minimum payment due is not paid by the payment due date
- Overlimit charges is applicable in the event of total outstandings exceeding the credit limit assigned

## Tariff sheet

| Standard joining fees   | ` 999                                                                                                                                                                                                                                                                  |
|-------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Standard annual fees    | ` 999 + taxes (Waived off for annual spends of ` 200,000 lakhs or more) Joining fee will be charged post first transaction on card. Annual fee will be charged at the end of the anniversary year and will be reversed off subsequently on meeting the spend Criteria. |

| Balance transfer charges                                                                                                                                                                | Rate of interest: 10.99% p. a. to 15.99% p. a. across tenures                                                                            |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                                                                         | Processing fee: 1.5% subject to a minimum of ` 200                                                                                       |
| Standard annual fees for Premier Customers                                                                                                                                              | NIL                                                                                                                                      |
| Free credit period                                                                                                                                                                      | Up to 45 days Please note that the free credit period is not valid if any balance of the previous months' bills are outstanding          |
| Finance charges on extended credit                                                                                                                                                      | 3.75% per month (45% b per annum) computed from the date of transaction b or at such modified rates as decided by HSBC from time to time |
| Finance charges on cash advance and transactions in categories such as money transfer (wire transfer), foreign currency purchase, money orders, traveler cheques, debt repayments, etc. | 3.75% per month (45% per annum) computed from the date of transaction                                                                    |
| Currency conversion charge (Foreign currency transactions)                                                                                                                              | 3.5%                                                                                                                                     |

| Minimum Payment Due (MPD) on credit usage                                               | Higher of ` 100 OR Sum of: a. 100% of all Interest, Fees and Taxes billed in the current statement b. 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any) c. Higher of (Past due*; Over limit amount if any) d. 1%of the billed statement balance (excluding any EMI balance, fees, interest and taxes billed) *Past due refers to unpaid Minimum Payment Due from the previous cycle   |
|-----------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Charge in case of bounced cheque, dishonoured SI or unsuccessful payment through NACH   | ` 500                                                                                                                                                                                                                                                                                                                                                                                                                         |
| Cash advance limit # (against credit card account)                                      | As communicated in your monthly card statement                                                                                                                                                                                                                                                                                                                                                                                |
| Transaction fee for cash advances against your credit card account at branches and ATMs | 2.5% of transaction amount (subject to a minimum amount of ` 500) 2                                                                                                                                                                                                                                                                                                                                                           |
| Transaction fee for cash withdrawal against your bank account at ATMs overseas          | ` 100 at ATMs overseas                                                                                                                                                                                                                                                                                                                                                                                                        |
| Overlimit fee                                                                           | 2.5% of the overlimit amount or INR 500(whichever is higher) + applicable GST                                                                                                                                                                                                                                                                                                                                                 |

| Late payment fee (Charged if the minimum amount is not credited in the card within 3 days of Payment Due Date)   | 100% of the minimum payment due (subject to a minimum of ` 250 and a maximum of ` 1,200 per month)   |
|------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|
| Rental and related payments (w.e.f. 25 January 2023)                                                             | 1% processing fee plus the applicable taxes                                                          |

NOTE: All fees will be charged along with applicable taxes. If a 100% interest refund EMI plan is communicated by the merchant, the interest component pertaining to the EMI will be charged by HSBC as applicable. However, the interest will be refunded as an upfront discount/cashback by the merchant to the card/ wallet as communicated at the time of the purchase. Applicable taxes on interest charged by HSBC will be borne by the cardholder.

## · Finance Charge Illustration

Let's say you purchase a watch for ` 1,200 on 01 March and a necklace for ` 800 on 10 March. The following interest will be charged on your purchases:

| Outstanding due in the 20 March statement                      | ` 2,000.00   |
|----------------------------------------------------------------|--------------|
| Payment made on the due date of 04 April                       | ` 100.00     |
| Balance carried forward (revolved)                             | ` 1,900.00   |
| Interest calculations: (3.49% p.m.)                            |              |
| a) Interest on ` 1,200 for 35 days (from 01 March to 04 April) | ` 51.00      |
| b) Interest on ` 800 for 26 days (from 10 March to 04 April)   | ` 25.00      |
| c) Interest on ` 1,900 for 15 days (from 05 April to 20 April) | ` 37.00      |
| Total interest charged in the 20 April statement               | ` 113.00     |
| GST @18.00% on interest                                        | ` 20.00      |

| Outstanding due in the 20 April statement   | ` 2,033.00   |
|---------------------------------------------|--------------|

Making only the minimum payment every month would result in the repayment stretching till the entire outstanding is settled and consequent payment on your outstanding balance during this extended period.

## Note:

No refund of annual fee will be available if the credit card is terminated. Tariff structure is subject to change from time to time at the sole discretion of HSBC. The Bank will notify you of any changes in the terms and conditions of this product with prior notice of 30 days. Please be advised that applicable Indirect Taxes including Goods and Services Tax (GST) would be recovered on all our fees and charges and any other amount liable to tax under prevailing Indirect Tax Laws.

The credit limit and cash withdrawal limit (20% of credit limit or as decided by the Bank from time to time) are communicated to you in your monthly card statement. The available credit limit is provided as part of the monthly card statement.

The Bank reserves its right to reduce the credit limit without any prior notice or intimation. Usage of the credit card shall be deemed as acceptance of the credit limits granted from time to time.

## e. Finance charges

- Cardholders can avail of the 'extended credit facility' by paying the Minimum Payment Due (MPD) indicated in the monthly credit card statement. The MPD is calculated as sum of 100% of all Interest, Fees and Taxes billed in the current statement and 100% of Equated Monthly Instalment (EMI) amounts billed in the current statement (if any) and higher of (Past due*; Over limit amount if any) and 1% of the billed statement balance (excluding any EMI balance, fees, interest and taxes billed), subject to a minimum of ` 100. Interest will be charged on the extended credit as per terms and conditions

- If Cardholders avail of the extended credit facility by paying an amount less than the statement closing balance, the entire outstanding amount will attract a finance charge from the respective date of transaction at the prevailing rate. All new transactions will also attract a finance charge from the respective date of transaction
- All cash advance transactions will attract a finance charge at the prevailing rate from the date of withdrawal, until the entire amount along with the charges are cleared
- Finance charges are computed from the date of transaction at 3.75% per month (45% per annum) or at such modified rates as decided by the Bank from time to time.

## f. Late payment fee:

Late payment fee (Charged if the minimum amount due is not credited in the card by the payment due date) is 100% of the Minimum Payment Due (MPD) - Subject to minimum fees of ` 250 and maximum fees of ` 1,200 per month. Please note that the Late Payment Fees is levied only if the Minimum Payment Due is not paid by the due date. Illustrative examples of how Late Payment Charges are calculated - Assume you receive a statement for the period 16 October - 15 November, with a payment due date of 07 December.

Payment of Minimum Payment Due (MPD) is required to be received in the card account by the payment due date (07 December) to ensure that no late   payment fees are levied. Late payment fees will be levied as per the illustration in the table given below:

| MPD ( ` )   | Late payment charges ( ` )   | Description                                                                                                   |
|-------------|------------------------------|---------------------------------------------------------------------------------------------------------------|
| ` 100       | ` 250                        | 100% of MPD i.e. on ` 100 is ` 100. Since the minimum fee is ` 250, the late payment fee levied will be ` 250 |

| ` 250   | ` 250   | 100% of MPD i.e. on ` 250 is ` 250, hence the late payment fees levied would be ` 250.                                                  |
|---------|---------|-----------------------------------------------------------------------------------------------------------------------------------------|
| ` 500   | ` 400   | 100% of MPD, i.e. ` 500 is ` 500, hence the late payment fees levied would be ` 500.                                                    |
| ` 1,500 | ` 1,200 | 100% of MPD, i.e. on ` 1,500 is ` 1,500. However since maximum fee applicable is ` 1,200, the late payment fee levied would be ` 1,200. |

## g. Interest free (grace) period:

The Interest free credit period could range from 45 days (Cashback/Live+ Card ) to 48 days (Platinum + Smart Value). This means that a customer who has a billing date of 5th of the month can spend on his Card from 6 May to 5 June, his bill will be generated on 5 June and his Payment Due Date will be 21 June (45 days for cashback/Live+ card) and (24 June for Smart Value and Platinum cards). This is applicable provided the credit card outstanding, as shown on monthly credit card statement, is settled fully within 3 days (Grace Period) of payment due date. However, the free credit period will not be applicable for cash advance transactions. Please note that the free credit period is not valid if any balance of the previous month's bill is outstanding.

## 2. Credit Limits

1. The credit limit and cash withdrawal limit (20% of credit limit or as decided by the Bank from time to time) are communicated to you in your monthly card statement. The available credit limit is provided as part of the monthly statement. The Bank reserves its right to reduce the credit limit. Usage of the card shall be deemed as acceptance of the credit limits granted from time to time.
2. Credit limit means the limit up to which the Card Member is authorised to spend on his Credit Card. This limit is specified in the mailer

## accompanying your HSBC Credit Card.

3. We may, for your convenience authorise transactions in certain circumstances above your total credit limit. An Over Limit Charge as enumerated in the Tariff of Charges section of the Most Important Terms and Conditions shall be levied for such transactions which exceed your credit limit.
4. The credit limit approved on the account is shared between the primary cardholder and the add-on Cardholders.
5. The available credit limit on your credit card account is the applicable credit limit less the 'Total Amount Due'. The Cardholder should refer to the Bank to ascertain the available credit limit at any point in time The available credit limit is also provided as part of the monthly statement.

The Bank reserves its right to reduce the credit limit. Usage of the card shall be deemed as acceptance of the credit limits granted from time to time.

In case the total outstanding exceeds the credit limit, all purchases/ cash transactions initiated beyond this limit will be declined till the credit card account is funded fully or partly.

For certain transactions on the credit card, with an objective to enhance customer experience, accounts will be allowed to transact higher than the credit limit (up to 145% for Premier credit cards and up to 130% for non-premier credit cards), considering the bank's internal policy and risk assessment. These additional limits maybe revised from time-to-time and shall be suitably amended in this section.

The Cardholder may apply for a review of his assigned credit limit at any time after six months of satisfactory credit card operations.

## 3.  Billing and Payments

- a. Payments made to the Cardholders account will be settled in the following order:
1. Service charges*, 2. Interest/finance charges, 3. Late payment fee,   4. Annual fee, 5. Overlimit fee, 6. Instalment handling fee, 7. Instalment processing fee, 8. Return cheque charges, 9. Insurance premium, 10. Principal**
3. *Service charges include the following:
- Cash Advance Fee, GST, Card Replacement Fee, Statement Reprint Fee, Balance Transfer processing fee, Standing Instruction (SI) failed fee
5. **Principal - Includes purchase amount, Balance Transfer principal amount and cash withdrawn on the credit card.
- b. When the credit card account has an outstanding balance, HSBC will send a monthly itemised statement of account at the mailing address indicating the payments credited and the transactions debited to the cardholders account since the last statement. Nonreceipt of the statement would not affect the cardholders obligations and liabilities.
7. If the due date for payment of outstanding dues of your Card account falls on a Sunday/Public holiday(s), the same shall have to be paid/debited on the next working day. Due and applicable interest will be calculated inclusive of said Sunday/Public holiday(s) and shall be payable by the Cardholder to the Bank.
- c. Cardholders may choose to pay only the minimum payment due, as printed on the statement and such payment should be sent before the payment due date, which is also printed on the statement. If payment is made by cheque, the funds must be realised in the card

account by the due date. The outstandings carried forward will attract a finance charge of 3.49% per month (41.88% per annum) or as decided by the Bank from time to time.

- d. Cardholders can choose from following modes of payment to settle monthly dues.
- Cheque/draft payment: The cheque/draft should be made payable to 'HSBC A/c No. XXXX XXXX XXXX XXXX (mention Cardholder's 16-digit credit card number)

Cheque/draft payment can be submitted at:

- Drop-boxes at HSBC branches/ATMs in India (visit www.hsbc.co.in for a complete list of branches and ATMs)
- Mail to The Hongkong and Shanghai Banking Corporation Limited,   Clearing Department, M G Road, Fort, Mumbai - 01
- Cash payment: Cash payments can be made at any HSBC branch in India
- Standing instruction: If the Cardholder is an accountholder with HSBC, he/she can issue a standing instruction for transferring funds from the cardholder's HSBC account to the credit card account
- Internet Banking: Cardholder can pay bills online conveniently by logging onto HSBC Personal Internet Banking* *Option available for HSBC accountholders only.
- NACH: Cardholders can make payment directly by authorising HSBC to debit a Cardholders account with any bank. This facility is available only in Mumbai and Delhi
- National Electronic Funds Transfer (NEFT): You can make a payment towards your credit card account via NEFT, mentioning the complete 16-digit credit card number
- ATM/PhoneBanking: Cardholder can access their account with HSBC through ATM/PhoneBanking facility for making payments against credit card outstandings

## PayU Payment Service

Pay HSBC Bank Credit Card bills online from any bank account through PayU Payment Service. Transfer money from your bank account to your HSBC Credit Card online using the PayU facility, a third party website with the URL https://securepayments.payu.in/hsbc-credit-card-payment. Visit www.hsbc. co.in for the terms and conditions of the payment service through PayU.

- e. Billing disputes resolution:
- The Cardholder is deemed to have received each statement of account for the preceding month, either on actual receipt of the statement of account or 10 days after the dispatch of the statement of account by the Bank, whichever is earlier (prescribed period).
3. Upon receipt of each statement of account and in any event not more than 30 days from the period mentioned above, the Cardholder agrees to immediately notify the Bank in writing of any errors, omissions, irregularities, including any fraudulent or unauthorised transactions or any other objections the cardholder has to that statement of account. If the Cardholder fails to notify the Bank within 30 days, the statement of account and all entries therein, will be conclusive evidence of the correctness of the contents and binding upon the Cardholder and/or any person claiming under or through such Cardholder without the requirement for any further proof and the Bank will be released from all liability for any transaction (including all charges, damages and losses of any kind whatsoever, taxes, levies, fines, fees or penalties suffered and/or incurred) occurring up to the date of the most recent statement of account except, for transactions the Cardholder   gave notice of in accordance with this section
- For reporting billing discrepancies, Cardholders can either call  the customer service centre (numbers are provided on the reverse of the monthly statement or at www.hsbc.co.in) or write to HSBC Credit

Card Division, Dispute Desk, P . O. Box 5080, Chennai - 600 028

- If at any stage, you feel that our service levels are not up to your expectations, you may write to Manager, Customer Care Centre, The Hongkong and Shanghai Banking Corporation Limited, Rajalakshmi,

No. 5 and 7, Cathedral Road, Chennai - 600 086

- Or you may contact our Customer Service Executive by visiting any of our branches or you may contact our PhoneBanking Service Executives
- All grievance escalations should be marked to the Regional Nodal Officers/Chief Nodal Officer, the contact details of whom can be accessed on the Grievance Redressal Page updated on our website www.hsbc.co.in
- Grievance Redressel Officer Handling Credit Card Complaints Mr. Sudeep Behari
- The Hongkong and Shanghai Banking Corporation Limited NESCO - IT Park Bldg. 3, 9 th  Floor, Nesco Complex, Western Express Highway, Goregaon (E), Mumbai - 63 Contact number: 040-61268015/080-71898015 (Monday to Friday between 9:30 a.m. and 6:00 p.m.) E-mail ID: complaints.india@hsbc.co.in
- Time-period for reversal of unsuccessful/failed transactions on Credit Card is 15 Days on POS/online/contactless transaction and 5 days for failed ATM transaction on Credit card. The compensation payable for failure to meet the specified timeline in ` 100 per day of delay

## 4.  Default

- In the event of default (if the minimum amount due is not paid by the payment due date or breach of any clause of the cardholder agreement), the cardholder will be sent reminders from time to time

for payment of any outstanding on credit card account, by post, fax, telephone, e-mail, SMS messaging and/or through third parties appointed for collection purposes to remind, follow-up and collect dues. Any third party so appointed, shall adhere to the Indian Banks Association (IBA) code of conduct on debt collection

The Bank will send SMS at T-7 to T+4 days, in this regard T being payment date. The Bank will provide seven days' notice period to such Cardholder about the intention to report him/her as defaulter to the Credit Information Company.

- Recovery of dues in case of death of Cardholder:
- i. The whole of the outstanding balance (including unbilled transactions) will become immediately due and payable to HSBC.
- ii. HSBC will become entitled to recover the total outstanding from the estate of the Cardholder.
- As per Reserve Bank of India guidelines, we provide credit information relating to our credit Cardholders to Credit Information Companies (CICs) payable in full to HSBC on suspension/ termination of the agreement for whatever reasons or on the insolvency or death of the credit Cardholder. HSBC will become entitled to recover the outstanding dues together with all expenses, legal fees, finance charges and interest from the estate of the credit Cardholder on his death, without prejudice to its rights to continue to charge the finance charges and other charges at prevailing rates till the dues are settled on a monthly basis. The information provided reflects the status as on the previous month-end and includes information regarding, whether the credit card account is regular or delinquent. In the event a credit card account is delinquent as on the date of such reporting and the account is subsequently regularised, the status of the account will only be updated prospectively, at the time of the next monthly reporting.

As per Credit Information Companies (CICs), all changes in

customer status are updated within a maximum of 30 days. To avoid any adverse credit history with Credit Information Companies (CICs), credit Cardholders should ensure that they make timely payment of the amount due on the card account

## Standard Illustration SMA/NPA classification:

| Loans in the nature of revolving facilities like cash credit/ overdraft   | Loans in the nature of revolving facilities like cash credit/ overdraft                                                                                       |
|---------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| SMA Sub-categories                                                        | Basis for classification - Outstanding Balance remains countinuously in excess of the sanctioned limit or drawing power, whichever is lower, for a period of: |
| SMA-1                                                                     | More than 30 days and up to 60 days                                                                                                                           |
| SMA-2                                                                     | More than 60 days and up to 90 days                                                                                                                           |

Example: If due date of a Credit card account is 31 March 2021, and full dues are not received before the lending institution runs the dayend process for this date, the date of overdue shall be 31 March 2021. If it continues to remain overdue, then this account shall get tagged as SMA-1 upon running day-end process on 30 April 2021 i.e. upon completion of 30 days of being continuously overdue. Accordingly, the date of SMA-1 classification for that account shall be 30 April 2021.

Similarly, if the account continues to remain overdue, it shall get tagged as SMA-2 upon running day-end process on 30 May 2021 and if continues to remain overdue further, it shall get classified as NPA upon running day-end process on 29 June 2021.

## 5.  Termination

- You may terminate this agreement at any time by written notice to HSBC accompanied by the return of the credit card and any additional credit cards cut into several pieces and full clearance of all

the outstandings. Where this agreement relates to the use of an additional credit card, the usage of the additional card may be discontinued by written notice to HSBC by you. Please destroy the additional credit card by cutting it into several pieces through the magnetic stripe

-     HSBC may at any time, by providing a notice of 30 days, terminate and close the credit card and the credit card account of the credit Cardholder without assigning any reason for the same
- HSBC may at its discretion recall the outstanding amount on your credit card(s)/add-on card(s) without assigning any reason thereof. In the event of HSBC recalling the entire outstanding amount, HSBC shall give you reasonable notice for paying the entire outstanding amount
- Notwithstanding anything to the contrary stated elsewhere in these terms and conditions, HSBC may at its discretion, cancel the limit granted on your credit card account or credit card/add-on card(s) without assigning any reason therefor. In the event HSBC cancels the limit granted on your credit card account or credit card/add-on card(s) in terms of this clause, HSBC shall intimate you on such cancellation
- The whole of the outstanding balance on the credit card account, together with the amount of any outstanding credit card transactions effected but not yet charged to the credit card account, will become immediately due
- Any intimation given by HSBC hereunder will be deemed to have been received by you within seven days of posting to your address last notified in writing to HSBC
- Closure of the credit card may entail withdrawal of all facilities provided through use of the credit card and/or the credit card number
- Any request for closure of a credit card shall be honoured within

seven working days by the credit card-issuer, subject to payment of all dues by the cardholder. Subsequent to the closure of credit card, the cardholder shall be immediately notified about the closure through email, SMS, etc.

Failure on the part of the card-issuers to complete the process of closure within seven working days shall result in a penalty of ` 500 per day of delay payable to the customer, till the closure of the account provided there is no outstanding in the account

- Procedure for surrender/closure of card by Cardholder: You can exercise any of the following options to initiate closure of your HSBC Credit Card:
- -Login to HSBC Internet Banking with your user ID and password and submit your request through secure message
- -You can also call HSBC PhoneBanking and register a card closure request
- -Alternatively, can submit a written request at any HSBC branch
- -Please remember to cut your card into pieces across the Chip and magnetic stripe, post-submission of your closure request. For more details please visit FAQs for Credit Cards | Help and Support - HSBC IN
- 5.10 In case of no activity/transaction on the credit card and/or if the credit card account has remained inoperational for a period of &gt; 12 months or any such period as deemed fit by HSBC, HSBC may exercise its right to close the concerned inactive card(s), linked additional card(s) issued to family members and the dormant/inoperational credit card account by providing a 30 days' notice.

## 6.  Loss/Theft/Misuse of the Card

- If the credit card is lost/stolen, the Cardholder should report it to HSBC immediately in writing or by calling HSBC PhoneBanking Officers. The Bank is merely acting as a facilitator in taking up the dispute through Visa to the concerning merchant. The Bank is thus not liable for the outcome of the investigation
- The Cardholder will not be held liable for any transaction made on the credit card after reporting the loss/theft/misuse to HSBC
- Although loss or theft may be reported as mentioned in (a) above, the cardholder must confirm to HSBC in writing. A copy of the acknowledged FIR must accompany the written confirmation
- Should the Cardholder subsequently recover the card, the recovered credit card must not be used. Please destroy the card by cutting it into several pieces through the magnetic stripe
- In the event that you lose your credit card, please:
- -Report the loss to HSBC PhoneBanking or to the Visa Global Emergency Assistance Helplines immediately
- -Request replacement at HSBC PhoneBanking/Branch/Internet Banking
- -File a police report for the lost/stolen HSBC Credit Card
- -Please confirm the loss in writing to, The Manager, Credit Cards, Post Box Number 5080, Chennai - 600 028

If you recover your HSBC Credit Card after you have reported its loss, please do not attempt to use it.

Instead, please destroy the HSBC Credit Card by cutting it into several pieces and report the same to HSBC. For more details please visit FAQs for Credit Cards | Help and Support - HSBC IN

## 7.  Disclosures

- The Cardholder acknowledges the right of HSBC to provide details of his/ her account including those of any add-on Cardholder(s), to third party agencies for the purpose of availing of support services of any nature by the Bank, without any specific consent or authorisation from him/her or any add-on Cardholders
- The Cardholder further acknowledges that HSBC is authorised to share Cardholder(s), to disclose information to such credit bureaus/credit reference agencies. Such entities may further make available processed information or data or products thereof to banks/financial institutions and other credit grantors
- HSBC may also provide information relating to credit history/repayment record of the cardholder to a credit information company (specifically authorised by the RBI), in terms of the Credit Information Companies (Regulation) Act, 2005

- Your HSBC Credit Card transactions outside India must be made strictly in accordance with Exchange Control Regulations of the Reserve Bank of India. Kindly note that a Cardholder resident in India is notified that collecting and effecting/remitting payments directly/indirectly outside India in any form towards overseas foreign exchange trading through electronic/internet trading portals is prohibited and a cardholder making such transactions would make himself/herself/themselves liable to be proceeded against with for contravention of the Foreign Exchange Management Act (FEMA), 1999 besides being liable for violation of regulations relating to Know Your Customer (KYC) norms/Anti Money Laundering (AML) standards. Any violation of the Exchange Control Regulations arising out of utilisation of this HSBC Credit Card is the responsibility of the individual HSBC Credit Cardholder

If the Bank comes across any prohibited transaction undertaken by the cardholder vide credit card or online banking, the Bank will immediately close the card and the matter will be reported to the Reserve Bank of India. Cardholder (primary/additional) and he/she would be liable for action under the provisions of the Foreign Exchange Management Act (FEMA), 1999 and any other regulations in force from time to time. Please note that the onus of ensuring compliance with the regulations is with the holder of the international credit card

- The Cardholder will not hold HSBC responsible or liable for, any actions, claims, demands, losses, damages, costs, charges and expenses that a Cardholder may suffer, sustain or incur by way of this scheme
- All and any disputes arising from the Instant EMI facility shall be subject to the exclusive jurisdiction of the courts of Mumbai
- The terms of this offer shall be in addition to and not in derogation of the terms contained in the terms and conditions for card usage. This offer is by way of a special facility for select Cardholders and nothing contained herein shall prejudice or affect the terms and conditions of the terms and conditions for card usage. The words and expressions used herein shall have the same meaning as in the terms and conditions for card usage

## Banking Codes and Standards Board of India

## 1. Introduction

This is a Code of Customer Rights, which sets minimum standards of banking practices we will follow as a member of BCSBI while dealing with individual customers. It provides protection to customers and explains how a member bank is required to deal with customers in its day-to-day operations.

The Code does not replace or supersede regulatory or supervisory instructions of the Reserve Bank of India (RBI) and we will comply with such instructions/ directions issued by RBI from time to time.

The Code may have set higher standards than those prescribed in the regulatory instructions and such higher standards will prevail as the Code represents the best practices voluntarily agreed to by us as our commitment to you.

We will endeavor to adopt higher standards of banking practices to extend better customer service and achieve higher levels of customer satisfaction. In the Code, 'you' denotes the customer and 'we'/'us', the Bank, the customer deals with. Branch includes Banking Outlet/Part-time Banking Outlet.

## 1.1  Objectives of the code

The Code has been developed to:

- a. promote good and fair banking practices by setting minimum standards in our dealings with you;
- b. increase transparency so that you can have a better understanding of what you can reasonably expect from us;
- c. encourage market forces, through competition, to achieve higher operating standards;
- d. promote a fair and cordial relationship between you and your bank;
- e. foster confidence in the banking system;
- f. promote safe and fair customer dealing in case of banking in a digitised environment;
- g. increase awareness of customers and to enhance customer protection. The standards of the Code are covered by the Key Commitments in Chapter 2.

## 1.2  Application of the code

This Code applies to all the products and services listed below, whether they are provided by our branch or agents acting on our behalf, whether across the counter, over the phone, by post, through interactive electronic devices, on the internet or by any other method. However, all products discussed here may or may not be offered by us.

- a. Current accounts , savings accounts, term deposits, recurring deposits, PPF accounts and all other deposit accounts ;
- b. Payment services such as pension, payment orders, remittances by way of demand drafts, wire transfers and all electronic transactions e.g. RTGS, NEFT, IMPS, UPI;
- c. Banking services related to Government transactions;
- d. Demat accounts, Equity, Government bonds;
- e. Indian currency notes/coins exchange facility;
- f. Collection of cheques, safe custody services, safe deposit locker facility;
- g. Loans, overdrafts and guarantees ;
- h. Foreign exchange services including money changing;
- i. Third party insurance and investment products marketed through our branch and/or our authorised representatives or agents;
- j. Card products including credit cards, debits cards, ATM cards, smart cards and POS services (including credit cards offered by our subsidiaries/companies promoted by us);
- k. Digital Products such as e-wallet, Mobile Banking, internet banking, UPI, BHIM, Aadhaar Pay .

The meanings of key words appearing in bold black have been given in the Glossary.

## 2. Key Commitments

- 2.1  Our key commitments to you:
- 2.1.1 Right to Fair Treatment
- Act fairly and reasonably in all our dealings with you by:

- a. Providing minimum banking facilities of receipt and payment of cash/cheques, remittances, exchange of soiled notes, etc. at the bank's counter and also providing cashless transactions through   alternate delivery channels.
- b. Meeting the commitments and standards set in this Code, for the products and services we offer, and in the procedures and practices we follow.
- c. Making sure our products and services meet relevant laws and regulations in letter and spirit and are appropriate to your needs and in line with the banking scenario, including digital banking.
- d. Ensuring that our dealings with you rest on ethical principles of integrity and transparency.
- e. Offering digital banking and payment systems in a secure, convenient and robust technological environment.
- f. Not discriminating against you on the basis of age, race, gender, marital status, religion, disability or financial status when offering and delivering our products and services.
- g. Promoting good and fair banking practices by setting minimum standards in all dealings with you.
- h. Promoting a fair and equitable relationship with you.
- i. Training our staff attending to you adequately and appropriately and ensuring that our staff attends to you promptly and courteously and to deal quickly and sympathetically with things that may go wrong by correcting mistakes and handling your complaints expeditiously.

## 2.1.2 Right to Transparency, Fair and Honest Dealing

- We will help you to understand how our financial products and

services work by:

- a. Giving you timely and adequate information about them and the necessary safeguards in any one or more of the following languages
2. -Hindi, English or the appropriate local language.
- b. Ensuring that our advertising and promotional literature is clear
4. and not misleading. We will make every effort to ensure that the contracts or agreements we frame are transparent, easily understood by and well communicated to you. The product's price, the associated risks, the terms and conditions that govern use over the product's life cycle and mutual responsibilities will be clearly disclosed. We will ensure that you are not subjected to unfair business or marketing practices, coercive contractual terms, negative confirmations or misleading representations. For achieving this, we will be following the practices and procedures given in Chapter 3 on Information Transparency and Chapter 4 on Advertising, Marketing and Sales.
- c. Ensuring that you are given complete information about our products and services, minimum balance requirements, the interest rates and service charges, besides the terms and conditions applicable to them in a transparent manner through the following methods as per your preference.
- i. By sending SMS or e-mails
- ii. Through electronic or print media
- iii.   Display on our website
- iv. Display on branch notice board [Display on website and branch notice board will be in addition to the

other modes of information dissemination mentioned above.]

- d. Giving you information on the facilities provided to you and how you can avail of these and whom and how you may contact for addressing your queries.
- e. Displaying in our branch, for your information:
- i. Services we provide.
- ii. Minimum balance requirement, if any, for Savings Bank Accounts and Current Accounts and the charges for non-maintenance thereof.
- iii. Information available in booklet form.
- f. Displaying on our website our policies on
- i. Deposits.

HSBC PhoneBanking numbers

g.

- ii. Cheque collection.
- iii. Grievance Redressal.
- iv. Compensation.
- v. Collection of Dues and Security Repossession.
- vi. Charter of Customer Rights.
- vii.  Customer Protection Policy (including protection from cyber fraud).
- viii.  Limited Liability in respect of unauthorized electronic banking transactions.
- ix. Facilities for senior citizens and differently abled persons.
9. To increase awareness of the Code among customers we will:
- i. provide you with a copy of the Code when you open an account with us and otherwise on request.
- ii. make available this Code at our every branch and on our website.
- iii. ensure that our staff are trained to provide relevant information about the Code and to effectively put the Code into practice.
- iv. hold customer meetings on provisions of the Code periodically.

## 2.1.3 Right to Suitability

We will offer you products appropriate to your needs and based on an assessment of your financial circumstances and understanding as detailed in Chapter 4 on Advertising, Marketing and Sales and Clause 8.18 on Third Party Products.

## 2.1.4 Right to Privacy

We will treat all your personal information as private and confidential subject to matters mentioned in Chapter 5 on Privacy and Confidentiality.

## 2.1.5 Right to Grievance Redressal and Compensation

We will deal quickly and sympathetically with things that go wrong by:

- a. Correcting our mistakes promptly and cancelling any bank charges that we apply by mistake and compensate you for any financial loss you may have incurred due to our mistake, in terms of our compensation policy.
- b. Handling your complaints promptly.
- c. Telling you how to take your complaint forward if you are still not

satisfied.

- d. Providing suitable alternative avenues to alleviate problems arising out of technological failures.
- e. We will display in our branch for your information:
- i. Name of the official at the branch whom you may approach if you have a grievance.
- ii. Name and address of the Regional/Zonal Manager/Principal Nodal Officer (PNO) whom you can approach if your grievance is not redressed at the branch.
- iii. Name and contact details of the Banking Ombudsman under whose jurisdiction the branch falls.

We will advise you the internal procedures for redressing your complaints including details of the Banking Ombudsman Scheme as explained in Chapter 6 of the Code.

## 3. Information - Transparency

We will display the information on products, services, Most Important Terms and Conditions (MITC) in our premises on a Comprehensive Notice Board (CNB) as prescribed in bilingual/trilingual language as applicable (Annexure 1) and we will update the information on CNB on realtime basis alongwith effective date of change.

You can get information on interest rates, fees and charges through various modes mentioned below:

- a. Notice Board in our branch.
- b. Contacting our branch or helplines.
- c. Our website.
- d. Asking our designated staff/help desk.
- e. Referring to the Tariff Schedule at our branch/on our website.

## 3.1  General information

We will:

- a. give you information on the types of products and services we offer and those that may suit your needs.

Your Voice Matters

- b. prominently display in bilingual/trilingual language at all our branches the documents required for opening Basic Savings Bank Deposit (BSBD) Accounts. We will also display the relaxed requirements for opening 'Small Accounts'.
- c. give you clear information explaining the key features of the services and products you are interested in, including applicable interest rates, fees and charges.
- d. tell you the different channels through which our products and services   may be availed e.g. Branches, Banking Outlets, Business Correspondents, Business Facilitators, ATMs, Micro ATMs, Phone Banking, Mobile Banking, Net banking and tell you how to find out more about them.
- e. tell you the information needed from you to prove your identity and address, for us to comply with legal, regulatory and internal policy requirements.
- f. give you information on your rights and responsibilities especially regarding availing of nomination facility offered on all deposit accounts, articles in safe custody and safe deposit lockers.
- g. provide you Most Important Terms and Conditions (MITC) for your record in respect of Savings Bank (SB)/Current Account (CA) and all other deposit accounts before opening the account.

## 3.2  'Do Not Call' service

We will not transmit to you any unsolicited commercial information regarding our products and services, through telephone calls/SMS if you have registered with the 'Do Not Call Registry' of our bank or with the 'National Do Not Call Registry' directly or through your Service Provider. However, this will not apply to receipt of information regarding your account statements and other important advices and information including SMS alerts relating to transactions in your account as also the products and services you are currently availing.

## 3.3  Interest Rates

We will give you information on:

- a. the interest rates which apply to your deposit and loan accounts.
- b. in case of loans at fixed rate of interest , details of interest reset clause, if any, in the loan agreement and the effective date thereof.
- c. in case of loans at floating rate of interest , the reference rate to which your floating rate will be linked and the premium or discount applied to the reference rate for determining the actual rate of interest on your loan.
- d. whether you have the option for converting your loan from fixed rate to floating rate and vice versa and, if so, one time applicable charges   thereof.
- e. periodicity at which we pay interest on your deposits or charge interest on your loan accounts.
- f. how we apply interest to your deposit and loan accounts and how we calculate interest thereon.

## 3.3.1 Changes in interest rates

We will inform you of changes in interest rates on our loan products and changes in the reference rate periodically by any of the following means at the last updated customer contact details available with us:

- i. Letter
- ii. E-mail
- iii.   SMS
- iv.   Media

We will also display this information on the Notice Board in our branch as also on our website.

## 3.4 Tariff schedule

## 3.4.1 Fees and charges

- a. We will ensure that our fees and service charges for various services are approved by our Board or any competent authority duly authorized by the Board to take decisions in this regard and that they would be reasonable and non-discriminatory for similar class of customers.
- b. We will place our Tariff Schedule on our website and make a copy

available at every branch for your perusal. We will display in our branches a notice about the availability of the Tariff Schedule at the branch.

- c. We will give you details in our Tariff Schedule of any charges applicable to the products and services chosen by you.
- d. We will also provide you information about the penalties leviable in case of non-observance/violation of any of the terms and conditions governing the product/services chosen by you.

## 3.4.2 Changes in fees and charges

If we increase any fee or charge or introduce a new fee or charge, it will be notified through statements of accounts/e-mail/SMS alerts/notice board at our branch one month prior to the revised charges becoming effective. This information will also be made available on our website prominently.

## 3.5  Terms and conditions

- a. We will advise you the relevant terms and conditions for the products/ services you have asked us to provide.
- b. All terms and conditions will be fair and will set out the respective rights, liabilities and obligations clearly and as far as possible in plain and simple language.

## 3.5.1 Changes to terms and conditions

- a. We will tell you of changes in terms and conditions through any one or more of the following channels one month prior to the revised terms and conditions becoming effective:
- i. Letter
- ii. Statement of account
- iii.  SMS
- iv. E-mail

This information will also be made available on the Notice Boards in our branch and our website.

- b. Normally, changes will be made with prospective effect after giving notice of one month.
- c. If we have made any change without notice, we will notify the change within 30 days. If such change is to your disadvantage, you may within
3. 60 days of the notice, close your account or switch to any other eligible account without having to pay revised charge or interest.
- d. We will immediately update, on our website, any changes in the terms and conditions. We will give you, on request, a copy of the new terms and conditions.

## 4. Advertising, Marketing and Sales

- a. We will make sure that all our advertising and promotional material is clear and not misleading.
- b. In any advertisement and promotional literature that draws attention to a banking service or product or includes a reference to an interest rate, we will also indicate whether other fees and charges will apply and full details of the relevant terms and conditions will be made available on request.
- c. If we avail of the services of third parties for providing support services, we will ensure that they handle your personal information (if available to such third parties) with the same degree of confidentiality and security as we would.
- d. We may, from time to time, communicate to you various features of our products availed by you by e-mail, SMS or over the telephone. Information about our other products or promotional offers in respect of our products/services will be conveyed to you only if you have not registered for the 'Do Not Call' facility. As regards the information shared through e-mail, you have the option to unsubscribe from such future communications.
- e. We have prescribed a code of conduct for our Direct Selling Agencies (DSAs) whose services we may avail to market our products/services which, amongst other matters, requires them to identify themselves as only selling agents of our bank when they approach you for selling our products personally or through phone. We will ensure that any third party or agent acting on our behalf or selling our product complies with the code of conduct.
- f. In the event of receipt of any complaint from you that our representative/

courier or DSA has engaged in any improper conduct or acted in violation of this Code, we shall take appropriate steps to investigate and to handle the complaint and to make good the loss as per our compensation policy.

- g. We will ensure that any third party or agent acting on our behalf or selling our product discloses the fee or commission they are paid upon completion of the sale.
- h. We will ensure that our advertisements will also include all relevant messages which require to be conveyed for enhancing awareness against unscrupulous/fictitious offers.

## 5. Privacy and Confidentiality

We will treat all your personal information as private and confidential (even when you are no longer our customer), and shall be guided by the following principles and policies:

- a. We will not reveal information or data relating to your accounts, whether provided by you or otherwise, to anyone, including other companies/entities in our group, other than in the following exceptional cases:
- i. Providing information to the Credit Information Companies (CICs) as per Credit Information Companies (Regulation) Act (CICA) about the loans, unsecured loans, credit card, etc.
- ii. Giving the information required by law or by the banking regulator.
- iii. Fulfilling a duty towards the public to reveal the information.
- iv. Our interests require us to give the information (for example, to prevent fraud) but we will not use this as a reason for giving information about you or your accounts (including your name and address) to anyone else, including other companies in our group, for marketing purposes.
- v. You authorise us to reveal the information.
- vi.   When required to give a banker's reference about you, we will need, unless provided earlier, your written permission before we give it.
- b. We will not use your personal information for marketing purposes by anyone including ourselves unless you specifically authorize us to do so.
- c. If we collect any information from you other than KYC requirement, we will collect it separately and not as a part of account opening form. In case we collect any additional information, we will explain the purpose for which we are collecting this information and take your specific consent for the same.

## 5.1  Credit Information Companies

When you apply for a credit facility:

- a.    We will explain to you the role of Credit Information Companies (CICs) as also the checks we may make with them and the effect that the information they provide can have on your ability to get credit.
- b. We will, on request and on payment of the prescribed fee, furnish you a copy of the credit information report obtained by us from the CICs.
- c. We will provide correct information about credit availed by you from us to the CICs at periodic intervals.
- d. Information reported to CICs will also include personal debts you owe us when:
- i. You have fallen behind with your payments.
- ii. The amount owed is in dispute.
- e. We will update the credit status immediately but not later than 30 days on repayment of overdues. We will report closure of loan to CICs within 30 days of the event. If your loan account has been in default, but thereafter regularised, we will update this information with the CICs in the next report. If there is partial/delayed/any settlement of credit dues, it will impact your credit score.
- f. In case of dispute about the information provided to the CICs, we will resolve the matter by satisfactorily explaining the reasons for reporting to CICs.

- g. We will, on request, inform you of the details of the CIC(s) to whom we submit information regarding the credit/loan facility you have availed from us.
- h. We will identify and declare the names of wilful defaulters of ` 25 lakh* and above and names of such wilful defaulters will be furnished to Credit Information Companies, strictly as per the guidelines of RBI.
- i. We will furnish the names of defaulters of ` 1.00 crore* and above whose accounts have been classified as doubtful or loss assets to Credit Information Companies strictly as per the guidelines of RBI. *( or as amended from time to time.)

## 6. Complaints, Grievances and Feedback

- 6.1 Internal procedures
- a. If you want to make a complaint, we will tell you:
- i. How to do so.
- ii. Where a complaint can be made.
- iii.   To whom a complaint can be made.
- iv. When to expect a reply.
- v. Whom to approach for redressal.
- vi.   What to do if you are not satisfied about the outcome.
- b. Our staff will help you with any questions you have.
- c. We will tell you where to find details of our procedure for handling complaints fairly and quickly.
- d. We will display the name of the official at the branch whom you may approach if you have a grievance. If your complaint is unresolved at the branch level, we will ensure to escalate it to the topmost level of grievance redressal authority within the Bank and give you a final response within 30 days. You may approach our Regional/Zonal Manager/Principal Nodal Officer (PNO) at the address displayed at the branch, if you so desire.
- e. If your written complaint is hand delivered, we shall immediately provide an acknowledgement and a 'complaint reference number' will be separately sent by SMS on the registered mobile number. If your
- complaint is relayed over phone at our designated telephone helpdesk or customer service number, we shall provide you a complaint reference number and keep you informed of the progress within a reasonable period of time.
- f. After examining the matter, we will send you our final response or explain why we need more time to respond and shall endeavour to do so within 30 days of receipt of your complaint and will tell you how to take your complaint further, if you are still not satisfied.
- g. Within 30 days of lodging a complaint with us, if you do not get response/satisfactory response from us and you wish to pursue other avenues for redressal of grievances, you may approach Banking Ombudsman appointed by RBI under the Banking Ombudsman Scheme. Our staff would explain the procedure in this regard.

## 6.2  Banking Ombudsman Scheme

- We will display the Banking Ombudsman Scheme on our website. A copy will be made available on request at a nominal charge. We will display at our branch the name and contact details of the Banking Ombudsman under whose jurisdiction the branch falls. In case the Banking Ombudsman passes an award and we do not have any ground to appeal against the award, we will comply with the Award within 30 days from the date of receipt of the acceptance in writing of the Award by the complainant.

## 6.3  Customers' Meetings

- We shall endeavour to organize meetings of customers at periodic intervals as a regular channel for exchange of ideas and suggestions.
- 6.4  Branch Level Customer Service Committee Meetings We will display in our branch, the date of our monthly branch Level Customer Service Committee meeting, which you may attend, if you so desire.

## 7. Collection of Dues

- a. Whenever we give loans, we will explain to you the repayment schedule viz. amount, tenure and periodicity of repayment. However, if you do not adhere to the repayment schedule, a defined process in accordance with the laws of the land will be followed for recovery of dues.

- b. We will have a Board approved policy for Collection of Dues and Security Repossession as also appointment of Recovery Agents.
- c. All relevant laws, regulations, guidelines and conditions of approval, licensing or registration will be taken into account while appointing Recovery Agents.
- d. We will ensure that our Recovery Agents are properly trained to handle their responsibilities with care and sensitivity. We will also ensure that they do not exceed their brief.
- e. Our collection policy is built on courtesy, fair treatment and persuasion. We believe in fostering customer confidence and longterm relationship.
- f. We will provide you with all the information regarding your dues and will endeavour to give sufficient notice for payment of dues.
- g. We will have a system of checks before passing on a default case to recovery agencies so that you are not inconvenienced on account of lapses on our part.
- h. We will write to you when we initiate recovery proceedings against you   and will inform you of the name of the recovery agency/agent, to whom your case has been assigned as also their address and telephone numbers.
- i. We have provided the details of recovery agency firms / companies engaged by us on our website: Regulatory Disclosures - HSBC IN under List of Collection Agencies.
- j. We will also make available, on request, details of the recovery agency firms/companies relevant to you at our branch.
- k. Our staff or any person authorized to represent us in collection of dues and/or security repossession will identify himself/herself and produce the authority letter issued by us and upon request show you his/her identity card issued by the bank or under authority of the bank.
- l. All the members of our staff or any person authorised to represent us in collection and/or security repossession would follow the guidelines set out below:
- i. You would be contacted ordinarily at the place of your choice and in the absence of any specified place at the place of your residence and if unavailable at your residence, at the place of business/occupation.
- ii. Their identity and authority to represent us would be made known to you.
- iii. Your privacy would be respected.
- iv. Interaction with you would be in a civil manner.
- v. Normally our representatives will contact you between 0700 hrs and 1900 hrs, unless the special circumstances of your business or occupation require otherwise.
- vi.   Your requests to avoid calls at a particular time or at a particular place would be honoured as far as possible.
- vii.   Time and number of calls and contents of conversation would be documented.
- viii.  All assistance would be given to resolve disputes or differences regarding dues in a mutually acceptable and in an orderly manner.
- ix.   During visits to your place for dues collection, decency and decorum would be maintained. Our officials/agents will not resort to intimidation or harassment of any kind, either verbal or physical against any person, including acts intended to humiliate publicly or intrude the privacy of your family members, referees and friends, making threatening and anonymous calls or making false and misleading representations.
21. However, it is your responsibility to keep updating your contact details. In case the bank is unable to contact you at the details provided, the bank will access information available from public sources and approach your friends/relatives to trace you.
- x. Inappropriate occasions such as bereavement in the family or other important family functions like marriages would be avoided for making calls/visits to collect dues.

- xi. We will investigate any complaint from you about unfair practices of our recovery agents.
2. 7.1  Collection of Dues and Security Repossession Policy We will follow collection of dues and security repossession policy in consonance with the law. The policy will be displayed on our website and a copy of the same will be made available at our branch for perusal.

## 8. Deposit accounts

- a. You may open different types of accounts with us such as, savings accounts, term deposits, current accounts, etc. You may open such accounts in the following styles:
- i. Single
- ii. Joint
- iii. Joint (Either or Survivor)
- iv. Joint (Former or Survivor)
- v. Joint (Latter or Survivor); or
- vi. In any other style.
- b. We will make available 'Basic Savings Bank Deposit Account' (BSBD Account) to you without the requirement of any minimum balance. We will offer/provide minimum common facilities, including passbooks* without any charges. The relevant details will be made known to you in a transparent manner at the time of opening of the account. *For Payment Banks and Small Finance Banks, the norms relating to passbook/statement of account shall be as per Operating Guidelines applicable. Payment Banks and Small Finance Banks are allowed to provide statement of account in paper form/electronic form instead of a passbook.
- c. The above accounts may be opened by you with nomination facility, wherever permissible. We will include, in the account opening form, the option for nomination as also the option for indicating the name of the nominee in passbooks/account statements/Fixed Deposit Receipts (FDRs).
10. We will explain the implications of the foregoing accounts as also the nomination facilities at the time of opening of the account.
- d. We will acknowledge the receipt of your nomination details and record the fact of nomination on the passbook/account statement/FDRs. At your written request, we will also indicate the name of the nominee thereon.
- e. We will provide information about deposit insurance cover in the passbooks.
- f. We will provide sufficient details of all transactions in the passbooks.
- g. We will also inform you about liquid deposit facility, sweep account and similar types of products offered by us and their implications and procedures involved, at the time of opening of account.
15. 8.1.1 Account opening and operation of deposit accounts Before opening any deposit account, we will:
- a. carry out due diligence as required under 'Know Your Customer' (KYC) guidelines.
- b. ask you to submit or provide necessary documents or proofs to do so.
- c. obtain only such information to meet with our KYC, Prevention of Money Laundering or any other statutory requirements. In case any additional information is asked for, it will be sought separately and we will explain the reason for obtaining such additional information. Providing such information will be voluntary, unless required by law. The information will be kept confidential, unless required by law enforcing agency/banking regulator.
- d. provide the account opening forms which will contain details of essential information required to be furnished and documents to be produced for verification and/or for record for meeting the KYC requirements.
- e. require you to submit documents in respect of KYC at periodic intervals to enable us to update our records as required.
- f. explain the procedural formalities and provide necessary clarifications sought by you while opening a deposit account.

- g. give you the Most Important Terms and Conditions (MITC) governing the deposit facility you have sought to avail.
- h. at the time of opening of the account, make available to you as part of MITC, the details of the deposit insurance scheme, offered by the Deposit Insurance and Credit Guarantee Corporation of India (DICGC) and the terms and conditions thereof.

## 8.1.2 Changing your account

- a. If you are not happy about your choice of current/savings account, you may within 14 days of opening the account, approach us to switch to any of our other account/products offered by us. Alternatively, you may ask for closure of the account along with any interest it may have earned. No penal charges will be applied in such cases.
- b. If you decide to close your current/savings account we will do so within three working days of receiving your instructions, subject to your completing all formalities and submitting all required documents.
- c. If you want to transfer your active and operative account to another branch of our bank, we will do so. On receiving your request, we will transfer the account to the transferee branch within 3 (three) working days without insisting on fresh proof of address and on the basis of a self-declaration from you giving your current address. You   will have to submit documentary proof of this address within a period of six months.

We will intimate you as soon as the account is operationalised. The transferee branch will be provided with information on your existing standing instructions/direct debits, if any.

## 8.1.3 Savings/Current accounts

## When you open a Deposit Account, we will:

- a. inform you about number of transactions, cash/ATM withdrawals, etc. that can be done free of charge in a given period.
- b. inform you about the kind of charges, if any, in case of exceeding
3. such limits. Details of the charges will be included in our Tariff Schedule.
- c. inform you of the rate at which interest is paid on your savings deposits, how it is calculated and the periodicity of its payment.

## 8.1.3.1 Minimum balance

- a. The minimum balance to be maintained in the Savings Bank account   will be displayed in our branch.
- b. We will inform you in respect of deposit products like Savings Bank Account and Current Account or any other type of Deposit Account:
- i. the minimum balance to be maintained as part of terms and conditions governing operation of such accounts.
- ii. the charges which will be levied in case of failure to maintain the minimum balance in the account by you. Details of the charges will be included in the Tariff Schedule.
- iii. 30 days in advance, of any change in minimum balance to be maintained. During this Notice period, we will not levy any charge for non-maintenance of such higher minimum balance prescribed. Further, there will be an option to switch to BSBD Account for which we will notify you before levying any charges.
- iv. we will ensure that the balance in the savings account does not turn negative solely on account of levy of charges for non maintenance of minimum balance. In case the account is to be closed or revived, we will not seek payment of unpaid charges   levied due to non-maintenance of minimum balance.
- v. the charges for non-maintenance of minimum balance to be maintained by you will be proportionate to the extent of shortfall observed.

## 8.1.3.2 Charges

Specific charges for issue of cheque books, additional/duplicate statement of accounts, duplicate passbook, copies of paid cheques, folio charges, debit card, ATM card, verification of signature, return of

cheque, change in mandate or style of account, closure of Savings Bank/ Current accounts, withdrawal/deposit of cash at home/non-home branches, cash/noncash transactions at Bank's own/other Bank's ATMs/Micro ATMs, etc., will be included in our Tariff Schedule. Concessions or relief given will not be withdrawn during the original validity period of the concession/relief.

## 8.1.3.3 Passbook/statements*

- a. To help you manage your account and check entries in it, we will provide you with a monthly statement/e-mail statement (subject to your acceptance) of account unless you have opted for a passbook. This can be available through digital channels also.
- b. You can ask us to provide you with account statements more often than is normally available for your type of account, at a charge. This charge will be indicated in our Tariff Schedule.
- c. We will indicate our MICR Code and IFS Code in cheque books, passbooks and statements of accounts.
- d. We will make available the Customer Care number of the bank/contact number of the branch in passbooks and statements of accounts.
- e. We will provide a detailed 'Statement of Loan account' free of charge once in a financial year. The statement shall be made available by providing the facility of online access or by e-mail and in absence of these channels, by post. In case you need duplicate or more copies of the statement of loan account, charges will be payable, which will be disclosed in the tariff schedule on our website and in the loan related documents.
6. *For Payment Banks and Small Finance Banks, the norms relating to passbook/statement of account shall be as per Operating Guidelines applicable. Payment Banks and Small Finance Banks are allowed to provide statement of account in paper form/electronic form instead of a passbook.

## 8.1.3.4 Upgradation of deposit accounts and addition of value added services.

In case your account meets the terms for upgradation or value added services, we will do it only after obtaining your consent in writing or through any other mode or where your consent is obtained through authenticated electronic means after necessary validation.

## 8.1.3.5 Downgrading of deposit accounts

We will intimate you once the account gets downgraded from higher product version to a lower product version. We will downgrade the account after giving thirty days notice.

## 8.1.4 Accounts of minors

- a. We will tell you, on request, how a Deposit Account can be opened in the name of a minor and how it can be operated.
- b. We will intimate the date on which the minor becomes major.

## 8.1.5 Inoperative/Dormant accounts

We will:

- a. inform you when you open your account, the circumstances under which your account will be classified as inoperative/dormant . You will also be informed at least three months before your account is classified as inoperative/dormant and the consequences thereof at your last recorded address and/or e-mail.
- b. also endeavour to send an SMS/e-mail advising that your account is being classified as inoperative/dormant.
- c. notify the joint holder(s) also before an account is classified as inoperative/dormant.
- d. inform you of the procedure to be followed if you want to activate the account.
- e. not levy any charge merely because an account is inoperative/dormant.
- f. not charge you for activation of the inoperative account.
- g. intimate you upon activation of Dormant account at your request through various channels including SMS/e-mail or letter.

## 8.1.6 Closing your account

Under normal circumstances, we will not close your account without giving you at least 30 days' notice indicating the reasons for such closure.

HSBC PhoneBanking numbers

In such cases, you will be required to make alternate arrangements for cheques already issued by you and desist from issuing any fresh cheques on such account.

## 8.2  Clearing cycle/collection services

- a. We may provide a drop box facility to enable you to deposit cheques to be sent for collection. Necessary precaution will be taken to   ensure that cheques deposited in the drop box are properly and promptly accounted for. However, you may, if you so desire, hand over cheques at the counter against acknowledgement instead of depositing them in the drop box.
- b. We will inform you about the clearing cycle for local and outstation instruments, including details such as cut-off time for lodging of instruments for same day clearing, when you can withdraw money after lodging instruments and when you will be entitled to earn interest on delayed collection as per our Cheque Collection Policy .
- c. We will pay you compensation, as per our Cheque Collection/ Compensation Policy for any delay in collection of instruments, without waiting for a demand from you.
- d. We will inform you immediately by SMS/e-mail when a cheque deposited by you for collection is returned unpaid.
- e. We will return a cheque unpaid/dishonoured along with a duly signed return memo indicating the date of return as also the reason for return/refusal of payment within 24 hours.
- f. If immediate credit for outstation cheques is offered, we will provide relevant information including the applicable terms and conditions, such as the limit up to which instruments tendered by you can be credited in satisfactorily operated accounts.
- g. We will proceed as per our Cheque Collection Policy and provide all assistance for you to obtain a duplicate cheque/instrument in case a cheque/instrument tendered by you is lost in transit and compensate   you as per our Cheque Collection/Compensation Policy.
- h. We will give the above information when you open your account

and whenever you ask for it. If there is any change in our Cheque Collection Policy, the revised Policy will be displayed on our website and will be made available at all our branches.

## 8.3 Cash transactions

- a. We will accept and dispense cash at any of our branches under core banking, subject to any restrictions on type of transaction or charges, if any, applicable to such transactions.
- b. We will exchange soiled/mutilated notes and/or small coins and issue good quality, clean bank notes/coins at all our branches up to a prescribed limit per day. We will extend this facility, within prescribed limits to walk-in customers too.
- c. For transactions above a specified amount, we will require you to furnish your PAN .

## 8.4 Direct debits and standing instruction

## We will:

- a. at the time of opening the account tell you how direct debits/ standing instructions work and how you may record/cancel them and the charges  connected with them. Charges will be levied as per our Tariff Schedule.
- b. act upon mandates given by you for direct debits [ Under National Electronic Clearing Service (NECS)]/ National Automated Clearing House (NACH) and other standing instructions. In case of any delay or failure in executing the mandate resulting in financial loss or additional cost, we will compensate you as per the compensation policy of the bank. If the mandate cannot be executed due to insufficient balance in your account, we will levy charges as per our Tariff Schedule.
- c. credit your account along with interest as soon as it is determined that any amount has been unauthorisedly/erroneously debited from your account and compensate you as per our Compensation Policy.

## 8.5 Stop payment facility

<!-- image -->

## We will:

- a. accept stop payment instructions from you in respect of cheques issued by you. Immediately on receipt of your instructions, we will give an acknowledgement and take action provided these cheques have not already been cleared by us.
- b. levy charges, if any, as indicated in our Tariff Schedule.
- c. reimburse and compensate you as per our Compensation Policy in case a cheque is paid subsequent to the receipt of stop payment instructions by us.

## 8.6  Cheques/debit instructions issued by you

## We will:

- a. keep original cheques/debit instructions acted upon from your account or copies or images of the cheques received from the presenting bank under Cheque Truncation System (CTS), for such periods as required by law.
- b. give you the cheque/image of cheque/debit instruction acted upon or a copy thereof as evidence as long as records are vailable with us. If there is a dispute about a cheque paid/debit instructions from your account and in case the request for such cheque, etc. is made within a period of one year from the date of cheque/debit instruction, no charge will be levied. In respect of requests received beyond this period, charges will be levied as per the Tariff Schedule.
- c. inform you how we will deal with unpaid cheques and out-of-date [stale] cheques. The details of charges to be levied will be included in our Tariff Schedule.

## 8.7  Term deposits

- a. When you place a term deposit with us, we will obtain instructions from you in the account opening form for the disposal of your deposit at maturity.
- b. Where there are no instructions for disposal of the deposit at maturity, we will inform you well in advance through letter/e-mail/SMS about its impending date of maturity.
- c. In case we still do not receive any instruction from you, we will renew
4. the deposit, excluding deposits like tax savings deposits, etc., for the same period as the matured deposit at the prevailing rate of interest.
- d. We will inform you the procedure for withdrawal of term deposits before maturity. This information will also be made available in the account opening form/MITC/reverse of the FDR.
- e. We will inform you of the interest rates applicable and charges for premature withdrawal of term deposits.
- f. We will permit premature withdrawals of term deposits in accordance with the mandate 'Former or Survivor/Either or Survivor', provided a specific joint mandate from all the depositors has been given for the purpose. We will provide for such a mandate in the account opening form.
- g. We will inform you, at the time of acceptance of the deposit, the terms and conditions and interest rate applicable in case you renew the deposits on a date after the date of maturity. This information will also be made available in the account opening form/MITC/reverse of the FDR.
- h. We will advise you of provisions of Income Tax Act applicable to the interest income accruing to you on your deposits, our obligations under the Act and provisions available to you for seeking exemption from Tax Deduction at Source.
- i. We will accept Form 15 G or 15 H as applicable from you at the time of application if you are not liable to pay tax on your interest income. You may submit to us such Form as required, at the beginning of the financial year, if you are not liable to pay tax on your interest income. We will acknowledge receipt of such Forms.
- j. We will issue the requisite certificate within the stipulated period if we deduct tax from interest paid/accrued on your deposits.

## 8.7.1 Advances against term deposits

- We will explain the facility of loan/overdraft available against term deposits.
- 8.8  Settlement of claims in respect of deceased accountholders

HSBC PhoneBanking numbers

- a. The operational procedure for settlement of claims of deceased depositors is available in our branch and on our website as a part of our Deposits Policy.
- b. We will provide claim forms for settlement of claims of the accounts of deceased persons, to those who approach us for the forms. We will also place the claim forms on our website.

## 8.8.1 Accounts with survivor/nominee clause

- a. In the case of a deposit account of a deceased depositor, where the depositor had utilized the nomination facility and made a valid nomination or where the account was opened with the survivorship clause ('either or survivor' or 'anyone or survivor' or 'former or survivor' or 'latter or survivor'), payment of the balance in the deposit account to the survivor(s)/nominee of a deceased deposit account holder will be made, provided:
- i. the identity of the survivor(s)/nominee and the fact of the death of the account holder, is established through appropriate documentary evidence.
- ii. there is no order from the competent court restraining the Bank from making the payment from the account of the deceased. In such cases, payment to the survivor(s)/nominee of the deceased depositors will be made without insisting on production of succession certificate, letter of administration or probate, etc. or obtaining any bond of indemnity or surety from the survivor(s)/nominee, irrespective of the amount standing to the credit of the deceased accountholder.
- b. The survivor(s)/nominee would be receiving the payment from the bank as a trustee of the legal heirs of the deceased depositor, i.e., such payment shall not affect the right or claim which any person may have against the survivor(s)/nominee to whom the payment is made.
- c. The payment made to the survivor(s)/nominee, subject to the foregoing conditions, would constitute a full discharge of the Bank's

liability .

- d. In case of term deposits with 'Either or Survivor' or 'Former or Survivor' mandate, premature withdrawal of the deposit, on death of one of the depositors, by the surviving joint depositor will be permitted only if there is a mandate from all the depositors to this effect. The premature withdrawal will be allowed at the rate of interest applicable on the date of deposit for the period the deposit remained with us and without   penalty.
- e. It may be noted that in case of a joint deposit account, nominee's right arises only after the unfortunate event of death of all the depositors.
- f. At the time of registration of nomination, you will have the option to indicate or not to indicate the name of the nominee in the passbook/statement of account/FDR.

## 8.8.2 Accounts without the survivor/nominee clause

- In case the deceased depositor had not made any nomination or for the accounts other than those styled as 'either or survivor' (such as single or jointly operated accounts), we will adopt a simplified procedure for repayment to the legal heir(s) of the depositor, keeping in view the imperative need to avoid inconvenience and undue hardship to the common person. In conformity with our risk management policy, we will fix a minimum threshold limit (which will be made known on demand at our branch) up to which claims in respect of the deceased depositor(s) will be settled without insisting on production of any documents other than a letter of indemnity.

## 8.8.3 Time limit for settlement of claims

We will settle the claims in respect of deceased depositors and release payments to survivor(s)/nominee within a period not exceeding 15 days from the date of receipt of the claim subject to the production of proof of death of the depositor and suitable identification of the claimant(s), to the bank's satisfaction.

## 8.8.4 Premature termination of term deposit accounts

<!-- image -->

HSBC PhoneBanking numbers

In the case of term deposits, we will incorporate a clause in the account opening form itself to the effect that in the event of the death of the depositor, premature termination of term deposits would be allowed.

The conditions subject to which such premature withdrawal would be permitted would also be specified in the account opening form. Such premature withdrawal would not attract any penal charge.

## 8.8.5 Treatment of flows in the name of the deceased depositor

- In order to avoid hardship to the survivor(s)/nominee of a deposit account, we will obtain appropriate agreement/authorisation from the survivor(s)/nominee with regard to the treatment of pipeline flows in the name of the deceased accountholder. In this regard, we will consider adopting either of the following two approaches:
- i. We could be authorized by the survivor(s)/nominee of a deceased account holder to open an account styled as 'Estate of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_, the Deceased' where all the pipeline flows in the name of the deceased accountholder could be allowed to be credited, provided no withdrawals are made.

OR

- ii. We could be authorised by the survivor(s)/nominee to return the pipeline flows to the remitter with the remark 'Accountholder deceased' and to intimate the survivor(s)/nominee accordingly. The survivor(s)/nominee/ legal heir(s) could then approach the remitter to   effect payment through a negotiable instrument or through electronic transfer in the name of the appropriate beneficiary.
- i. We could be authorised by the survivor(s)/nominee of a deceased accountholder to open an account styled as 'Estate of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_, the Deceased' where all the pipeline flows in the name of the deceased accountholder could be allowed to be credited, provided no withdrawals are made.

OR

- ii. We could be authorised by the survivor(s)/nominee to return the pipeline flows to the remitter with the remark 'Accountholder

deceased' and to intimate the survivor(s)/nominee accordingly. The survivor(s)/nominee/legal heir(s) could then approach the remitter to effect payment through a negotiable instrument or through electronic transfer in the name of the appropriate beneficiary.

## 8.8.5.1 Pension Accounts*

- i. We will inform you that Nomination facility is available for Savings Bank Account opened for credit of pension.
- ii. We will inform you that Banking Companies (Nomination) Rules, 1985 are distinct from the Arrears of Pension (Nomination) Rules, 1983.
- iii. We will inform you that nomination exercised by you under Arrears of Pension (Nomination) Rules for receipt of arrears of pension will not be valid for the purpose of deposit accounts held by you with us.

For this a separate nomination is necessary in terms of the Banking Companies (Nomination) Rules, 1985 in case you desire to avail of nomination facility .

- *[ Note: Provisions of 8.8.5 of the Code does not apply in case of deposit account held with us by pensioners]*.

## 8.9 Safe deposit lockers

- a. We will give you the complete details of the rules and the procedures applicable for allotment of the safe deposit lockers and also safe deposit of valuables, in case we offer the service and will explain the differences between the same and also the charges and unique features of these services. We will allot lockers without linking it to placement of fixed deposits. However, to ensure prompt payment of locker rent, we may at the time of allotment, obtain a Fixed Deposit which would cover 3 years' rent and the charges for breaking open the locker in case of an eventuality. We will send reminders for the overdue rent of your safe deposit locker at the last recorded address and/or e-mail. We would have the right to restrict operations of the locker till the rent due is paid as per the locker agreement. We will include this clause in the agreement.
- b. We will advise you that hiring of a safe deposit locker creates

relation of a lessor and lessee and the lessee has the right for free access to safe deposit locker in a safe and secure environment.

## 8.10 Foreign Exchange services

- a. When you buy or sell foreign exchange, we will give you information on the services, details of the exchange rate and other charges which apply to foreign exchange transactions. If this is not possible, we will tell you how these will be worked out.
- b. If you want to transfer money abroad, we will inform you how to do this and will give you:
- i. a description of the services and how to use them.
- ii. details of when the money you have sent abroad should get there and the reasons for delays, if any.
- iii. the exchange rate applied for conversion of the foreign currency (if this is not possible at the time of the transaction, we will let you   know later what the rate was).
- iv. details of any commission or charges, which you will have to pay and a caution that the person receiving the money may also have to pay the correspondent bank's charges.
- c. We will tell you if the information provided by you for making a payment abroad is adequate or not. In case of any discrepancies or incomplete documentation, we will advise you immediately and assist you to rectify/complete the same.
- d. If money is transferred to your bank account from abroad, we will tell you the original amount received and charges, if any, levied. Even if the sender has agreed to pay all charges, we shall still deduct our charges/statutory taxes from the proceeds at the time of crediting the money into your account.
- e. We will guide you about the regulatory requirements or conditions relating to foreign exchange services offered by us as and when requested by you.
- f. In case of delay beyond the day when the amount is due for credit, you will be compensated (i) for any loss on account of interest
11. for due period beyond the due date and (ii) also for adverse movement of forex rate as per the Compensation Policy of the Bank.
- g. All certificates required to be issued under regulatory/statutory instructions will be issued at nominal charges which will be displayed on our website except the certificates which are statutory and to be issued free of charge.

## 8.11 Remittances within India

If you want to remit money within India, we will inform you how to effect it and:

- a. give a description of our services and how to use them.
- b. suggest to you the best way to send the money to suit your needs.
- c. disclose the details of all charges including commission that you will have to pay for the service as per the Tariff Schedule.
- d. send you an SMS/e-mail informing you of the fate/status of the remittance made by you through Mobile Banking/NEFT/RTGS.
- e. make available on our website updated contact details of our Customer Facilitation Centres to handle your queries/complaints regarding NEFT/RTGS transactions/digital banking.
- f. in case of any delay we will compensate you for the delay and any loss/additional expense incurred by you as per our Compensation Policy.
- g. we will extend remittance facilities within prescribed limits to walkin customers too.

## 8.12 Lending

- a. We will have a Board approved policy on Loans and Advances.
- b. We will base our lending decisions on a careful and prudent assessment of your financial position and capacity to repay.
- c. We will not discriminate on grounds of sex, caste and religion in the matter of lending. However, this does not preclude us from instituting or participating in schemes framed for specified sections of the society.

## 8.12.1 Loans

## 8.12.1.1 General Information

We will:

- a. give you the Most Important Terms and Conditions (MITC) governing the loan/credit facility you have sought to avail.
- b. give you information explaining the key features of our loan and credit card products including applicable fees and charges while sourcing the application and at the time of communicating the sanction of the loan/ credit card.
- c. advise you about the information/documentation we need from you to enable you to apply. We will also advise you what documentation we need from you with respect to your identity, address, employment, etc. and any other document that may be stipulated by statutory authorities (e.g. PAN details), in order to comply with legal and regulatory requirements.
- d. verify the details mentioned by you in the loan/credit card application by contacting you at your residence and/or on business telephone numbers and/or through any alternative channels and/or physically visiting your residence and/or business addresses through agencies appointed by us for this purpose, if deemed necessary by us.
- e. if we offer you an overdraft, or an increase in your existing overdraft limit, we will tell you if your overdraft is repayable on demand or otherwise. We will, if required, also advise about the method of calculation of overdrawn amount and also the computation of interest as well as penal interest.
- f. in case we offer/approve a credit facility over the telephone, we will credit your account with the amount only after receiving your acceptance in writing or through any other mode such as SMS/e-mail and where your consent is obtained through authenticated electronic means, after necessary validation.
- g. not offer any unsolicited pre-approved credit facility in any form, including enhancement of credit card limit and top up of personal loan limits, etc.

## 8.12.1.2 Applications for loans and their processing

- a. At the time of sourcing a loan product, we will provide as part of the loan
2. application form, information about the interest rates along with the annualised rates of interest, whether floating or fixed, as also the fees/charges payable for processing, the amount of such fees refundable if loan is not sanctioned/disbursed, pre-payment options and charges, if any, penal rate of interest for delayed repayments, if any,   conversion charges for switching your loan from fixed to floating rates or vice-versa, existence of any interest reset clause and any other matter which affects the interest of the borrower, so that a meaningful comparison with those of other banks can be made and an informed decision can be taken by you.
- b. We will provide you with a checklist of the documents to be submitted (compliant with legal and regulatory requirements) along with the loan application form to enable you to submit the application complete in all respects. If required, we will assist you in filling up your loan application form.
- c. We shall invariably provide you with an acknowledgement of your loan application, whether submitted online or manually, indicating therein the time frame within which the application will be processed.
- d. We will convey our decision on your loan application as per our prevailing policy, which is available on the website, provided your application is complete in all respects and is submitted along with all the documents as per 'check list' provided.
- e. Normally all particulars required for processing the loan application will be collected by us at the time of application. In case we need any additional information, we will contact you immediately.
- f. We will communicate, in writing, the reason(s) for rejection of your loan application. We may communicate this through letter or e-mail stating the reason(s) for such rejection of the loan application.
- g. We will provide you the sanction letter detailing particulars of amount sanctioned and the terms and conditions.
- h. We will provide you an amortisation schedule (schedule of repayment of principal and interest for the duration of the loan).

HSBC PhoneBanking numbers

- i. We will also inform you whether you have an option to let equated monthly instalments stay constant and change tenure or vice-versa when the interest rate changes.
- j. We will, at your request, supply authenticated copies of all the loan documents executed by you at our cost along with a copy each of all enclosures quoted in the loan document as part of disbursement welcome kit. However, reasonable charges will be levied for additional authenticated copies as per our tariff.
- k. We will give written receipt for all documents to title taken as security/collateral for any loan.
- l. We will endeavour to send you a communication through letter/ e-mail or SMS about the status of your account before it becomes a Non Performing Asset (NPA).
- m. We will give you notice, sufficiently in advance, if we decide to recall/accelerate payment or performance under the agreement or seek additional securities.
- n. We will provide you with an annual statement of account of your term/demand loans.
- o. We will provide you with the loan statement, more often, if required, at a cost which will be indicated in the Tariff Schedule.
- p. We will return to you all the securities/documents/title deeds to mortgaged property within 15 working days of the repayment of all dues agreed to or contracted and report to Central Registry for Securitisation, Asset Reconstruction and Security Interest (CERSAI) about satisfaction of our charge. If any right to set off is to be exercised for any other claim, we will give due notice with full particulars about the other claims and retain the securities/ documents/title to mortgaged property till the relevant claim is settled/paid.
- q. We will compensate you for any delay in return of securities/ documents/title deeds to mortgaged property beyond 15 working days of the repayment of all dues agreed to or contracted or in
10. reporting to CERSAI about satisfaction of our charge in line with our Compensation Policy.
- r. In the event of our losing the securities/documents/title deeds you have provided to us when you availed a loan, we will compensate you for the loss. We will issue a certificate indicating the securities/ documents/title deeds lost and extend all assistance to you for obtaining duplicate documents, etc. at our cost.
- s. We will process a request for transfer of borrowal account, either from you or from a bank/financial institution, along with your explicit consent   in the normal course and convey our concurrence or otherwise within two weeks of receipt of request.
- t. We will not levy foreclosure charges/pre-payment penalties on all floating rate term loans sanctioned to you (in your individual capacity) irrespective of whether paid from own funds or takeover by other Banks.
- u. Where a loan is eligible to be covered under any subsidy schemes or subvention scheme in force we will explain to you features of such scheme and any requirement you will need to fulfil.

## 8.13 Guarantee

- a. If you want us to accept a guarantee or other security from a third party for your liabilities, we may ask you for your permission to give confidential information about your finances to the person giving the guarantee or other security, or to their legal adviser.

## b. We will also:

- i. encourage them to take independent legal advice to make sure that they understand their commitment and the possible consequences of their decision (where appropriate, the documents we ask them to sign will contain this recommendation as a clear and obvious notice).
- ii. inform them that by giving the guarantee or other security they may become liable instead of, or as well as, you.
- iii. inform them what their liability will be.

c.

- iv. give a copy of the terms and conditions of the loan sanctioned/loan agreement, free of cost, to the guarantor(s) of the credit facility availed by you.

When you are considering to be a guarantor to a loan, we will tell you:

- i. your liability as guarantor;
- ii. the amount of liability you will be committing yourself to the bank;
- iii. circumstances in which we will call on you to pay up your liability;
- iv. whether we have recourse to your other monies in the bank if you fail to pay up as a guarantor;
- v. whether your liabilities as a guarantor are limited to a specific quantum or they are unlimited;
- vi. time and circumstances in which your liabilities as a   guarantor will be discharged as also the manner in which we will notify you about this;
- vii. of any material or adverse change in the financial position of the borrower to whom you stand as a guarantor.
- d. We will return to you all the securities/documents/title deeds to mortgaged property within 15 days of the repayment of all dues agreed to or contracted.
- e. We will compensate you for any delay in return of securities/documents/title deeds to mortgaged property beyond 15 days of the repayment of all dues agreed to or contracted.
- f. In the event of our losing the securities/documents, we will compensate you for the loss. We will issue a certificate indicating the securities/documents lost and extend all assistance to you for obtaining duplicate documents, etc.
11. 8.14 Central Registry of Securitisation, Asset Reconstruction and Security Interest of India (CERSAI)

When you avail of a loan facility involving immovable property and/or movables as primary or collateral security, we will advise you the functioning of the CERSAI and the fact that their records will be available for search by any lender or any other person desirous of dealing with the property/assets. We will notify our charge to CERSAI.

## 8.15 Settlement of dues

- a. You should let us know, as soon as possible, if you are not able to make your payments in time.
- b. We will consider all cases of genuine financial difficulties sympathetically and positively, in consonance with regulatory guidelines and our policy.
- c. We will try to help you overcome your difficulties.
- d. In case we offer you a One Time Settlement (OTS) for repayment of dues, we will explain to you the details of the offer.
- e. We will spell out, in writing, the terms and conditions of the OTS offered to you.
- f. If the dues are settled under OTS, we will explain to you the implications of such settlement on your credit history maintained by the CICs.

## 8.16 Securitisation of loans/card dues

- a. In case we securitise (sell) your loans/dues on your card to another entity, we will advise you the name and contact details of such entity along with the amount of your loan/dues transferred to them. In the normal course, loans/credit card dues, which are Non Performing Assets (NPAs) are considered for sale to Asset Reconstruction Company (ARC) through assignments. Where dues are settled through compromise, assigning such assets to ARC does not arise.
- b. You will then be liable to pay the amount due to the entity to which the loan/dues have been transferred.
- c. The entity to which the loan/dues have been transferred will continue to report your credit information to the CICs.
- d. We will endeavour to assist you in case you have a grievance against the entity to which your loan/dues have been transferred by us.
- e. For all complaints against the entity to which your loan/dues have been transferred by us, we will remain the Nodal Authority for resolution. We will treat these complaints as if they are against us and ensure that these are resolved promptly.

## 8.17. Electronic and Digital Banking

HSBC PhoneBanking numbers

## 8.17.1 Internet and Mobile Banking

We will take appropriate measures to provide safe and secure Internet and Mobile Banking. We will ensure that our systems and technology are safe and secure and review and update them periodically.

- a. We will implement robust and dynamic fraud prevention and detection mechanisms to mitigate risks and protect customers from liabilities arising from unauthorised transactions.
- b. We will undertake various initiatives to educate you on Internet/ Mobile Banking security and on prevention from payment related frauds, by way of:
- i. Displaying relevant information on our website
- ii. Displaying information at customer touchpoints like ATMs and branches.
- iii. Periodic educational e-mails
- c. When you have access to Internet/Mobile Banking services, we will also inform you of the applicable terms and conditions relating to such services. All Internet/Mobile Banking related services and associated charges, if any, will be displayed on our website and made available to you.
- d. We will also inform you where to find the information you need to safeguard your online information and to protect yourself while using computer/mobile handset from fraud, scams or unauthorised transactions. This information will be updated from time to time.
- e. We will carry out adequate authentication processes for financial transactions, as prescribed by the regulator from time to time.
- f. We will send you SMS/online e-mail alerts for all types of transactions, irrespective of the amount, undertaken by you. These alerts will be sent to the contact details registered with us.
- g. We will ask you for additional factor authentication/validation based on information not visible on the cards for all on-line card not present transactions as well as IVR transactions.
- h. We will send you an SMS/e-mail on all payee/biller registration done

## on Netbanking.

- i. In case we offer you the facility of fixing a daily cap on the value, mode of transactions, number of transactions and beneficiaries for electronic modes of transactions, we will require an additional authorization in the event of your changing the options. We will send you an alert when a request for change in the option is received.
- j. Mobile Banking service is network independent, i.e. customers having mobile phones of any network of operator can transfer funds from account in one bank to any other account in the same bank or any other bank.
- k. If you opt for Mobile Banking services we will, prior to your registration for the service, inform you of:
- i. the security procedure adopted by us for user authentication;
- ii. time taken between registration of customers and activation of services;
- iii. the applicability or otherwise of stop payment instructions and the terms and conditions for the acceptance, if any, for the same.
- l. You can apply for registration of Mobile Banking services through multiple channels such as ATMs, Websites, Phone Banking, IVR, SMS, etc. You need not come to branches for the same.
- m. Mobile Banking transactions are completely instantaneous and are incapable of being reversed. Thus stop payment privileges are very limited.
- n. You may opt out of Internet/Mobile Banking Services at any point of time. However, you must keep us informed of your decision and ensure that you complete the requisite formalities.
- o. In any dispute about receipt of Passwords or security information that are not issued to you in person, we will not rely merely on proof of dispatch to your correct registered address as proof that they have been received by you.

HSBC PhoneBanking numbers

- p. Online banking is safe and convenient as long as you take adequate and simple precautions. Please make sure you follow the advice given below:
- i. Visit our secure Internet banking site directly. Avoid accessing the site through a link from another site or an e-mail and verify the domain name displayed to avoid spoof websites.
- ii. Log out of Internet Banking when your session is complete. Use the 'Log Out' button to log out so that the session closes. Do not just close the window to log off.
- iii. Log off your PC when not in use.
- iv. Avoid using Internet Banking on unsecured networks like airports, railway stations, cyber-cafes or any other public network/wi-fi, etc.
- v. Update your computer/laptop with the latest version of your browser (Internet Explorer, Google Chrome, etc.)
- vi. Install security programmes to protect against hackers, virus attacks or any malicious programmes. Update your security programme or antivirus on regular basis.
- vii. Install a suitable firewall to protect your device/laptop/mobile, etc. and its contents from outsiders.
- viii.  Disable the 'File and Printing Sharing' feature on your operating system.
- ix. Preferably use virtual keypad while conducting electronic financial transactions/internet banking.
- q. Apart from your obligations when using Internet Banking, you will need to take additional care to protect your device when using a mobile application or any other form of social media to access banking services:
- i. Do not leave your device unattended and logged into a Mobile Banking service.
- ii. Lock your device to prevent unauthorised use of your Mobile Banking service.
- iii. Notify us as soon as possible if your device is lost or stolen.
- iv. Update your Mobile Banking App as and when a new version/
16. upgrade is released.
- v. Update your mobile operating system to ensure that the latest security patches are available on your mobile.
- vi.   Purchase your mobile phone from an authorized dealer.
- vii.   Ensure to check the authenticity of all Apps downloaded on your mobile. Do not download Apps from untrusted sources.
- r. Log out of Mobile Banking application once you are done using it. Check your account and transaction history regularly.
- s. Do not share your internet/Mobile Banking security information or disclose your password as response to any e-mail (even if it appears to have been sent from our bank). Please inform us of the same for us to investigate. Neither the police nor we will ever contact you to ask you to reveal your online banking or payment card PINs , or your password information.
- t. Customer complaints/grievances arising out of Mobile Banking facility are covered under Banking Ombudsman (BO) Scheme.

## 8.17.2.1 PINs and Passwords

- a. A password is a string of characters used to verify the identity of a user during the authentication process. Passwords are important so that sensitive data or a critical information does not fall into wrong hands.
- b. We will conform to internationally accepted standards for methods of generation, storage and terminal security relating to PINs and Passwords to ensure their confidentiality and security for your protection.
- c. We will deliver your PIN in a sealed cover to you at the registered address we have on record or at our branch after due identification. You   may, also at your convenience, generate PIN online/via IVRS or at ATMs.
- d. We will ensure that your recent contact details (mobile number, e-mail ID and landline number) are registered and updated with the Bank.
- e. In order to safeguard your account, you must choose a strong PIN/ password and change it regularly.
6. 8.17.2.2 You should also adopt the following safe practices/precautions to

HSBC PhoneBanking numbers

## protect your PIN or Password. For creating PIN /Password:

- a. Use the following guidelines to create a strong password:
- Do not use familiar names which are easily discoverable (self, spouse, children, parents, pets, etc.)
- Avoid using commonly known facts about yourself (hobbies, birthdays, favourite sports, etc.)
- Do not use words found in the dictionary as software programmes can search for probable words and guess the password. Instead combine misspelt words to prevent a dictionary attack
- Use at least six or more characters. More the characters in a password, the more secure it is
- Utilize a combination of letters and numbers to make it more difficult for a person/software programme to guess your password
- Use special characters (@, #, %, $, etc.) to make the password more difficult to crack
- Use a combination of upper- and lower-case letters which helps to create a more secure password
- b. Do not use the following to create a * PIN :
- birth dates, months or years;
- sequential numbers (e.g. 3456);
- number combinations that may be easily guessed (e.g. 1111);
- parts of your telephone number;
- parts of numbers in the order in which they are printed on any of your cards;
- other easily accessible personal data (e.g. driving licence, your vehicle number or other numbers easily connected with you)
16. *This is only an illustrative and not exhaustive list.

Precautions for preventing unauthorised transactions in your account: Do not:

- Allow anyone else to use your card, PIN, password or other security information
- Write down or record your PIN, password or other security information
- Store your password(s) in your Browsers (such as Internet Explorer, Google Chrome, Firefox, etc.) or on e-Commerce sites or in mobile handset
- Save your Mobile Banking Login and password on your phone
- Give your account details, password/PIN/OTP or other security information to anyone, including those who claim to be authorized representatives of the bank
- Respond to any communication asking for your Bank account credentials (Internet banking password, ATM PIN, CVV, Card expiry date, etc.)
- Respond even if any message threatens discontinuation of facility or makes an exciting offer or mentions any other reason All such communication through letters, e-mails, mobile phones, SMSs, etc. should be ignored.
- Fall prey to fictitious offers/lottery winnings/remittance of cheap funds in foreign currency from abroad by certain foreign entities/individuals. These could include Indian residents acting as representatives of such entities/individuals.
- These messages often appear to be from a friend, bank or other legitimate source directing you to certain websites designed to trick you into providing personal information such as your user name and password or credit card information.
- Click a link in any suspicious e-mails/SMS, and don't provide your information unless you trust the source e-mail/SMS
- Allow anyone else to see you enter your Password in a PC/mobile handset or to see the PIN when you use your card at ATMs or at Points of Sale (POS) counters

## Always:

- Change your PIN/Password at regular intervals at least every 3 to 6

<!-- image -->

HSBC PhoneBanking numbers

months. Do not repeat your previous passwords

- Memorize your PIN, password and other security information and destroy the written communication, if any, received by you
- Take reasonable steps to keep your card safe in your personal custody and your PIN, password and other security information secret at all times
- Use different PINs or Passwords for different cards or devices
- Use a power-on/access password for your computer/laptop/mobile and a screensaver password on your computer/laptop/mobile so that no one else can use it without your consent Immediately inform (through authorised officials of bank or authorised channel) your bank on change of your e-mail ID or mobile number.

## 8.17.3 ATM/Debit and Credit Cards

- a. We will offer you an ATM/Debit Card if it is normally issued with the type of account you have opted for.
- b. New Cards/Replacement cards (debit as well as credit cards) will be essentially EMV Chip and PIN enabled card only. You may decline to accept the card if you do not want it.
- c. Where cards are delivered to you personally, we must be satisfied about your identity before allowing cards to be delivered.
- d. We will send a service guide/member booklet giving detailed terms and conditions, losses on your account that you may be liable if your card is lost/misused and other relevant information with respect to usage of your card along with your first card.
- e. We will inform you which of your accounts your card can access. We will also inform you whether the card issued to you has more than one function and if so, what those functions are.
- f. We will advise you of the current transaction limits that apply at POS counters, ATMs and forex transactions.

g.

We will advise you of the fees and charges that apply to your card.

- h. Please safeguard your card by taking the following measures:
- Sign your card as soon as you receive it
- Do not leave your card unattended (in a wallet/purse) or in a
4. location   (e.g. your vehicle) from where it could be removed without being noticed
- Do not give your card to anyone or let anyone else use your card including at merchant establishments (e.g. restaurants, petrol pump, etc.)
- Always remember to take your card back after using it
- Inform us if you change your address with documentary proof so that, whenever required, a replacement card is sent to your correct address
- Complaints relating to disputed/failed ATM transactions are to be lodged with card issuing bank (through authorized officials or channel)

## 8.17.4.1 Reporting loss/theft/disputed transactions

- a. We will inform you of the procedure you must follow to report the loss, theft or unauthorised use of your card or PIN.
- b. We will include in the terms and conditions what your liability will be in relation to the loss or theft of your card or disclosure of your PIN or Password.
- c. We will provide the capability to register your mobile number and wherever available, e-mail ID, before activating any electronic transaction facility .
- d. We will provide multiple channels for enabling you to report an unauthorized transaction on 24x7 basis. These channels would be helplines, SMS, e-mail, IVR, website, etc. You can also report such transactions to your home branch during the working hours. Further, we will also provide you the details of our channels through which you can block your card. We will promptly send a confirmation for having blocked usage of the card.
- e. We will provide, if possible, inbuilt reply facility to SMS. However all our SMS alerts will include alternate number/mobile number/e-mail ID to contact us immediately.
- f. We will provide a direct link for lodging the complaints, on home

HSBC PhoneBanking numbers

- page of our website with specific option to report unauthorized electronic transactions.
- g. We will provide a loss/fraud reporting system that sends an immediate response (including auto response) to you acknowledging the complaint  along with the registered complaint number.
- h. You should inform us as soon as you discover that your card has been lost or stolen or someone else knows your PIN, password or other security information, apart from changing them immediately. On your   notifying us, we will take immediate steps (such as blocking of your card or resetting the PIN, as the case may be) to prevent the misuse.
- i. Once you have advised us that your card has been lost or stolen or your PIN or Password disclosed, you will not be responsible for any unauthorised use of your card after that time.
- j. On receipt of your complaint of an unauthorised transaction, we will take immediate steps to prevent further unauthorised transactions in your account.
- k. The liability for the losses due to an unauthorised transaction will be based on the regulations from the regulator that are in force at that time.
- l. You will not be liable for losses before you receive your card or, if applicable, your PIN and Password, provided you have notified us of your current address.
- m.   We will display the telephone/Toll Free numbers of the help desk/contact persons of the ATM owning bank at ATM locations for lodging complaints and/or for reporting/blocking lost/ compromised cards.
- Please ensure to lodge complaints only to your card issuing bank for redressal.
- n. ATM ID has been displayed on all the ATMs. You should quote the same while making a complaint/suggestion. Forms are available
- within ATM premises for lodging ATM complaints.
- o. We will reimburse amounts wrongly debited in failed ATM transactions  within the prescribed time limit. For any delay beyond the prescribed time limit, we will pay compensation as prescribed, provided the claim is lodged with us, (i.e. the ATM card issuing bank) within 30 days of the transaction.
- p. In case of disputed ATM transactions, we will retain the relevant camera footage till the dispute is settled. Access to such footage will be available only if the dispute is raised within the prescribed preservation period of such records.
- 8.17.4.2 Limited Liability in respect of unauthorised electronic banking transactions.
- a. You will be entitled for Zero liability where the unauthorised transaction occurs in the following events:
- i. Contributory fraud/negligence/deficiency on our part.
- ii. Third party breach where the deficiency lies elsewhere in the system and you notify us within three working days of receiving the communication from us regarding the unauthorised transaction.
- b. You shall be liable for the loss occurring due to unauthorised transactions in the following cases:
- i. In cases where the loss is due to your negligence such as where you have shared the payment credentials, you will bear the entire loss until you report the unauthorised transaction to us. Any loss occurring after the reporting of the unauthorised transaction shall be borne by us.
- ii. In cases where the responsibility for the unauthorised electronic banking   transaction lies neither with us nor you, but lies elsewhere in the system and when there is a delay (of four to seven working days after receiving the communication from us) on your part in notifying us of such a transaction, your per transaction liability shall be limited to that transaction value or

the

- amount whichever is lower as mentioned in RBI guidelines issued from time to time on the subject.
- iii. Further, if the delay in reporting by you is beyond seven working days, your liability shall be determined as per our Board approved policy which will be available in public domain/our website. We shall provide the details of our policy in regard to your liability formulated in pursuance of the RBI directions on the subject at the time of opening the accounts. We will inform all the customers individually also about our policy on the subject.

## 8.17.4.3 Reversal Timeline for Zero Liability/Limited Liability

On being notified by you, we shall credit (shadow reversal) the amount involved in the unauthorised electronic transaction to your account within 10 working days from the date of such notification by you (without waiting for settlement of insurance claim, if any). The credit shall be value dated to be as of the date of the unauthorised transaction.

Further, we will ensure that:

- i. your complaint is resolved and liability, if any, established within such time, as may be specified in our Board approved policy, but not exceeding 90 days from the date of receipt of the complaint and you will be compensated as per RBI guidelines on the subject.
- ii. where we are unable to resolve the complaint or determine your liability, if any, within 90 days, the compensation as per RBI guidelines will be paid; and
- iii. in case of debit card/bank account, you will not suffer loss of interest, and in case of credit card, you do not bear any additional burden of interest.

## 8.17.5 Credit Card

- a. When you apply for a credit card, we will explain the relevant terms and conditions such as fees, interest and other charges, billing and payment, method of computation of overdues, financial implications of paying only 'the minimum amount due', renewal and termination procedures,
2. and any other information that you may require to operate the card. We will disclose the Most Important Terms and Conditions (MITC)
- b. in a font of ten as below:
- i. During marketing-MITCs on 'Fees and Charges'
- ii. At application/Welcome kit-All MITCs, including, inter-alia,*
- iii. On Credit card Billing-MITCs on Fees and Charges, drawing limits.
- iv. On an ongoing basis, any change of the terms and conditions.

*Your liability in case of third party fraud or where you have not contributed to the fraud.

- c. We will advise you of our targeted turnaround time while you are availing/applying for a credit card. We will quote annual fee and Annualised Percentage Rates (APR) on card products (separately for retail purchase and for cash advance, (if different) with equal prominence). The method of calculation of APR, late payment charges, and calculation of interest will be explained clearly with examples. These aspects will be shown in the Welcome Kit in addition to being shown in the monthly statement. A notice to the   effect making only the minimum payment every month would result in the repayment stretching with consequent interest payment on your outstanding balance will be prominently displayed in all the monthly statements. We will also mention the rate of interest that will be charged   on the unpaid amount and other charges if you choose to pay only the 'minimum amount due' as mentioned in the monthly credit card statement.
2. In MITC, we would specifically explain that the 'free credit period' is lost if any balance of the previous month's bill is outstanding.
- d. We may also issue a deactivated (not ready to use) credit card if we consider your profile appropriate for issuing credit card and such deactivated card will become active only after you convey your acceptance of the card and take steps for its activation as required and subject to such other conditions as may be specified.
- e. In case we activate the card without your consent or bill you for the card for which you have not given your consent, we will not

- only reverse the charges forthwith but will also pay a penalty amounting to twice the value of the charges reversed.
- f. We will extend a loan/credit facility or enhance the credit limit on your card only with your consent in writing. Consent received through electronic means where you specifically validate the transaction and having read the MITC and where digital records of such consent can be retrieved as a proof of consent, will also be treated as consent.
- g. We may issue an add-on card(s) to the person(s) nominated by you. We will, at your request, set a credit limit (within the overall limit) for the add-on card(s) issued to you. You will be liable for all transactions made by such additional cardholders.
- h. If the limit on your credit card is proposed to be reduced, we will give you thirty days notice unless at your request and also inform you the reason therefor, by SMS/e-mail/letter.
- i. We will ensure that we comply with your request for cancellation/ reduction of limit and confirm cancellation/reduction of limit/closure of the credit card to you within 7 working days of the request being received in writing or through an e-mail ID registered with us, provided that the outstanding amount, if any, is settled/paid.
- j. We will have right to place a lien and right to set off on all monies belonging to you, being the card holder, standing to your credit, in the same capacity, in any account whatsoever with the Bank or in the possession or custody of the Bank if you are in default to us in payment of our dues. We will send you intimation to this effect by e-mail on your registered e-mail ID/registered mobile number or letter within three days from placing lien/hold on your deposit account.
- k. In case we are offering any insurance cover to our credit card holders, in tie up with insurance companies, we will obtain in writing from you the details of nominee/s for the insurance cover in respect of accidental death and disablement benefits. We will ensure that
- the relevant nomination details are recorded by the insurance company which will handle the claims relating to the insurance cover.
- l. To facilitate low value online Card Not Present (CNP) transactions, the requirement of Additional Factor Authentication (AFA) has been relaxed. Accordingly, we (card issuing bank) will offer the 'payment authentication solutions' to you on an optional basis. To seek your consent and to activate your option, we shall provide a one-time registration process facility. The relaxation for AFA under such solutions shall be applicable for CNP transactions for a maximum value of ` 2,000 per transaction (or as decided by regulator from time to time). We will also facilitate you to set lower per transaction limits.
- m.   We will bear the liability of any unauthorised electronic transaction as per Clause 8.17.4.2 of this Code.

## 8.17.5.1 Credit card statements

- a. To help you manage your credit card account and check details of purchases/cash withdrawals, we will send you a monthly statement, free of cost, with details of the transactions made ith/ using your credit card. The credit card statement will be dispatched on a predetermined date every month, by post/courier to your mailing address or, if you so desire, by e-mail to the address registered with us. The statement will also be made available for viewing on internet banking. We will ensure that wrong bills are not raised and issued nor will we levy charges which have not been notified by us.
2. In case, a complaint is raised against any bill, we will provide explanation and, if necessary, documentary evidence will also be provided to you within a maximum period of sixty days with a spirit to amicably redress the grievances. In case erroneous charges are reversed, the reversal will not be deemed as settlement of dues.
- b. In the event of non-receipt of this statement, we expect you to get in

touch with us so that we can arrange to resend the details to enable you to make the payment and highlight exception, if any, in a timely manner.

- c. We will let you know/notify changes in the schedule of fees and charges and terms and conditions. Normally, changes (other than interest rates and those which are a result of regulatory requirements) will be made with prospective effect after giving notice of at least one month. The changes will be notified along   with the monthly statement of account or copy thereof. In case of a default, the same will be reported to Credit Information Companies (CICs).
- d. Before reporting to Credit Information Companies about default status of a credit card holder, we will adhere to a procedure approved by the Board, including issuing of sufficient notice to the Cardholder. Notwithstanding the reversal of a wrong billing, unnotified charges will not be the cause of reporting to CICs. In case we treat the reversal of charges as SETTLED, we will inform CIC about the settlement and inform you of the same being reported to CIC.

## 8.18 Third Party Products

We distribute third party products like pension funds,mutual funds and insurance, etc. under corporate agency arrangements in terms of Certificate of Registration issued by respective regulators viz SEBI (mutual fund) and IRDAI (insurance products). We have Board approved policy for sale of insurance products in line with IRDAI (Registration of Corporate Agents) Regulations 2015.

- a. We will inform you if we, as agents of any investment/asset management company or insurance company, offer any type of investment products including mutual funds or insurance products. We are responsible for any person using our premises for selling or marketing third party products on our behalf.
- b. We will ensure that all investment and insurance products we sell are in accordance with extant rules and regulations.
- c. When you avail a banking service or product from us, we will not compel you to purchase/subscribe to any third party product as a quid

pro quo.

- d. In the case of securities provided by you for loans availed from us, we will not insist on your obtaining insurance cover   from any particular provider/same organisation. Obtention of insurance products, if any, offered by us will be purely on voluntary basis. You will be free to obtain insurance cover from a service provider of your choice.
- e. We will, at regular intervals, educate you by way of advertisement/ notice board/information on website/distribution of pamphlets, etc. the benefit of the products being sold at our branch, and also through e-mails and SMS, unless you have opted not to receive such information.
- f. We will ensure that all investment and insurance products sold at the branch will be explained to you by personnel who are duly qualified and trained to sell the products.
- g. We will provide detailed terms and conditions of the product which is being offered to you (Key information Memorandum in case of mutual fund and product brochure, sales illustration in case of insurance products).
- h. We will apply appropriate customer due diligence measures before selling investment/insurance products to you.
- i. We will sell a product to you only if we believe it is suitable and appropriate for you.
- j. We will obtain the requisite application and documentation for a product offered only after you have consented to subscribe/avail of the product, in writing or through authenticated electronic means/ after necessary validation.
- k. We will ensure that the statement/policy documents will be delivered to you within 30 days from the completion of all the formalities (including medical examination) as per the scheme.
- l. We will arrange to provide maximum possible 'After Sales Service' like reminder of SIP , latest NAV, date of maturity, due date of payment of premium, etc.

- m. The service providers will be providing you periodical information on the performance of the scheme/products you have availed from them.

In case you require any specific service, we will facilitate the same on receiving specific request from you.

- n. We will disclose details of all commissions/other fees received, if any, from mutual fund/insurance/other financial companies on the Bank's website for distributing their products.
- o. We will adhere to RBI guidelines on para banking activities like sale of insurance/mutual fund/other third party investment products.
- p. We will ensure that the charges for related services for selling of various products will be displayed and made available to you.

## 8.19 Credit Counselling Facility

We will endeavour to provide credit counselling facility. Wherever such facility is available, we will display, at our branch in a particular centre, the address, timings, etc. of the counselling centres set up by any bank at that centre to enable you to avail of the service.

## 8.20 G etting Records

We will, on request, make available to you, at a cost, records pertaining to your transactions, provided this is within the prescribed preservation period of such record.

## 9. Branch closure/shifting

- a. If we plan to close our branch or if we move our branch or we are not able to continue to provide banking services to you, we will give you,
- i. Notice of two months if there is no branch of any bank functioning at that centre;
- ii. Notice of one month in all other cases.
- b. In case we shift the branch, we will inform you of the complete address of the new location of our branch.
- c. We will inform you of any change in the timings of the working of the branch.

## 10.  Financial Inclusion

- a. We will make available 'Basic Savings Bank Deposit Account' (BSBD Account)/Small Account and Jan-Dhan Account without the requirement of any minimum balance subject to compliance with the instructions on Know Your Customer (KYC)/Anti-Money Laundering (AML) for opening of bank accounts issued by RBI/ Government of India(GOI) from time to time. We will also offer/ provide minimum common facilities including the facility of ATM card or ATM-cum-Debit Card without any charges, which will be made known to you. The relevant details will be made known to you in a transparent manner at the time of opening of the account.
- b. We will also extend the facility of opening such accounts on the basis of simplified KYC norms. However, such accounts will be additionally treated as 'Small Accounts' and subjected to restrictions which will be made known to you in an easy to understand manner and in the local language.
- c. We will also prominently display at all our branches in bilingual/ trilingual, the requirements for opening 'Basic Savings Bank Deposit Account' and also the documentation required under simplified KYC norms for opening 'Small Account'/Jan-Dhan account.
- d. We will also take steps, including training, to create awareness about the above among our staff, particularly the frontline staff.
- e. We will make available, free of cost, basic banking facilities like maintaining of accounts with a specified number of withdrawals in a   month, General Credit Card and transfer of benefits from State and Central Governments through electronic platforms.
- f. We will provide value added services, if so desired, by you either free of cost or with low charges, to be notified upfront in the language known and understood by you.
- g. If there are any changes in the services, transactions or the charges, these will be made known at least one month prior to these becoming effective.

- h. The changes, if any, will be communicated through means appropriate to you such as by display on the Notice Board of the branch, or through the Business Correspondent or through letters, etc.
- i. Where we do not have a branch, we will endeavour to have a Business Correspondent (BC)/Business Facilitator (BF) in unbanked areas as per guidelines and road map agreed to, if any, with RBI to enable the opening of accounts, deposit and withdrawal of money, subject to amount and number of transactions, balance enquiry, etc., as also to facilitate transfer of money from one place to another.
- j. We will also endeavour to provide Mobile Banking facilities.
- k. We will also endeavour to provide other modes of remittance including mobile phones, electronic platforms like NECS, NEFT , etc.
- l. We will be responsible for all acts of omission and commission of Banking Outlet/BC/BF and any complaint lodged against them will be investigated.
- m.   We will offer, in case of need, a credit facility at affordable cost, subject to terms and conditions which will be made known to you at the time of applying for the credit facility.
- n. We will explain to you the various credit plans available, including minimum information which the bank may need for processing your loan application, the most important terms and conditions applicable to such loans, the security which may be charged to the Bank, the manner and periodicity of application of interest, repayment procedure, etc.
- o. We will not insist on collateral security for credit limits up to Rupees One lakh for Government sponsored schemes under Priority Sector Lending except loans to MSE customers where higher collateral free imit of ` 10 lakh is applicable. We will not insist on collateral security for education loans, up to ` 4 lakh or as revised from time to time under Education Loan Scheme.
- p. In case you face any financial difficulty in relation to the credit facility availed by you, we will consider such cases sympathetically and positively.
- q. You may keep us informed of any financial difficulty you may face, as above, to help us assist you overcome your difficulties. While processing your loan application we will not insist on obtaining 'No Dues' Certificate from you (individual borrowers and Self Help Groups (SHGs) &amp; Joint Liability Groups (JLGs) for all types of loans unless a particular Government sponsored scheme itself provides for obtention of 'No   Dues' Certificate.
- r. We will endeavour to help you to overcome your difficulties by, where desirable, drawing up a revival package, if such package is considered desirable in the interest of both of us.
- s. We will educate and guide the account holders the manner of operating bank accounts either under normal branch or through alternate channel including using devices under Information and Communication Technology (ICT) enabled platforms.
- t. We will undertake financial literacy activities to educate customers.
- u. We will organize camps, stalls and town hall events to promote the cause of financial inclusion in towns and villages with participation by the target group.
- v. We will introduce a mechanism in the Bank to educate our staff across levels about the financial inclusion efforts in the country in general and in the Bank, in particular.
- w.   We will put in place a system of regular/ongoing visits by the Bank's officials to the unbanked areas where financial inclusion initiatives have been undertaken to ensure end-implementation of the Bank's efforts.
- x. We will endeavour to attend promptly to your complaints, if any, and resolve them at the earliest.
- y. In case you have any grievance about the bank or its Banking Outlet/BC/ BF, we will make known the manner of lodging complaints and the mechanism in the bank for resolution of complaints, as also the Banking Ombudsman Scheme, in case your complaint is not resolved or resolved to your satisfaction by the Bank.
- z. We will give wide publicity to the financial inclusion programme and

educate the customers about various products and services.

## 11.  Senior Citizens And Differently Abled Persons

- a. We will make our best efforts to make it easy and convenient for our special customers like senior citizens , differently abled and illiterate persons to bank with us. This will include making convenient policies, products and services for such applicants and customers.
- b. We will endeavour to develop systems and procedures to improve access to banking services by you.
- c. We will endeavour to make physical access to our branches and ATMs convenient to you. We will endeavour to provide ramps and hand railings at bank branches and ATMs to make it easier for senior citizens and differently abled persons to access various banking   facilities.
- d. We will sensitise our staff interacting with you to assist you in carrying   out your banking transactions.
- e. In addition to all the other commitments made in this Code:
- i. We will accord due priority to you. We will endeavour to provide you   personalised services for banking transactions and redressal of grievances.
- ii. We will endeavour to provide seating arrangements in the banking   hall.
- iii. We will endeavour to provide you our services through a Single Window mechanism.
- iv. We will permit withdrawal of your funds, up to limits set by you, by persons authorised by you on production of the authorisation letter and passbook.
- v. We will endeavour to provide 'Doorstep' banking (pick up of cash/instruments for credit to the account or delivery of cash/ demand drafts against issue of cheque/requisition in writing) in special circumstances like ill health, inability to come to the branch, etc.
11. For senior citizens more than 70 years of age and differently abled or infirm persons (having medically certified chronic illness or disability) including those who are visually impaired, we will make concerted effort to provide door step banking for basic banking facilities such as pick up of cash and instruments against receipt, delivery of demand drafts, submission of KYC documents and Life Certificate at the premises/residence of such customers.
- vi.   We will issue a pension slip to you (pensioners) containing details of the pension credited to your account.
- vii.   We will endeavour to arrange to disburse the pension at the doorstep, in special circumstances.
- viii.  We will accept the Life Certificate that is required to be submitted by you (pensioners) at any branch of our bank by maintaining centralized data for the same.
- ix.   We will guide relatives/parents of disabled persons on how to appoint a legal guardian, under the National Trust Act, 1999, for disabled persons   with autism, cerebral palsy, mental retardation and multiple disabilities who can then open and operate accounts for such persons.
- x. We will ensure that all the banking facilities such as cheque book facility,   ATM facility, net banking facility, locker facility, retail loans, credit cards etc., are invariably offered to the visually challenged without any discrimination.
- xi.   We will render all possible assistance to the visually challenged for availing various banking facilities.
- xii.   We will endeavour to arrange regular meetings so that you may voice your concerns and benefit from collective experience.

## 12.  Protecting your Accounts

## 12.1 Secure and reliable banking and payment systems

- a. We will make best efforts to ensure that you enjoy secure and reliable banking and payment systems which you can trust.

HSBC PhoneBanking numbers

- b. We will install CCTV, wherever feasible, for close surveillance as part of security arrangements.

## 12.2 Keeping us up to date

- a. Please make sure you register your current address, phone number, mobile phone number and/or e-mail ID with us to enable us to send you necessary alerts.
- b. Please make sure you let us know, promptly, when you change your name, address with supporting documents of change of name and address proof as required, phone numbers and e-mail ID so that we are able to contact you when required.

## 12.3 Checking your account

- a. We recommend that you check your statement or passbook regularly. If there is an entry, which seems to be wrong, you should tell us as soon as possible so that we can investigate the same.
2. Regular checks on direct debits and standing orders will help you ensure the money is going where you want it to.
- b. If we need to investigate a transaction on your account, you should co-operate with us and with the police/other investigative agencies if we need to involve them.

## 12.4 Taking care

Taking care of your cheques, passbook and other security information is essential to help prevent fraud and protect your accounts. Please make sure that you follow the advice given below:

- a. i. Do not keep your cheque book and cards together.
- ii. Do not keep the Blank cheque leaves signed.
- iii. Do not give your account details, password or other security information to anyone.
- b. We will advise you what you can do to protect your card/cheque book from misuse.
- c. In the event your cheque book, passbook or ATM/Debit card has been lost or stolen, or that someone else knows your PIN or other security information, we will, on your notifying us, take immediate steps to try to
6. prevent these from being misused. You should also change your PIN/ Password if someone else knows them.
- d. It is essential that you tell us as soon as you can if you suspect or discover that your cheque book, passbook, card has been lost or stolen or someone else knows your PIN, password or other security information.
- e. You could tell us about the loss of the above by phone at our 24 hour toll free number given to you and send us a written confirmation to that effect immediately. Alternatively, you may advise us by e-mail to the address we have given you for this purpose.
- f. You may be liable for misuses until the time that we have been notified.

## 12.5 Cancelling payments

- a. To stop payment of a cheque or cancel standing instruction given, or cancel a direct debit instruction, you must tell us in writing.
- b. We will accept any instruction on withdrawal of mandate by you without necessitating you to obtain the prior concurrence/approval for withdrawal from the beneficiary/user institution.
- c. It may not be possible to cancel payments if you do not give notice of your decision to cancel.
- d. Cancellation of credit card payments will be subject to other terms and conditions as may be stipulated.

## 12.6 Liability for losses

If you act fraudulently, you will be responsible for all losses on your account. If you act without reasonable care, which results in losses, you may be responsible for them.

## Annex - Glossary

These definitions explain the meaning of words and terms used in the Code. They are not precise legal or technical definitions.

## Aadhaar Pay

A mobile app which enables digital payments using biometric card.

## App:

App is an abbreviated form of the word 'application'. An application is a software programme that is designed to perform a specific function directly for the user.

## ATM

An Automated Teller Machine (ATM) is a machine in which a customer can use his card along with PIN to get cash, information and other services.

## Banking Ombudsman

An independent dispute resolution authority set up by the Reserve Bank of India to deal with disputes that individuals and small businesses have with their banks.

## Banking Outlet

A fixed point service delivery unit, manned by either Bank's staff or it's business correspondent where services of acceptance of deposits, encashment of cheques/cash withdrawal or lending of money are provided for a minimum of four hours per day for at least five days a week.

## BHIM

Bharat Interface for Money is a mobile App developed by National Payments Corporation of India (NPCI) based on the Unified Payment Interface (UPI).

## Card

A general term for any plastic card, which a customer may use to pay for goods and services or to withdraw cash. In this Code, it includes debit, credit, smart and ATM cards.

## Credit Card

A Credit Card is a plastic card with a credit facility, which allows you to pay for goods and services or to withdraw cash.

## Cheque Collection Policy

Cheque Collection Policy refers to the policy followed by a bank in respect of the various local and outstation cheques and instruments deposited with the bank for credit to an account. The policy inter alia deals with:

- cheque purchase requests
- timeframe for credit of cheques
- payment of interest in case of delay in collection of cheques
- instant credit of local and outstation cheques
- cheques/instruments lost in transit and charges for such collection

## Customer

A person who has an account (including a joint account with another person or an account held as an executor or trustee or as a 'Karta' of an HUF , but not including the accounts of sole traders/proprietorships, partnerships, companies, clubs and societies) or who avails of other products/services from a bank.

## Current Account

A form of demand deposit wherefrom withdrawals are allowed any number of times depending upon the balance in the account or up to a particular agreed amount.

## Deceased Account

A Deceased account is a deposit account in which case either the single accountholder has deceased or in case of joint accounts one or more of joint accountholders has/have deceased.

## Demat Account

A Demat account refers to dematerialised account and is an account in which the stocks of investors are held in electronic form.

Your Voice Matters

HSBC

## Deposit Accounts

- 'Savings deposit' means a form of demand deposit which is subject to restrictions as to the number of withdrawals as also the amounts of withdrawals permitted by the bank during any specified period
- 'Term deposit' means a deposit received by the bank for a fixed period withdrawable only after the expiry of the fixed period and includes deposits such as Recurring/Double Benefit Deposits/Short Deposits/Fixed Deposits/ Monthly Income Certificate/Quarterly Income Certificate, etc.
- 'Notice Deposit' means term deposit for specific period but withdrawable on giving at least one complete banking day's notice.

## Equity

Equity means a part of capital of a corporate entity which is represented by the shares of the company whether in physical or in dematerialised form.

## Electronic Clearing Service

It is a mode of electronic funds transfer from one bank account to another bank account using the services of a Clearing House.

## Fixed rate of interest

Fixed Rate of Interest on a loan means that interest rate is fixed for the entire period of the loan or it may be revised after the first few years depending upon the terms and conditions of loan.

## Floating rate of interest

Floating Rate of Interest on a loan means that interest rate is not fixed but is linked to Reference Rate and would vary with changes in the latter.

## Guarantee

An undertaking in writing to assure the payment or performance of another person's debt or obligations in the event of a default by the person primarily responsible for it.

## Government Bond

Government bond means a security created and issued by the Government for the purpose of raising a public loan.

## Inoperative/Dormant Account

An inoperative/dormant account is a savings bank or current account in which there are no transactions for over a period of two years.

## IMPS

Immediate Payment Service is an interbank electronic instant mobile money transfer service through mobile phones.

## National Electronic Clearing Service

It is a system introduced by Reserve Bank of India (RBI) for electronic fund transfer within India.

## National Automated Clearing House

It is a web based platform to facilitate interbank, high volume electronic transactions for bank, financial institutions, corporate and government.

## NEFT

National Electronic Funds Transfer (NEFT) system is a nationwide funds transfer system to facilitate transfer of funds from one bank branch to any other bank branch in the country.

## Nomination facility

The nomination facility enables the bank to: make payment to the nominee of a deceased depositor, of the amount standing to the credit of the depositor; return to the nominee the articles left by a deceased person in the Bank's safe custody; release to the nominee of the hirer, the contents of a safe deposit locker, in the event of the death of the hirer.

## Out-of-date (stale) cheque

A cheque, presented for collection, three months after the date of issue of the cheque.

## PAN (Permanent Account Number)

The Permanent Account Number is an all India unique number having ten alphanumeric characters allotted by the Income Tax Department, Government of India. It is issued in the form of a laminated card. It is permanent and will not change with change of address of the assessee or change of Assessing Officer.

Your Voice Matters

## Part time Banking Outlet

A Banking Outlet which provides delivery of service for a minimum of four hours per day and for at least five days a week.

## Password

A word or numbers or a combination on an access Code, which the customer has chosen, to allow him to use a phone or Internet Banking service. It is also used for identification.

## PIN (Personal Identification Number)

A confidential number, use of which along with a card allows customers to pay for articles/services, withdraw cash and use other electronic services offered by the Bank.

## PoS (Point of Sales)

PoS or Swipe Machine as it is popularly known is a technological instrument provided to a Merchant Establishment (ME) to carry out the sale of goods or services to customers in a cashless environment. All the customer has to do is swipe his/her Debit, Credit or Prepaid Card.

## RTGS

The acronym 'RTGS' stands for Real Time Gross Settlement. RTGS system offers the fastest means of transfer of funds through banking channel. Settlement of transactions under RTGS takes place on one-toone basis, which is termed as 'Gross' settlement and in 'real time' i.e. without any waiting period.

## Reference rate

It is the benchmark rate of interest of a bank to which interest on loans sanctioned under floating rate of interest is linked. The Reference rate of interest is determined/modified by individual banks in accordance with their policies.

## Senior Citizen

Senior Citizen is a person of over sixty years of age.

## Settled account

A loan account which is settled under 'One Time Settlement' (OTS) Scheme offered by a Bank for repayment of overdues. This suggests that while the borrower paid some amount it probably was not the full amount originally agreed to. Such settled accounts are reported to CICs for updating the credit history of the borrower.

## Smart Card

A smart card is a plastic card about the size of a credit card, with an embedded microchip which can process data. It provides a secure way of identification, authentication and storage of data. It can be used for telephone calling, electronic cash payments, and other applications.

## Tariff Schedule

A schedule detailing charges levied by a bank on the products and services offered by it to its customers.

## Unified Payment Interface (UPI)

A payment system that allows money transfer by using predefined e-mail ID, between any two bank accounts by using a smart phone.

## Unpaid Cheque

This is a cheque, which is returned 'unpaid' (bounced) by the bank.

## Your Voice Matters

## Did we put a smile on your face?

At HSBC, customer delight is a priority. If you are happy with our services, we would love to hear about it. It would only encourage our employees to serve you better.

Kindly visit the website and share your valued compliments: www.hsbc.co.in/1/2/miscellaneous/compliments

## Providing Feedback

Your feedback helps us strengthen things that we are doing well and at the same time, improve on areas where we need to do better. If you have a suggestion about how we can improve our services, kindly visit the website: www.hsbc.co.in/1/2/miscellaneous/compliments

Thank you for taking time to share your views with us. It will help us serve you better.

## Expect more from HSBC

At HSBC, we want to make sure that you get only the very best of service from us - service which you, our valued customer, deserves.

If at any stage, you feel that our service level is not up to your expectations, here is what you can do:

## L 1

You may visit our website www.hsbc.co.in to make a complaint OR

**E-mail us at complaints.india@hsbc.co.in OR

## Write to:

The Manager, Customer Care Centre, The Hongkong and Shanghai Banking Corporation Limited,

Rajalakshmi, No. 5 and 7, Cathedral Road, Chennai - 600 086.

Banking customers may contact the customer service executive(s) at our branches or write to the Branch Manager explaining the details of their issues. Please visit the Bank's website www.hsbc.co.in to locate the branch nearest to you.

Credit card customers may contact HSBC's PhoneBanking. Please visit the Bank's website www.hsbc.co.in for a list of PhoneBanking numbers. In case you wish to reach out with a complaint on your demat account, please write to retaildematqueriesinm@hsbc.co.in

In case you have any complaints regarding an RTGS or NEFT transaction that you had initiated, please contact the Customer Facilitation Centre (CFC) of the respective beneficiary bank. For details of CFC of member banks, please visit our website www.hsbc.co.in/1/2/miscellaneous/grievance-redressal

## We will respond to your complaint within 10 days.

## L 2

If you are not satisfied with the resolution which you receive or if you do not hear from us within 10 days, please write to the Regional Nodal Officers of the Bank. Please visit the Bank's website www.hsbc.co.in for contact details of our Regional Nodal Officers. Kindly quote the reference number provided to you in your earlier interaction with the Bank, along with your account/card number to help us understand and address your concern.

OR

HSBC

You may also contact the Nodal Officer Team between 9:30 AM and 6:00 PM, Monday to Friday on contact number: +91 44 - 4594 1217,

+91 44 - 3340 1217,

+91 044 - 3911 1217,

Fax number:

+91 - 044 - 3013 4046

OR

You may log into the HSBC Internet Banking and send a message to the Nodal Officer by selecting the message option 'Nodal Officer'.

## We will respond to your complaint within 10 days.

## L 3

If you are not satisfied with the response that you receive from the above or if you do not receive a response within 10 days, you may contact the Office of the Chief Nodal Officer whose details are provided below:

Mr. Sabri Ali, Chief Nodal Officer, The Hongkong and Shanghai Banking Corporation Limited, NESCO - IT Park Building 3, 9 th  Floor, Nesco Complex, Western Express Highway, Goregaon (East), Mumbai - 400 063.

E-mail: pnohsbcbank@hsbc.co.in

## We will respond to your complaint within 10 days.

Please visit the Bank's website www.hsbc.co.in for their contact details of Code Compliance Officers and the Senior Management.

## Escalation to Banking Ombudsman

In the event that you do not receive any response within 30 days from the date the Bank first received your representation or if you are dissatisfied with the response given by the Bank, you may write to the Banking Ombudsman for an independent review. The Banking Ombudsman is a statutory body appointed by the Reserve Bank of India under its Banking Ombudsman Scheme 2006, to look into the provision of satisfactory service by banks. You can get details on the Banking Ombudsman Scheme on our website www. hsbc.co.in (grievance redressal section) or by visiting any of our branches.

## Note:

Please quote the complaint reference number provided by our Customer Service Officer, in case you wish to correspond further on the same issue.

**We recommend that you send an e-mail to us via secured channel i.e. by logging to your Internet Banking account. This is to ensure that we maintain customer confidentiality and security.

Thank you for taking the time to share your feedback with us.

Service Guide

Your Voice Matters

## HSBC PhoneBanking numbers

HSBC PhoneBanking numbers in India: 1800 267 3456/1800 121 2208 For calls from overseas to India: +91-40-61268002 or +91-80-71898002

For complete list of our branches refer our website www.hsbc.co.in