<!-- image -->

## Key Things You Should Know

1. HSBC Credit Cards are globally valid and have been designed to complement your lifestyle. Our products extend a host of offers ranging from travel privileges to dining, shopping and more.
2. Please visit the Credit Cards section of this website for more details on:
-   Free credit up to 48 days on purchases under the applicable terms and conditions (effective 1 July 2021)
-   Rewards programme on your HSBC Credit Card
-   Lost card liability and how to reduce the chances of your credit card being subject to misuse
-   Transaction fee and applicable interest for cash advances against your credit card, Finance charge (interest) in case the credit card outstanding is not repaid in full by the due date
3. You need to pay the Minimum Payment Due (you may choose to pay higher) by the payment due date specified on your monthly card statement to avoid transactions getting declined and levy of late payment fee.
4. Making only the minimum payment every month would result in the repayment stretching till the entire outstanding is settled. For example, if payment due is ` 5,000 and you do not make any new transactions on your credit card, minimum repayment could stretch up to 9 years basis the current tariff structure on your card.
5. You need to pay at least your minimum due amount by the due date. Non payment would impact:
-   Your credit rating (reporting to Credit Bureau - CIBIL)
-   Other credit facilities availed from HSBC
-   In addition to the above, the Bank can cancel the credit limit and initiate recovery proceedings to recover the dues
6. The Bank will notify you of any changes in the terms and conditions of this product with prior notice of one month.
7. Please visit 'Personal - Credit Cards' section of this website for detailed Terms and Conditions applicable on your credit card.

8. Following categories will not accrue reward points on Visa Platinum / RuPay Platinum Credit Card starting from 15 July 2024:
9. Following categories will not accrue cashback on Live+/RuPay Cashback Credit Card (with effect from 15 July 2024):

| Merchant Group                 | MCC                                                                    |
|--------------------------------|------------------------------------------------------------------------|
| UTILITIES                      | 4900                                                                   |
| TAX PAYMENTS                   | 9311                                                                   |
| REAL ESTATE AGENT AND MANAGERS | 6513                                                                   |
| NON FINANCIAL INSTITUTIONS     | 6051                                                                   |
| MONEY TRANSFER                 | 4829                                                                   |
| JEWELRY                        | 5944, 5094                                                             |
| INSURANCE                      | 6300, 5960                                                             |
| FUEL                           | 5541, 5983, 5172, 5542, 5552                                           |
| FINANCIAL INSTITUTIONS         | 6011, 6012, 6010                                                       |
| E-WALLETS                      | 6540                                                                   |
| EDUCATION & GOVERNMENT         | 9399, 8299, 8220, 8211, 8241, 8244, 8249, 9222, 9402, 9211, 9405, 9223 |

| Merchant Group                 | MCC                                                                                                                                                                                                                    |
|--------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| UTILITIES                      | 4900                                                                                                                                                                                                                   |
| TAX PAYMENTS                   | 9311                                                                                                                                                                                                                   |
| REAL ESTATE AGENT AND MANAGERS | 6513, 7012, 7349                                                                                                                                                                                                       |
| NON FINANCIAL INSTITUTIONS     | 6051                                                                                                                                                                                                                   |
| MONEY TRANSFER                 | 4829                                                                                                                                                                                                                   |
| JEWELRY                        | 5944, 5094, 5932, 5937                                                                                                                                                                                                 |
| INSURANCE                      | 6300, 5960                                                                                                                                                                                                             |
| FUEL                           | 5541, 5983, 5172, 5542, 5552                                                                                                                                                                                           |
| FINANCIAL INSTITUTIONS         | 6011, 6012, 6010                                                                                                                                                                                                       |
| E-WALLETS                      | 6540                                                                                                                                                                                                                   |
| EDUCATION & GOVERNMENT         | 9399, 8299, 8220, 8211, 8241, 9311, 8244, 8249, 9222, 9402, 9211, 9405, 9950, 9223, 8351                                                                                                                               |
| BUSINESS TO BUSINESS           | 7399, 7311, 7372, 5045, 5047, 5065, 5072, 5111, 5013, 2741, 5137, 5192, 5193, 5131, 7361, 5085, 7333, 5039, 7379, 5021, 5199, 5122, 5099, 5198, 5139, 7829, 7395, 5051, 5046, 5169, 7375, 5074, 8734, 5044, 2842, 2791 |
| GAMBLING                       | 7995                                                                                                                                                                                                                   |

| TOLLS AND BRIDGE FEES    | 4784       |
|--------------------------|------------|
| SECURITY BROKER SERVICES | 6211       |
| COLLECTION AGENCIES      | 7322       |
| CHARITY                  | 8398, 8641 |
| WHOLESALE CLUBS          | 5300       |