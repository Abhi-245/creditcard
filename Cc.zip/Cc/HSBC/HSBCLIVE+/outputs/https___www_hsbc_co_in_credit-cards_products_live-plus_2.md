# HSBC Live+ Credit Card

Dine, shop and have fun with extra cashback.

<!-- image -->

[Apply for Live+ card](https://www.accountopening.hsbc.co.in/credit-cards/#!/app/apply-for-credit-card?form.campaign_id=INM_PWS_RKTCCPDTPINB&form.source=INM_PWS&WT.ac=INM_PWS_RKTCCPDTPINBANNER&card=cbc)

[Apply for Live+ card  This link will open in a new window](https://www.accountopening.hsbc.co.in/credit-cards/#!/app/apply-for-credit-card?form.campaign_id=INM_PWS_RKTCCPDTPINB&form.source=INM_PWS&WT.ac=INM_PWS_RKTCCPDTPINBANNER&card=cbc)

1. [HSBC IN](\)
2. [Credit cards](\credit-cards)
3. HSBC Live+ Credit Card

## Live it up with extra cashback

Who says you can't have it all? With our HSBC Live+ Credit Card, you can spend on all the things you love... and earn cashback towards the things you've got your eye on.

- 10% accelerated cashback, up to INR1,000 a month, on all dining, food delivery and grocery spends
- 1.5% unlimited cashback on most other spends[@unlimited-cashback-exclusions]

### Joining fee and annual fee

Joining fee

INR999

Annual fee (waived if you spend more than INR200,000 per year)

INR999

[Get started](#what-you-need-to-know)

<!-- image -->

## Our welcome gifts to you

Get INR1,000 cashback when you download and log on to the HSBC India Mobile Banking app and spend INR20,000 within the first 30 days of getting your card. [T&amp;Cs apply (PDF, 295 KB)](\content\dam\hsbc\in\documents\credit-cards\live-plus-welcome-cashback.pdf) .

Plus, get an INR250 Amazon eGift Voucher when you apply online, verify yourself by video and receive your card. [T&amp;Cs apply](\credit-cards\products\live-plus\#verify-video) .

## Get up to 10% cashback on what you love

<!-- image -->

### Dine

Treat yourself with 10% cashback[@accelerated-cashback-cap] on dining and food delivery, around town and across India.

<!-- image -->

### Shop

Get 10% cashback on groceries[@accelerated-cashback-cap] and 1.5% unlimited cashback at other retailers.[@unlimited-cashback-exclusions]

<!-- image -->

### Fun

Binge movies and shows at home or at the cinema, and earn 1.5% unlimited cashback on them too.[@unlimited-cashback-exclusions]

<!-- image -->

### More

Power up on your spending with 1.5% unlimited cashback in selected categories at home and when you're travelling abroad.[@unlimited-cashback-exclusions]

## Live+ perks and privileges

The card that gets you more out of life.

### Dine - in India and around Asia

Take a bite out of dessert, not out of your wallet. No matter if you're craving takeaway or heading out to the restaurants, we've got some pretty sweet dining deals - including up to 15% off with our Live+ Dining Programme and 10% cashback on dining and food delivery spends.[@accelerated-cashback-cap]

- [Learn more Learn more about HSBC Live+ Dining Offers](\credit-cards\offers\regional-live-plus-dining)

<!-- image -->

<!-- image -->

### Shop - both online and offline

Load up your cart without breaking the bank. Whether you're shopping for yourself or the whole family, you'll get 10% cashback on your groceries[@accelerated-cashback-cap] and 1.5% unlimited cashback on other retail purchases.[@unlimited-cashback-exclusions]

### Fun - on screens big and small

Sit back and enjoy some extra cashback. Whatever you're in the mood for, we've got offers you'd love to immerse yourself in - get 1.5% unlimited cashback[@unlimited-cashback-exclusions] on your entertainment spending.

<!-- image -->

## Life with even more perks

- Travel in style and comfort Relax before you fly with 4 complimentary domestic airport lounge visits per year - one per quarter.
- Get more out of life With our exclusive dining programme and curated offers on the Visa Digital Concierge app - [learn more](https://www.concierge-asia.visa.com/)

- Activate your card right away For both primary and supplementary cards, on the HSBC India app.

## What you need to know

### Are you eligible?

To apply, you must: Be aged between 18 to 65 years old Have a minimum income of INR400,000 per year for salaried individuals Be an Indian resident Reside in Chennai, Gurgaon, Delhi National Capital Region (NCR), Pune, Noida, Hyderabad, Mumbai, Bangalore, Kochi, Coimbatore, Jaipur, Chandigarh, Ahmedabad or Kolkata

### What documents do I need to apply?

The latest salary slip, if you're a salaried employee, OR The front side of the card and the latest credit card statement, if you're already using another credit card, AND Proof of residence, identity proof, and your permanent account number (PAN) card Please note that this list is for reference purposes only. Additional documents may be requested from you during the credit card application process.

### Important documents

- [Domestic Lounge List: Live+ Lounge Access Domestic Lounge List: Live+ Lounge Access Download](\content\dam\hsbc\in\documents\credit-cards\live-plus-in-participating-airport-lounges.pdf)
- [Terms and conditions (PDF) Terms and conditions (PDF) Download](\content\dam\hsbc\in\documents\credit-cards\visa-cashback\terms-and-condition.pdf)
- [Key things you should know (PDF, 83KB) Key things you should know (PDF, 83KB) Download](\content\dam\hsbc\in\documents\credit_cards_ktysk.pdf)
- [Live+ Credit Card Service Guide (PDF, 0.98MB) Live+ Credit Card Service Guide (PDF, 0.98MB) Download](\content\dam\hsbc\in\documents\credit-cards\live-plus-credit-card-services-guide.pdf)
- [Credit card limit review form (PDF, 574KB) Credit card limit review form (PDF, 574KB) Download](\content\dam\hsbc\in\documents\cc_limit_enhancement.pdf)
- [Acquisition offer terms and conditions (PDF, 296KB) Acquisition offer terms and conditions (PDF, 296KB) Download](\content\dam\hsbc\in\documents\credit-cards\live-plus-welcome-cashback.pdf)

## Live+ eligible purchases for cashback

| Category      | Transaction value   | Applicable cashback               | Cashback earned   |
|---------------|---------------------|-----------------------------------|-------------------|
| Dining        | INR11,500           | 10%                               | INR1,150          |
| Food delivery | INR5,000            | 10%                               | INR500            |
| Groceries     | INR9,000            | 10%                               | INR900            |
| Hotel         | INR15,000           | 1.5%                              | INR225            |
| Medicine      | INR3,000            | 1.5%                              | INR45             |
| Shopping      | INR15,000           | 1.5%                              | INR225            |
| Utilities     | INR500              | 0                                 | 0                 |
| Grand total   | INR59,000           | 10% (capped) and 1.5% (unlimited) | INR1,495          |

| Category            | Dining                            |
|---------------------|-----------------------------------|
| Transaction value   | INR11,500                         |
| Applicable cashback | 10%                               |
| Cashback earned     | INR1,150                          |
|                     |                                   |
| Category            | Food delivery                     |
| Transaction value   | INR5,000                          |
| Applicable cashback | 10%                               |
| Cashback earned     | INR500                            |
|                     |                                   |
| Category            | Groceries                         |
| Transaction value   | INR9,000                          |
| Applicable cashback | 10%                               |
| Cashback earned     | INR900                            |
|                     |                                   |
| Category            | Hotel                             |
| Transaction value   | INR15,000                         |
| Applicable cashback | 1.5%                              |
| Cashback earned     | INR225                            |
|                     |                                   |
| Category            | Medicine                          |
| Transaction value   | INR3,000                          |
| Applicable cashback | 1.5%                              |
| Cashback earned     | INR45                             |
|                     |                                   |
| Category            | Shopping                          |
| Transaction value   | INR15,000                         |
| Applicable cashback | 1.5%                              |
| Cashback earned     | INR225                            |
|                     |                                   |
| Category            | Utilities                         |
| Transaction value   | INR500                            |
| Applicable cashback | 0                                 |
| Cashback earned     | 0                                 |
|                     |                                   |
| Category            | Grand total                       |
| Transaction value   | INR59,000                         |
| Applicable cashback | 10% (capped) and 1.5% (unlimited) |
| Cashback earned     | INR1,495                          |

## Get started

### Apply online

When you apply online and complete your application with video self-verification, you'll be eligible for an Amazon eGift Voucher worth INR250. T&amp;Cs apply.

[Apply now](https://www.accountopening.hsbc.co.in/credit-cards/#!/app/apply-for-credit-card?form.campaign_id=INM_PWS_RKTCCPDTBOTTOM&form.source=INM_PWS&WT.ac=INM_PWS_RKTCCPDTBOTTOM&card=cbc)

[Apply now for Live+ credit card This link will open in a new window](https://www.accountopening.hsbc.co.in/credit-cards/#!/app/apply-for-credit-card?form.campaign_id=INM_PWS_RKTCCPDTBOTTOM&form.source=INM_PWS&WT.ac=INM_PWS_RKTCCPDTBOTTOM&card=cbc)

### Contact us

It's usually quickest to apply online, but if you prefer to speak to someone about your application, call us or visit your nearest branch.

[Get in touch](\help\contact)

## Frequently asked questions

### What is a cashback credit card?

A cashback credit card is a credit card that provides cashback whenever the customer swipes the card at a physical store or makes online payments through the credit card.

### How can I make the most of my cashback credit card?

To make the most of your cashback credit card, use your card for larger purchases to gain maximum cashback.

### Will the cashback be credited to the credit card account?

Yes, the cashback you earn will be credited to your credit card within 45 days of the card statement date.

### How do cashback credit cards work?

Cashback credit cards offer you the chance to earn cash from the money you spend, by paying you back a percentage of what you spend or giving you reward points for additional benefits.

## You might also be interested in

### [HSBC RuPay Cashback Credit Card](\credit-cards\products\rupay-cashback-credit-card)

Earn cashback and enjoy exciting rewards, exclusive perks and effortless payments with UPI.

### [HSBC Premier Credit Card](\credit-cards\products\premier)

From travel to gourmet dining, your HSBC Premier Credit Card offers a range of exclusive benefits.

### [HSBC Travel Companion](\credit-cards\offers\travel-companion)

Explore our exclusive travel offers with your HSBC credit card.

### [Credit card offers](\credit-cards\offers)

Explore the latest offers for our credit card customers, with discounts on shopping, dining and more.

## Notes

### Verify yourself by video - terms and conditions

This Offer ('Offer') is brought to you by The Hongkong and Shanghai Banking Corporation Limited, India ('Bank') and is made available on the website [amazon.in](https://amazon.in/) or mobile site or mobile application thereof (collectively, ' [Amazon.in](https://amazon.in/) ') by Amazon Pay (India) Private Limited ('Amazon') and any participation is voluntary. Offer Terms and Conditions ('Offer Terms') are in addition to the [amazon.in](https://amazon.in/) 'Conditions of Use &amp; Sale' and 'Privacy Notice' to which you agree to, by using [amazon.in](https://amazon.in/) and [Terms and Conditions of HSBC Credit Cards (PDF)](\content\dam\hsbc\in\documents\platinum_mostimp_tnc.pdf) . In the event of any conflict between the Conditions of Use &amp; Sale and these Offer Terms, these Offer Terms will prevail, only for the purposes of this Offer. This Amazon eGift Voucher offer is provided by The Hongkong and Shanghai Banking Corporation Limited, India (HSBC) to Resident Indian customers (hereinafter referred to as 'credit card applicant') who have participated in the offer. Each qualifying credit card applicant who has completed Video KYC (VKYC) and has got the credit card approved and issued is entitled to an Amazon eGift Voucher of INR250 (Offer). This offer is valid only on online applications and upon successful completion of the Video KYC (VKYC) and issuance of the credit card, during the offer period from 19 August 2025 to 30 September 2025. This is a limited period Offer and HSBC in its sole discretion reserves the right to alter, modify, change or vary all or any of these terms and conditions or to replace, wholly or in part, this Offer by another Offer, whether similar to this Offer or not, or to withdraw it altogether at any point in time by providing appropriate intimation to the Cardholder. The Amazon eGift Voucher (WinPin code) will be sent to your email ID provided in the online credit card application, within 45 days of end of the offer i.e. 15 November 2025. All decisions with respect to the Offer shall be at the sole discretion of HSBC and the same shall be final, binding and non-contestable. Other than the specific entitlements available to the Cardholders under this Offer, any other claims with regard to this Offer against HSBC are waived. Credit card applicants are not bound in any way to participate in this Offer. Any participation is voluntary and the Offer is being made purely on a best effort basis. Nothing herein amounts to a commitment by the Bank or Amazon to conduct further, similar or other Offers. Issuance of the credit card is at the sole discretion of the Bank and is subject to the Bank's internal approval norms. By participating in this Offer, every credit card applicant expressly agrees that Bank and Amazon will not be liable or responsible for any loss or damage whatsoever that a Cardholder may suffer, directly or indirectly, in connection with the Offer including but not limited to that associated with his/her use or delivery or misuse of the Product(s). The existence of any dispute shall not, by itself, constitute any claim against HSBC. The Bank does not make any warranties or representations as to the quality, merchantability, suitability or availability of the product and services offered under these Offers. Any dispute regarding these must be addressed in writing, by the Cardholder, directly to Amazon. Prior to using the Amazon website and/or the mobile app, the Cardholder should refer, read, understand, accept and agree to the user agreement and Terms and Conditions of the said website and the mobile app, and proceed only if the Cardholder agrees to abide by the same. The Cardholder will be required to give personal information and other details online. The Cardholder should read and understand the privacy policy of the website and the mobile site, prior to providing any such information. Any disclosure of information made by the Cardholder towards availing of or fulfilment of the Offer is at the sole discretion of the Cardholder and the Bank shall not be responsible for the same. Amazon may use the personal information shared by the Cardholder for any other purpose (like marketing, etc.) and the Bank will not be held liable for such usage of personal information by Amazon Products offered under this Offer are subject to availability with Amazon and HSBC will not be liable for non-availability of any of the products. The Offer is subject to force majeure events. These Offer Terms are governed by the laws of India and the courts at Mumbai will have exclusive jurisdiction over any matters/disputes arising out of or in relation to these Offer Terms. Any person availing this Offer will be deemed to have accepted these Offer Terms. **Voucher Terms and Conditions:** The eGift Voucher is valid for a period of 6 months from the date of issuance. eGift Voucher cannot be reloaded, resold, transferred for value or redeemed for cash. eGift Voucher cannot be used to purchase other gift card. eGift Voucher cannot be used on any of the partner sites. eGift Voucher cannot be used to purchase any other type of digital content such as apps. eGift Voucher cannot be transferred from one account to another once the claim code has been added. Amazon may change (add to, delete, or amend) these terms from time to time. Unless stated otherwise, the changes will apply to any new Amazon eGift Voucher that are for personal, non-commercial use and enjoyment only. The same may be shared with family and friends, but may not be advertised, sold or used as promotional items by the purchaser or anyone else without Amazon's prior written consent. Amazon eGift Voucher cannot be replaced, refunded or revalued. It cannot be exchanged for points or cash and cannot be re-validated. HSBC does not make any warranties or representations as to the quality, merchantability, suitability or availability of the products or services offered under this Offer. Any dispute regarding delivery, service, suitability, merchantability, availability or quality of the products/services availed under this Offer must be addressed in writing, by the customer directly to [amazon.in](https://www.amazon.in/) Tax liability, if any, will be borne by the Cardholder. By using the eGift Voucher, the Cardholders shall be deemed to have accepted all the aforementioned Terms and Conditions in totality.

[Back to top](#)

## [Connect with us](\help\contact)

Here's an easy way to share your thoughts, stay informed and join the conversation. Follow us:

[HSBC India Instagram Account This link will open in a new window](https://instagram.com/hsbc_in/)

[HSBC India Facebook Account This link will open in a new window](https://www.facebook.com/HSBCIndia/)

[HSBC India Twitter Account This link will open in a new window](https://www.twitter.com/HSBC_IN)

[HSBC India Youtube Account This link will open in a new window](https://www.youtube.com/channel/UC3Nt_U6gzLlKdAL9Evq0KXQ/featured)