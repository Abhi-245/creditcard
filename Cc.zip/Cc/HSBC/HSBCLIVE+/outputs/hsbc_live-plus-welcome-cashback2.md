<!-- image -->

## Live+ - Terms and Conditions

1. This Offer is brought to you by The Hongkong and Shanghai Banking Corporation Limited, India ('HSBC'),. Any participation in the said Offer is voluntary.
2. This Offer is applicable to new HSBC Live+ Credit Cardholders (hereinafter referred to as 'Cardholders'), excluding Corporate Cardholders, who apply for a Live+ Credit Card between 1 July 2025 till 31 December 2025 ('Offer Period') and the card is issued subsequently.
3. Credit Cardholders who have not repaid their minimum payment due within 30 days of their payment due date as mentioned on the credit card statement, will not be eligible for the Offer.
4. Credit Cardholders with updated KYC details with the Bank only are eligible for this Offer.
5. Under this Offer, Cardholders will be entitled to ₹ 1,000 Cashback on successfully downloading the HSBC India Mobile app and make transactions of at least ₹ 20,000 within the first 30 days T&amp;Cs apply. Offer ends 31 December 2025.
6. Add-on credit Cardholders will not have separate Offer eligibility.
7. Eligible customers will receive cashback within 60 days after completion of 30 days from credit card issuance.
8. Cardholders are required to complete transactions within 30 calendar days of the date of issuance of the new credit card. The transaction refers to all types of sales transactions (including but without limitation, bill payments, online purchases, mail and telephone orders and insurance payments). Non-sales transactions, including but without limitation, finance charges, cash advance and cash advance charges, late payment charges, balance transfer or annual fees are not included.
9. Cancelled or refunded transactions will not be considered as first transaction.
10. Cardholders cannot combine any other welcome Offer/introductory Offer with this cashback Offer.

.

11. HSBC reserves the sole right to decide on whether a purchase transaction meets the eligibility criteria as listed above. All decisions with respect to the Offer shall be at the sole discretion of HSBC and the same shall be final, binding and non-contestable. Other than the specific entitlements available to the Cardholders under this Offer, any other claims with regard to this Offer against HSBC are waived.
12. This is a limited period Offer and HSBC in its sole discretion reserves the right to add, alter, modify, change or vary all or any of these Terms and Conditions or to replace, wholly or in part, this programme by another programme, whether similar to this programme or not, or to withdraw it altogether at any point in time by providing appropriate intimation to the Cardholder.
13. Issuance of the credit card is at the sole discretion of the Bank and is subject to the Bank's internal approval norms.
14. When the Cardholder shows any interest in the Offer by reaching out to the Bank by way of any of the above modes such as writing/calling on the toll free number or by providing an SMS, the said communication shall be treated as explicit and express consent to HSBC (including its representatives, group companies and service providers) to call the Cardholder on the contact number provided by the Cardholder in relation to the HSBC Credit Card irrespective of whether the Cardholder is a part of National Do Not Call registry/Do Not Call registry/National Customer Preference Register.
15. HSBC will not be liable for any direct or indirect loss or damage whatsoever that may be suffered, as a result of participating in the Offer. The existence of any dispute shall not, by itself, constitute any claim against HSBC.
16. Any disputes arising out of or in connection with this Offer shall be subject to the exclusive jurisdiction of courts in Mumbai only.
17. The usage of the credit card is governed by applicable Terms and Conditions. Please visit www.hsbc.co.in for detailed Terms and Conditions.
18. This Offer is subject to force majeure events.
19. Tax liability, if any will be borne by the Cardholder.
20. By availing of the Offer, Cardholders shall be deemed to have accepted all the aforementioned Terms and Conditions in totality.

Issued by The Hongkong and Shanghai Banking Corporation Limited, India. Incorporated in Hong Kong SAR with limited liability.

Privacy and Security | Terms of use | Hyperlink Policy

© Copyright 2025. The Hongkong and Shanghai Banking Corporation Limited, India. Incorporated in Hong Kong SAR with limited liability. All rights reserved.