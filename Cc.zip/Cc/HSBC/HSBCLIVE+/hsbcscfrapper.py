"""
genericcrawl.py
---------------
 - Scrape the main webpage (entire front page, no depth).
 - Save it as text.
 - Then scrape extra links provided manually:
     * HTML pages → BeautifulSoup
     * PDFs → PyPDF2
 - Save everything separately + combined.
"""

import os
import re
import time
import requests
import io
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from PyPDF2 import PdfReader


# -------------------------------
# Helpers
# -------------------------------

def fetch_with_retries(url, retries=3, timeout=15):
    """Fetch HTML/PDF with retries. Returns (kind, data)."""
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(
                url,
                timeout=timeout,
                headers={"User-Agent": "Mozilla/5.0"},
                allow_redirects=True,
            )

            content_type = resp.headers.get("Content-Type", "").lower()

            # PDF detection
            if resp.url.lower().endswith(".pdf") or "application/pdf" in content_type:
                return ("pdf", resp.content)

            if resp.status_code == 200:
                return ("html", resp.text)

            print(f"[WARN] {url} returned {resp.status_code} (attempt {attempt})")

        except Exception as e:
            print(f"[ERROR] Fetch failed for {url} (attempt {attempt}): {e}")

        time.sleep(2 * attempt)  # backoff

    return (None, None)


def extract_pdf_bytes(pdf_bytes):
    """Extract text from raw PDF bytes using PyPDF2."""
    try:
        file_like = io.BytesIO(pdf_bytes)
        reader = PdfReader(file_like)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception as e:
        print(f"[ERROR] PDF extraction failed: {e}")
        return ""


def safe_filename_from_url(url: str, suffix: str = "", folder: str = "") -> str:
    safe = re.sub(r"[^\w\-_.]", "_", url)
    if suffix:
        safe = f"{safe}_{suffix}"
    if folder:
        os.makedirs(folder, exist_ok=True)
        return os.path.join(folder, f"{safe}.txt")
    return f"{safe}.txt"

def clean_extracted_text(text: str) -> str:
    """Clean up extracted text by removing junk lines and collapsing spaces."""
    cleaned_lines = []
    for line in text.splitlines():
        if not line.strip():
            continue
        # remove lines that are only | or whitespace
        if re.fullmatch(r"[\|\s]+", line):
            continue
        cleaned_lines.append(line.strip())
    return "\n".join(cleaned_lines)

# -------------------------------
# Main scraping logic
# -------------------------------

def scrape_site(main_url, extra_links=None):
    combined_texts = []

    # --- Step 1: Scrape main page fully ---
    print(f"\n[Scraping main page] {main_url}")
    kind, data = fetch_with_retries(main_url)

    if kind == "html" and data:
        soup = BeautifulSoup(data, "html.parser")
        text = soup.get_text(separator="\n", strip=True)
    elif kind == "pdf":
        text = extract_pdf_bytes(data)
    else:
        text = "(no text extracted)"

    main_file = safe_filename_from_url(main_url, suffix="main")
    with open(main_file, "w", encoding="utf-8") as f:
        f.write("URL: " + main_url + "\n\n")
        f.write(text)
    print(f"Saved main page -> {main_file}")
    combined_texts.append(f"==== Main Page: {main_url} ====\n{text}\n")

    # --- Step 2: Scrape extra links provided ---
    if extra_links:
        for link in extra_links:
            print(f"\n[Scraping extra link] {link}")
            kind, data = fetch_with_retries(link)

            if not kind:
                print(f"[FAILED] Could not scrape {link}")
                continue

            if kind == "pdf":
                text = extract_pdf_bytes(data)
            else:
                soup2 = BeautifulSoup(data, "html.parser")
                raw_text = soup2.get_text(separator="\n", strip=True)
                text = clean_extracted_text(raw_text)


            safe_url = safe_filename_from_url(link, folder="hsbclinkbylinkscrap")
            with open(safe_url, "w", encoding="utf-8") as f:
                f.write("URL: " + link + "\n\n")
                f.write(text or "(no text extracted)")
            print(f"Saved extra link -> {safe_url}")

            combined_texts.append(f"==== Extra Link: {link} ====\n{text or '(no text extracted)'}\n")

    # --- Step 3: Save combined output ---
    with open("hsbccombinedscrapping.txt", "w", encoding="utf-8") as f:
        f.write("\n\n".join(combined_texts))
    print("\nSaved combined output to hsbccombinedscrapping.txt")


# -------------------------------
# Run example
# -------------------------------

if __name__ == "__main__":
    scrape_site(
        main_url="about:blank",
        extra_links=[
            "https://www.hsbc.co.in/content/dam/hsbc/in/documents/credit-cards/visa-cashback/terms-and-condition.pdf",
            "https://www.hsbc.co.in/content/dam/hsbc/in/documents/credit_cards_ktysk.pdf",
            "https://www.hsbc.co.in/content/dam/hsbc/in/documents/credit-cards/live-plus-credit-card-services-guide.pdf",
            "https://www.hsbc.co.in/content/dam/hsbc/in/documents/credit-cards/live-plus-welcome-cashback.pdf"
        ]
    )
